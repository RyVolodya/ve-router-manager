# VE Router Manager (PRM) 0.4.25

PRM is a host-native management UI for Proxmox VE. It runs independently on HTTPS port 8005 while the Proxmox GUI remains on port 8006.


## Dashboard cluster awareness (v0.4.25)

- Dashboard always shows the local node as `Node: <name> · HTTPS :8005`.
- When `/etc/pve/corosync.conf` is present, PRM also shows `Cluster: <cluster-name> (<local-corosync-address>)`.
- Standalone nodes do not show a Cluster line.
- Firewall UI is intentionally limited to Datacenter and local Node scopes; VM/LXC firewalls remain under native Proxmox management.
- User-facing `Host firewall` wording was renamed to `Node firewall`.

## NAT priority (v0.4.23)

- Explicit DNAT rules are evaluated before DMZ.
- Newly created DNAT rules are placed above older DNAT rules.
- DMZ is always emitted last in `prerouting`, so it acts as a catch-all fallback.
- Overlapping SNAT/MASQUERADE rules are emitted from the most-specific source prefix to the broadest source prefix.
- NAT status in the web UI follows this effective PRM ordering.

## Static IPv6 disables SLAAC (v0.4.22)

When an interface is configured as **IPv6 Static** in PRM, PRM now enforces `accept_ra=0` and `autoconf=0` for that interface. Any previously learned dynamic global SLAAC address and RA/DHCPv6 routes are removed while the configured static IPv6 address and static gateway remain intact. SLAAC and DHCPv6 modes explicitly opt back into RA processing.

The boot-time IPv6 synchronizer also migrates existing `inet6 static` Proxmox interfaces so upgrades from v0.4.21 remove stale SLAAC state automatically.


## IPv6 firewall safety rule (v0.4.21)

PRM now maintains a persistent Proxmox Host Firewall rule `IN ACCEPT -p ipv6-icmp`.
The rule is tagged as `PRM Auto`, is read-only in PRM, survives reboot/firewall reloads,
and prevents a host INPUT DROP policy from breaking essential IPv6 ICMP/NDP/RA traffic.
Automatic PRM firewall rules are also rejected by the backend if an edit/delete is attempted directly through the PRM API.


## 0.2.5

- Fixed Linux Bridge create/update on current Proxmox VE: PRM no longer passes unsupported `bridge_stp` / `bridge_fd` options to `pvesh`; bridge ports and VLAN-aware settings continue to use the supported Proxmox API fields.

## 0.2.4

- Enforce `root:root 0644` on `/etc/network/interfaces` and `interfaces.new` after every PRM network mutation, before/after Apply, and during rollback so Proxmox Network GUI cannot lose visibility because of restrictive file permissions.

## 0.2.3
- Pending Proxmox network changes no longer block PRM interface operations.
- Interfaces page shows pending Add/Edit/Delete changes with Apply/Revert controls.
- Interface inventory merges active `/etc/network/interfaces`, staged `interfaces.new`, Proxmox API and physical NIC discovery so active interfaces do not disappear because of a staged deletion.
- Rollback preserves any pending Proxmox changes that existed before the PRM transaction.
- Runtime Up/Down controls for Linux Bridge, Linux Bond and Linux VLAN only. Physical NICs never receive Up/Down buttons.
- Up/Down uses `ip link` and does not modify persistent Proxmox networking.

## 0.2.1
- DHCP-aware host interfaces with runtime lease addresses.
- Linux Bridge, Linux Bond and Linux VLAN create/edit/delete.
- Physical NIC attach/detach with L3 settings migration.
- Automatic 90-second rollback for applied network changes.

## 0.2.0

- Dashboard is read-only and contains no network action buttons.
- Shows interface count plus QEMU VM and LXC counts from Proxmox.
- Shows global WAN IPv4 and IPv6 addresses from physical/default-route interfaces only.
- Dashboard interface table has deterministic ordering and live RX/TX rates using Linux interface counters.
- All navigation pages are active: Interfaces, Networks, DHCP, Routing, NAT, Firewall, WireGuard, IPv6 and System.
- Interfaces page retains safe vmbr staging and Proxmox Apply actions.
- Monitoring pages read current host/Proxmox state without changing it.
- Linux PAM authentication is retained.

## Safety

Installing or upgrading PRM does not modify `/etc/network/interfaces`, user-created Proxmox firewall rules, pveproxy, Proxmox certificates, or TCP port 8006. When a PRM DHCPv4/DHCPv6 server is active, PRM manages only the narrow Host INPUT permits required for UDP/67 and UDP/547 on that DHCP interface. Network changes happen only after an authenticated administrator explicitly uses the Interfaces page.


## v0.2.10
- Interfaces: optional Add IPv6 block with Static, SLAAC, DHCPv6 modes.
- DHCP: IPv4 fields shown by default; optional Add IPv6 block with SLAAC/DHCPv6.

## v0.2.11
- Fixed SLAAC client mode: PRM now runs a persistent IPv6-only dhcpcd process per interface instead of issuing a one-shot Router Solicitation.
- SLAAC uses dhcpcd userspace Router Advertisement processing (`ipv6ra_own`) and does not modify IPv4 DHCP or resolv.conf.
- DHCPv6 uses the same persistent per-interface client and keeps RA processing for the IPv6 default route while requesting IA_NA addresses.

## v0.3.0
- NAT44/NAT66 management with SNAT, DNAT and DMZ/exposed-host modes.
- PRM-owned nftables NAT tables with packet/byte counters and IPv4/IPv6 forwarding controls.

## v0.3.1
- Firewall page now reads Datacenter, Host, QEMU VM and LXC rules directly from the Proxmox API.
- Add Firewall Rule supports Host, VM and LXC targets; INPUT/OUTPUT for guests and INPUT/OUTPUT/FORWARD for Host where supported by the nftables-based Proxmox firewall backend.
- Common Proxmox rule fields are supported: action, interface, source/destination, protocol, source/destination ports, macro, ICMP type, log level, enabled state and comment.
- Rules created by PRM are stored in Proxmox and tagged in their comment with a PRM rule ID so only those rules expose Edit/Delete controls in PRM.
- Rules created elsewhere remain visible but read-only in PRM.

## v0.3.2
- Added Datacenter and Host firewall enable/disable controls through the Proxmox API.
- Removed the separate IPv6 page.
- Added persistent IPv4 and IPv6 forwarding enable/disable controls to NAT.
- Added Proxmox 9 fallback state reading for Datacenter firewall options.

## v0.3.6
- Fixed Datacenter and Host firewall Enable/Disable actions on Proxmox builds that require integer values: PRM now sends `-enable 1` and `-enable 0` instead of boolean strings.
- Both firewall toggles are verified against the Proxmox API state after the write; the GUI changes only after verification succeeds.

## v0.4.1 WireGuard

PRM can manage multiple WireGuard interfaces and Remote Access / Site-to-Site peers directly on the Proxmox host. Server-side policy routing is intentionally disabled (`Table = off`); site-to-site networks are installed as ordinary routes in the Linux main table. Peer access can be scoped to detected Proxmox bridge/VLAN/bond networks, with optional IPv4 Internet NAT and IPv6 NAT66, client configuration/QR generation, PSK support, and live handshake/RX/TX status.

## v0.4.1
- WireGuard interface IPv6 is optional via **Use IPv6** and receives an automatic free ULA address from `fd00::/8`.
- WireGuard peer bridge access uses per-bridge checkboxes and supports Internet-only peers with no bridge access selected.
- Internet-only IPv4 client profiles use `AllowedIPs = 0.0.0.0/0` without redundant IPv4 tunnel entries.
- PRM WireGuard interfaces are shown in Interfaces and Dashboard alongside Proxmox interfaces.
- Sidebar/login branding now uses the PRM network-router logo mark and no longer shows the version next to the logo.


## DHCP lease reservations (v0.4.9)
PRM-managed DHCPv4 and DHCPv6 leases can be pinned from the Leases table with a Static button, given an optional PRM name, and returned to dynamic allocation with Dynamic. IPv4 uses MAC identity; DHCPv6 uses DUID/client-id. SLAAC and Proxmox SDN leases remain read-only.

## NAT boot persistence (v0.4.10)

PRM restores its nftables NAT44/NAT66 rules after boot and now orders the NAT
service after the Proxmox firewall daemons.  A lightweight systemd timer checks
only the Proxmox `fwbr+` conntrack-zone helper and recreates the PRM-owned
`CT --zone 1` rule if a later firewall startup/reload removes it.  The guard
does not rewrite NAT tables, so it does not reset NAT counters or flows.

## NAT boot persistence (v0.4.11)

PRM restores NAT44/NAT66 and the Proxmox `fwbr+` conntrack-zone helper once during boot. `prm-nat.service` runs after the Proxmox firewall services, then `prm-nat-helper.service` performs a final one-shot configuration check. There is no periodic watchdog or timer. If the saved PRM NAT configuration contains an active NAT44/NAT66 SNAT, DNAT or DMZ rule, the corresponding `CT --zone 1` helper is ensured; otherwise no helper is created.

## Dynamic IPv6 client split (v0.4.12)

PRM now keeps SLAAC and DHCPv6 as separate mechanisms on WAN/uplink interfaces:

- **SLAAC** uses the Linux kernel only (`accept_ra=2`, `autoconf=1`) and does not run dhcpcd. This prevents duplicate global addresses/default routes caused by two RA processors.
- **DHCPv6** uses the kernel for Router Advertisements/default route (`accept_ra=2`, `autoconf=0`) and a restricted dhcpcd instance only for DHCPv6 IA_NA address assignment (`noipv6rs`, `nogateway`, `ia_na 1`).
- Router-facing PRM dynamic IPv6 modes disable temporary/privacy SLAAC addresses (`use_tempaddr=0`) so the host has one stable SLAAC address.
- `prm-ipv6-restore.service` restores the selected mode once after networking starts at boot; no polling/watchdog is used.

## NAT/DHCP/IPv6 reliability (v0.4.13)

- NAT44/NAT66 boot restore now performs a one-time conntrack-zone verification after Proxmox firewall services and again immediately before the PRM GUI starts. There is no watchdog/timer.
- Static DHCP reservations can use a different IPv4/IPv6 address than the current lease. PRM validates the subnet/prefix, existing reservations, active leases, local interface addresses and performs an ARP/NDP duplicate probe before saving.
- Dynamic IPv6 client modes are cleanly transitioned. Switching SLAAC <-> DHCPv6 removes the previous dynamic global IPv6 address and RA/DHCP routes, then solicits a fresh RA. SLAAC remains kernel-native; DHCPv6 uses address-only dhcpcd IA_NA.


## Deterministic NAT boot restore (v0.4.14)

At boot, `prm-nat.service` reads `/var/lib/prm/nat.json`. If there are no enabled NAT rules, PRM installs no NAT44/NAT66 tables and no PRM conntrack-zone helper. If enabled rules exist, the service waits (bounded to the startup window) for referenced interfaces and source networks to become available, removes stale PRM NAT runtime tables, and recreates the active NAT44/NAT66 tables, chains, rules, forwarding state, and required `fwbr+` conntrack-zone helper using the same rule-generation path as a fresh GUI Create/Save operation. No periodic watchdog is used.



## Configuration apply overlay and DMZ/WireGuard protection (v0.4.21)

- Mutating actions such as Save, Create, Delete, Apply, interface state changes and firewall/NAT updates show a central `Зачекайте йде застосування змін у конфігурації.` overlay while the server applies the change.
- DMZ / Exposed host rules automatically protect every configured or currently running WireGuard UDP listen port. These ports remain local to the Proxmox/PRM host and are not DNATed to the DMZ target.
- Automatic WireGuard DMZ exclusions are UDP-only, so TCP on the same numeric port can still be forwarded unless it is also present in the administrator's `DMZ excluded ports` list.
- Creating, editing, enabling, disabling or deleting a PRM WireGuard interface refreshes existing DMZ rules so listener-port exclusions stay current.
- Active PRM WireGuard listeners receive persistent PRM-owned Proxmox Host Firewall UDP ACCEPT rules, scoped to the configured WAN interface when one is selected.

## DHCP firewall, WireGuard live monitor and IPv6 firewall UI (v0.4.19)

- Active PRM DHCPv4 servers automatically create a persistent Proxmox Host INPUT ACCEPT rule for UDP/67 on the selected interface. Active DHCPv6 server mode does the same for UDP/547. Rules are tagged as PRM automatic rules, synchronized on create/edit/delete and package upgrade, and removed when no longer required.
- WireGuard peers now have a dedicated ACTIVE/INACTIVE live monitor. Handshake age, endpoint and RX/TX counters refresh every 2 seconds without reloading the whole page.
- Page data loads display a blocking overlay with `Зачекайте йде завантаження даних` after a short anti-flicker delay. Live dashboard/WireGuard polling does not trigger the overlay.
- Firewall Source/Destination fields explicitly support IPv4 and IPv6 addresses/CIDRs (for example `10.10.0.0/16` and `fd10:10::/64`) and continue to write rules through the native Proxmox Firewall API.
- DHCPv6 pool values remain administrator-controlled; v0.4.19 does not rewrite the configured range.

## DMZ excluded-ports nftables fix (v0.4.18)

- Fixed DMZ / Exposed host rule generation when `DMZ excluded ports` are configured.
- nftables terminal `return` verdict is now emitted before the trailing rule comment, producing valid nft syntax.
- Existing DMZ semantics are unchanged: excluded TCP/UDP ports remain on the PRM/Proxmox host, while other traffic to the configured external address is DNATed to the DMZ target.

## DHCPv6 + SLAAC and WireGuard local-access fix (v0.4.17)

- PRM DHCPv6 server mode now advertises SLAAC on the same /64 while continuing to allocate stateful DHCPv6 IA_NA addresses. IPv6 default-route delivery remains Router Advertisement based.
- Existing PRM DHCPv6 dnsmasq configurations are regenerated during package upgrade so the combined DHCPv6 + SLAAC behaviour takes effect without re-saving the DHCP server in the GUI.
- DHCP lease/status view now also observes SLAAC neighbours while DHCPv6 mode is active.
- WireGuard full-tunnel client configs keep explicitly selected Proxmox bridge prefixes in `AllowedIPs` alongside `0.0.0.0/0` and/or `::/0`. This prevents a client's more-specific local route from stealing traffic intended for selected `vmbr` networks.
- WireGuard Internet NAT remains WAN-only; enabling Internet access does not remove or replace selected bridge-network access.

