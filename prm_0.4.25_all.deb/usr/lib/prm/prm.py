#!/usr/bin/env python3
import ctypes
import ctypes.util
import grp
import ipaddress
import json
import os
import pwd
import re
import secrets
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from http import cookies
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, unquote

CONFIG = Path('/etc/prm/config.json')
WEB = Path('/usr/share/prm/web')
STATE = Path('/var/lib/prm')
ROLLBACK_DIR = STATE / 'rollback'
DHCP_DIR = STATE / 'dhcp'
DHCP_CONFIG = STATE / 'dhcp.json'
DHCP_RESERVATIONS = STATE / 'dhcp-reservations.json'
ROUTES_CONFIG = STATE / 'routes.json'
IPV6_CLIENTS_CONFIG = STATE / 'ipv6-clients.json'
IPV6_PENDING_CONFIG = STATE / 'ipv6-pending.json'
WIREGUARD_CONFIG = STATE / 'wireguard.json'
WG_DIR = Path('/etc/wireguard')
VERSION = '0.4.25'
SESSIONS = {}
SESSIONS_LOCK = threading.Lock()
FIREWALL_CACHE = {'ts': 0.0, 'data': None}
FIREWALL_CACHE_LOCK = threading.Lock()
FIREWALL_CACHE_TTL = 3.0
INTERFACES_CACHE = {'ts': 0.0, 'data': None}
INTERFACES_CACHE_LOCK = threading.Lock()
INTERFACES_CACHE_TTL = 3.0
GUEST_CACHE = {'ts': 0.0, 'data': None}
GUEST_CACHE_LOCK = threading.Lock()
GUEST_CACHE_TTL = 10.0

PAM_SUCCESS = 0
PAM_PROMPT_ECHO_OFF = 1
PAM_PROMPT_ECHO_ON = 2
PAM_ERROR_MSG = 3
PAM_TEXT_INFO = 4


class PamMessage(ctypes.Structure):
    _fields_ = [('msg_style', ctypes.c_int), ('msg', ctypes.c_char_p)]


class PamResponse(ctypes.Structure):
    _fields_ = [('resp', ctypes.c_char_p), ('resp_retcode', ctypes.c_int)]


CONV_FUNC = ctypes.CFUNCTYPE(
    ctypes.c_int,
    ctypes.c_int,
    ctypes.POINTER(ctypes.POINTER(PamMessage)),
    ctypes.POINTER(ctypes.POINTER(PamResponse)),
    ctypes.c_void_p,
)


class PamConv(ctypes.Structure):
    _fields_ = [('conv', CONV_FUNC), ('appdata_ptr', ctypes.c_void_p)]


def load_config():
    cfg = {
        'listen': '0.0.0.0',
        'port': 8005,
        'tls': True,
        'allowed_groups': ['root', 'sudo'],
        'session_hours': 8,
        'rollback_seconds': 90,
    }
    if CONFIG.exists():
        try:
            cfg.update(json.loads(CONFIG.read_text()))
        except Exception:
            pass
    return cfg


def node_name():
    return socket.gethostname().split('.')[0]


def run(cmd, timeout=45, allow_fail=False):
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    except FileNotFoundError:
        if allow_fail:
            return ''
        raise RuntimeError(f'{cmd[0]} was not found')
    if p.returncode != 0:
        if allow_fail:
            return ''
        raise RuntimeError((p.stderr or p.stdout or 'command failed').strip())
    return p.stdout


def run_json(cmd, default=None):
    out = run(cmd, allow_fail=True)
    if not out:
        return [] if default is None else default
    try:
        return json.loads(out)
    except Exception:
        return [] if default is None else default


def pvesh_json(args):
    out = run(['pvesh'] + args + ['--output-format', 'json'])
    return json.loads(out or 'null')


def natural_key(value):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r'(\d+)', str(value or ''))]


def valid_iface(name):
    return bool(re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,14}', str(name or '')))


def read_counter(iface, counter):
    try:
        return int(Path(f'/sys/class/net/{iface}/statistics/{counter}').read_text().strip())
    except Exception:
        return 0


def carrier_state(iface):
    """Return an operator-friendly link state.

    Linux bridges without a physical port commonly report operstate=UNKNOWN even
    while they are administratively UP and fully usable by guests.  Treat that
    specific combination as UP, while preserving real DOWN/LOWERLAYERDOWN states.
    """
    rows = run_json(['ip', '-j', 'link', 'show', 'dev', iface])
    if rows:
        row = rows[0]
        oper = str(row.get('operstate') or '').upper()
        flags = {str(x).upper() for x in (row.get('flags') or [])}
        if oper == 'UP':
            return 'UP'
        if oper == 'UNKNOWN' and 'UP' in flags:
            return 'UP'
        if oper:
            return oper
        return 'UP' if 'UP' in flags else 'DOWN'
    try:
        return Path(f'/sys/class/net/{iface}/operstate').read_text().strip().upper()
    except Exception:
        return 'NOT PRESENT'


def runtime_addresses(iface):
    rows = run_json(['ip', '-j', 'address', 'show', 'dev', iface])
    v4, v6 = [], []
    for row in rows:
        for ai in row.get('addr_info', []):
            local = ai.get('local')
            prefix = ai.get('prefixlen')
            scope = ai.get('scope')
            if not local or scope == 'host':
                continue
            text = f'{local}/{prefix}' if prefix is not None else local
            if ai.get('family') == 'inet':
                v4.append(text)
            elif ai.get('family') == 'inet6' and not local.lower().startswith('fe80:'):
                v6.append(text)
    return {'ipv4': v4, 'ipv6': v6}


def default_route_ifaces():
    result = set()
    for family in ('-4', '-6'):
        for r in run_json(['ip', '-j', family, 'route', 'show', 'default']):
            if r.get('dev'):
                result.add(r['dev'])
    return result


def physical_interfaces():
    result = set()
    base = Path('/sys/class/net')
    if not base.exists():
        return result
    for entry in base.iterdir():
        try:
            if (entry / 'device').exists():
                result.add(entry.name)
        except Exception:
            pass
    return result


def _runtime_address_map():
    """Read addresses for all interfaces with one iproute2 invocation.

    Older PRM builds called `ip -j address show dev <iface>` once per interface.
    On hosts with several bridges/VLANs/WireGuard interfaces that dominated page
    load time.  A single bulk snapshot is both faster and internally consistent.
    """
    result = {}
    for row in run_json(['ip', '-j', 'address', 'show']):
        name = str(row.get('ifname') or '')
        if not name:
            continue
        v4, v6 = [], []
        for ai in row.get('addr_info', []):
            local = ai.get('local')
            prefix = ai.get('prefixlen')
            scope = ai.get('scope')
            if not local or scope == 'host':
                continue
            text = f'{local}/{prefix}' if prefix is not None else local
            if ai.get('family') == 'inet':
                v4.append(text)
            elif ai.get('family') == 'inet6' and not str(local).lower().startswith('fe80:'):
                v6.append(text)
        result[name] = {'ipv4': v4, 'ipv6': v6}
    return result


def _runtime_link_state_map():
    """Read operational state for all interfaces with one iproute2 invocation."""
    result = {}
    for row in run_json(['ip', '-j', 'link', 'show']):
        name = str(row.get('ifname') or '')
        if not name:
            continue
        oper = str(row.get('operstate') or '').upper()
        flags = {str(x).upper() for x in (row.get('flags') or [])}
        if oper == 'UP':
            state = 'UP'
        elif oper == 'UNKNOWN' and 'UP' in flags:
            state = 'UP'
        elif oper:
            state = oper
        else:
            state = 'UP' if 'UP' in flags else 'DOWN'
        result[name] = state
    return result


def _configured_cidr(item, family=4):
    if family == 4:
        if item.get('cidr'):
            return item['cidr']
        if item.get('address') and item.get('netmask'):
            mask = item['netmask']
            try:
                prefix = ipaddress.IPv4Network(f'0.0.0.0/{mask}').prefixlen if '.' in str(mask) else int(mask)
            except Exception:
                prefix = mask
            return f"{item['address']}/{prefix}"
    else:
        if item.get('cidr6'):
            return item['cidr6']
        if item.get('address6') and item.get('netmask6') is not None:
            return f"{item['address6']}/{item['netmask6']}"
    return None


def _bridge_membership(rows):
    membership = {}
    for x in rows:
        ports = str(x.get('bridge_ports') or '').split()
        for p in ports:
            membership[p] = x.get('iface')
    return membership


def _parse_interfaces_file(path):
    """Parse the subset of ifupdown syntax Proxmox uses for node networking.

    This is intentionally a read-only fallback. Proxmox/pvesh remains the writer.
    It lets PRM show active interfaces even when Proxmox has a staged
    interfaces.new which hides an interface that is only pending deletion.
    """
    path = Path(path)
    result = {}
    if not path.exists():
        return result
    current = None
    family = None
    autostart = set()
    try:
        lines = path.read_text(errors='replace').splitlines()
    except Exception:
        return result
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith('#') or line.startswith('source'):
            continue
        m = re.match(r'^(?:auto|allow-hotplug)\s+(.+)$', line)
        if m:
            autostart.update(m.group(1).split())
            continue
        m = re.match(r'^iface\s+(\S+)\s+(inet6?|inet)\s+(\S+)', line)
        if m:
            name, family, method = m.groups()
            item = result.setdefault(name, {'iface': name})
            if family == 'inet':
                item['method'] = method
            else:
                item['method6'] = method
            current = name
            continue
        if current is None or not (raw.startswith(' ') or raw.startswith('\t')):
            continue
        parts = line.split(None, 1)
        key = parts[0]
        value = parts[1].strip() if len(parts) > 1 else ''
        item = result[current]
        if key == 'address':
            if family == 'inet':
                if '/' in value:
                    item['cidr'] = value
                else:
                    item['address'] = value
            else:
                if '/' in value:
                    item['cidr6'] = value
                else:
                    item['address6'] = value
        elif key == 'netmask':
            item['netmask' if family == 'inet' else 'netmask6'] = value
        elif key == 'gateway':
            item['gateway' if family == 'inet' else 'gateway6'] = value
        elif key == 'bridge-ports':
            item['bridge_ports'] = '' if value.lower() == 'none' else value
        elif key == 'bridge-vlan-aware':
            item['bridge_vlan_aware'] = value.lower() in ('yes', 'on', '1', 'true')
        elif key == 'bridge-stp':
            item['bridge_stp'] = value
        elif key == 'bridge-fd':
            item['bridge_fd'] = value
        elif key == 'bond-slaves':
            item['slaves'] = value
        elif key == 'bond-mode':
            item['bond_mode'] = value
        elif key == 'bond-primary':
            item['bond-primary'] = value
        elif key == 'bond-xmit-hash-policy':
            item['bond_xmit_hash_policy'] = value
        elif key == 'vlan-raw-device':
            item['vlan-raw-device'] = value
        elif key == 'vlan-id':
            try: item['vlan-id'] = int(value)
            except Exception: item['vlan-id'] = value
        elif key == 'mtu':
            item['mtu'] = value
    phys = physical_interfaces()
    for name, item in result.items():
        item['autostart'] = 1 if name in autostart else 0
        if name in phys:
            item.setdefault('type', 'eth')
        elif 'bridge_ports' in item or name.startswith('vmbr'):
            item.setdefault('type', 'bridge')
        elif 'slaves' in item or name.startswith('bond'):
            item.setdefault('type', 'bond')
        elif 'vlan-id' in item or 'vlan-raw-device' in item or re.search(r'\.\d+$', name):
            item.setdefault('type', 'vlan')
        else:
            item.setdefault('type', 'unknown')
    return result


def _pending_change_map():
    active_path = Path('/etc/network/interfaces')
    staged_path = Path('/etc/network/interfaces.new')
    if not staged_path.exists():
        return {}
    try:
        if active_path.exists() and active_path.read_bytes() == staged_path.read_bytes():
            return {}
    except Exception:
        pass
    active = _parse_interfaces_file(active_path)
    staged = _parse_interfaces_file(staged_path)
    changes = {}
    for name in sorted(set(active) | set(staged), key=natural_key):
        if name not in active:
            changes[name] = 'add'
        elif name not in staged:
            changes[name] = 'delete'
        elif active[name] != staged[name]:
            changes[name] = 'edit'
    return changes


def pending_network_status():
    changes = _pending_change_map()
    return {
        'has_pending': bool(changes),
        'changes': [{'iface': k, 'action': v} for k, v in sorted(changes.items(), key=lambda kv: natural_key(kv[0]))],
    }


def _api_interfaces_uncached():
    # pvesh follows Proxmox' current configuration view, which may be the staged
    # interfaces.new. Merge that with the ACTIVE interfaces file so pending
    # deletions do not disappear from PRM before they are actually applied.
    try:
        pve_rows = pvesh_json(['get', f'/nodes/{node_name()}/network']) or []
    except Exception:
        pve_rows = []
    active_map = _parse_interfaces_file('/etc/network/interfaces')
    staged_map = _parse_interfaces_file('/etc/network/interfaces.new')
    pending = _pending_change_map()

    merged = {str(x.get('iface')): dict(x) for x in pve_rows if x.get('iface')}
    for name, item in active_map.items():
        if name not in merged:
            merged[name] = dict(item)
            merged[name]['config_source'] = 'active'
    for name, item in staged_map.items():
        if name not in merged:
            merged[name] = dict(item)
            merged[name]['config_source'] = 'pending'

    # Physical ports may exist without their own iface stanza. Include them too.
    phys = physical_interfaces()
    for name in phys:
        merged.setdefault(name, {'iface': name, 'type': 'eth', 'config_source': 'runtime'})

    rows = list(merged.values())
    membership = _bridge_membership(rows)
    defaults = default_route_ifaces()
    # Bulk runtime snapshots avoid two subprocesses per interface.
    address_map = _runtime_address_map()
    state_map = _runtime_link_state_map()
    for item in rows:
        iface = str(item.get('iface') or '')
        runtime_exists = iface in state_map or bool(iface and Path(f'/sys/class/net/{iface}').exists())
        runtime = address_map.get(iface, {'ipv4': [], 'ipv6': []}) if runtime_exists else {'ipv4': [], 'ipv6': []}
        item['rx_bytes'] = read_counter(iface, 'rx_bytes')
        item['tx_bytes'] = read_counter(iface, 'tx_bytes')
        item['link_state'] = state_map.get(iface, 'NOT PRESENT') if runtime_exists else 'NOT PRESENT'
        item['runtime_exists'] = runtime_exists
        item['runtime_ipv4'] = runtime['ipv4']
        item['runtime_ipv6'] = runtime['ipv6']
        item['configured_ipv4'] = _configured_cidr(item, 4)
        item['configured_ipv6'] = _configured_cidr(item, 6)
        item['dhcp4'] = str(item.get('method') or '').lower() == 'dhcp'
        mode6 = _effective_ipv6_mode(iface, item)
        item['ipv6_mode'] = mode6
        item['dhcp6'] = mode6 == 'dhcpv6'
        item['auto6'] = mode6 == 'slaac'
        if not item['dhcp4'] and not item['configured_ipv4'] and runtime['ipv4']:
            item['dhcp4_detected'] = True
        else:
            item['dhcp4_detected'] = False
        item['parent_bridge'] = membership.get(iface)
        item['is_physical'] = iface in phys or item.get('type') == 'eth'
        item['is_default_route'] = iface in defaults
        item['pending_action'] = pending.get(iface)
    rows.sort(key=lambda x: natural_key(x.get('iface')))
    return rows

def _invalidate_fast_caches():
    """Invalidate short-lived read caches after any state-changing API call."""
    with INTERFACES_CACHE_LOCK:
        INTERFACES_CACHE['ts'] = 0.0
        INTERFACES_CACHE['data'] = None
    with GUEST_CACHE_LOCK:
        GUEST_CACHE['ts'] = 0.0
        GUEST_CACHE['data'] = None


def api_interfaces():
    """Return the enriched interface list with a very short backend cache.

    Proxmox `pvesh get /nodes/<node>/network` is substantially slower than
    reading Linux runtime state. Many PRM pages request the same interface
    inventory at almost the same time. Reusing it for 1.5 seconds removes
    duplicate pvesh processes while keeping UI state effectively live.
    """
    now = time.monotonic()
    with INTERFACES_CACHE_LOCK:
        if INTERFACES_CACHE['data'] is not None and now - INTERFACES_CACHE['ts'] < INTERFACES_CACHE_TTL:
            return json.loads(json.dumps(INTERFACES_CACHE['data']))
    data = _api_interfaces_uncached()
    with INTERFACES_CACHE_LOCK:
        INTERFACES_CACHE['ts'] = time.monotonic()
        INTERFACES_CACHE['data'] = data
    return json.loads(json.dumps(data))


def _guest_counts_uncached():
    vm = lxc = 0
    try:
        resources = pvesh_json(['get', '/cluster/resources', '--type', 'vm']) or []
        for item in resources:
            typ = str(item.get('type') or '').lower()
            if typ == 'qemu':
                vm += 1
            elif typ == 'lxc':
                lxc += 1
    except Exception:
        vm = len(pvesh_json(['get', f'/nodes/{node_name()}/qemu']) or [])
        lxc = len(pvesh_json(['get', f'/nodes/{node_name()}/lxc']) or [])
    return {'vm': vm, 'lxc': lxc, 'total': vm + lxc}


def guest_counts():
    now = time.monotonic()
    with GUEST_CACHE_LOCK:
        if GUEST_CACHE['data'] is not None and now - GUEST_CACHE['ts'] < GUEST_CACHE_TTL:
            return dict(GUEST_CACHE['data'])
    data = _guest_counts_uncached()
    with GUEST_CACHE_LOCK:
        GUEST_CACHE['ts'] = time.monotonic()
        GUEST_CACHE['data'] = dict(data)
    return dict(data)


def _dashboard_live_ifaces():
    """Fast RX/TX snapshot for the Dashboard without pvesh/iproute subprocesses."""
    base = Path('/sys/class/net')
    rows = []
    if not base.exists():
        return rows
    hidden_prefixes = ('fwbr', 'fwpr', 'fwln', 'tap', 'veth')
    for entry in sorted(base.iterdir(), key=lambda x: natural_key(x.name)):
        name = entry.name
        if name == 'lo' or name.startswith(hidden_prefixes):
            continue
        rows.append({
            'iface': name,
            'rx_bytes': read_counter(name, 'rx_bytes'),
            'tx_bytes': read_counter(name, 'tx_bytes'),
        })
    return rows


def dashboard_live_data():
    return {'ts': time.time(), 'interfaces': _dashboard_live_ifaces()}


def wan_addresses(interface_rows=None):
    # Prefer interfaces carrying a default route. Fall back to physical interfaces.
    defaults = default_route_ifaces()
    candidates = defaults or physical_interfaces()
    rows = {x.get('iface'): x for x in (interface_rows if interface_rows is not None else api_interfaces())}
    ipv4, ipv6 = [], []
    for iface in sorted(candidates, key=natural_key):
        item = rows.get(iface, {})
        for addr in item.get('runtime_ipv4') or []:
            ipv4.append({'iface': iface, 'address': addr, 'dhcp': bool(item.get('dhcp4') or item.get('dhcp4_detected'))})
        for addr in item.get('runtime_ipv6') or []:
            ipv6.append({'iface': iface, 'address': addr, 'dhcp': bool(item.get('dhcp6')), 'auto': bool(item.get('auto6'))})
    return {'ipv4': ipv4, 'ipv6': ipv6}


def display_interfaces():
    """Return Proxmox interfaces plus runtime WireGuard interfaces for UI cards.

    Proxmox remains the source of truth for bridge/bond/VLAN configuration;
    WireGuard is PRM-owned and is merged only for display/monitoring.
    """
    rows = list(api_interfaces())
    names = {str(x.get('iface') or '') for x in rows}
    try:
        wg = wireguard_status()
        for item in wg.get('interfaces', []):
            name = str(item.get('name') or '')
            if not name or name in names:
                continue
            rt = item.get('runtime_addresses') or {'ipv4': [], 'ipv6': []}
            rows.append({
                'iface': name,
                'type': 'wireguard',
                'configured_ipv4': item.get('address4') or '',
                'configured_ipv6': item.get('address6') or '',
                'runtime_ipv4': rt.get('ipv4') or [],
                'runtime_ipv6': rt.get('ipv6') or [],
                'link_state': item.get('state') or ('UP' if item.get('runtime_exists') else 'DOWN'),
                'active': bool(item.get('runtime_exists') or item.get('state') == 'UP'),
                'runtime_exists': bool(item.get('runtime_exists') or item.get('state') == 'UP'),
                'rx_bytes': read_counter(name, 'rx_bytes'),
                'tx_bytes': read_counter(name, 'tx_bytes'),
                'comments': 'PRM WireGuard' if item.get('managed') else 'WireGuard',
                'wg_managed': bool(item.get('managed')),
                'listen_port': item.get('listen_port') or item.get('listen_port_runtime'),
            })
            names.add(name)
    except Exception:
        pass
    rows.sort(key=lambda x: natural_key(x.get('iface')))
    return rows



def cluster_info():
    """Return local Proxmox cluster metadata without making Dashboard cluster-wide.

    `/etc/pve/corosync.conf` exists only after a node is configured as a Corosync
    cluster member.  There is no single "cluster IP" in Proxmox; each node has
    its own Corosync link address.  PRM therefore displays the current node's
    ring0/link0 address next to the cluster name.
    """
    conf = Path('/etc/pve/corosync.conf')
    if not conf.exists():
        return {'joined': False, 'name': '', 'address': ''}
    try:
        text = conf.read_text(errors='replace')
    except Exception:
        return {'joined': True, 'name': 'Proxmox cluster', 'address': ''}

    name_match = re.search(r'(?m)^\s*cluster_name\s*:\s*([^\s#]+)', text)
    cluster_name = name_match.group(1).strip() if name_match else 'Proxmox cluster'
    current = node_name()
    address = ''
    for block in re.findall(r'node\s*\{(.*?)\}', text, flags=re.S):
        n = re.search(r'(?m)^\s*name\s*:\s*([^\s#]+)', block)
        if not n:
            continue
        node = n.group(1).strip()
        if node != current and node.split('.')[0] != current:
            continue
        a = re.search(r'(?m)^\s*(?:ring0_addr|link0_addr)\s*:\s*([^\s#]+)', block)
        if a:
            address = a.group(1).strip()
        break

    # Fallback for unusual corosync.conf layouts: pvecm status marks the local
    # membership address with "(local)".
    if not address:
        out = run(['pvecm', 'status'], allow_fail=True)
        m = re.search(r'(?m)^\s*\S+\s+\d+\s+(\S+)\s+\(local\)\s*$', out or '')
        if m:
            address = m.group(1).strip()
    return {'joined': True, 'name': cluster_name, 'address': address}

def dashboard_data():
    # Static/dashboard metadata is intentionally separated from 1-second traffic
    # samples. Run independent Dashboard metadata reads in parallel so the
    # initial Dashboard paints as soon as the slower of the two completes.
    with ThreadPoolExecutor(max_workers=3) as pool:
        if_future = pool.submit(api_interfaces)
        guest_future = pool.submit(guest_counts)
        cluster_future = pool.submit(cluster_info)
        pve_rows = if_future.result()
        guests = guest_future.result()
        cluster = cluster_future.result()
    rows = list(pve_rows)
    names = {str(x.get('iface') or '') for x in rows}
    managed_wg = {str(x.get('name') or ''): x for x in _wg_cfg().get('interfaces', []) if x.get('name')}
    addr_map = _runtime_address_map()
    state_map = _runtime_link_state_map()
    for name in sorted((set(addr_map) | set(state_map) | set(managed_wg)), key=natural_key):
        if not name.startswith('wg') or name in names:
            continue
        cfg = managed_wg.get(name, {})
        rt = addr_map.get(name, {'ipv4': [], 'ipv6': []})
        rows.append({
            'iface': name, 'type': 'wireguard',
            'configured_ipv4': cfg.get('address4') or '', 'configured_ipv6': cfg.get('address6') or '',
            'runtime_ipv4': rt.get('ipv4') or [], 'runtime_ipv6': rt.get('ipv6') or [],
            'link_state': state_map.get(name, 'DOWN'),
            'active': name in state_map, 'runtime_exists': name in state_map,
            'rx_bytes': read_counter(name, 'rx_bytes'), 'tx_bytes': read_counter(name, 'tx_bytes'),
            'comments': 'PRM WireGuard' if name in managed_wg else 'WireGuard',
            'wg_managed': name in managed_wg,
            'listen_port': cfg.get('listen_port') or '',
        })
        names.add(name)
    rows.sort(key=lambda x: natural_key(x.get('iface')))
    return {
        'interfaces': rows,
        'guests': guests,
        'wan': wan_addresses(pve_rows),
        'node': node_name(),
        'cluster': cluster,
        'version': VERSION,
    }


def network_rows():
    rows = []
    for x in api_interfaces():
        if x.get('type') not in ('bridge', 'vlan', 'bond'):
            continue
        rows.append({
            'iface': x.get('iface'), 'type': x.get('type'),
            'cidr': x.get('configured_ipv4'), 'cidr6': x.get('configured_ipv6'),
            'gateway': x.get('gateway'), 'gateway6': x.get('gateway6'),
            'ports': x.get('bridge_ports') or x.get('slaves'),
            'comments': x.get('comments'), 'active': bool(x.get('active')),
            'method': x.get('method'), 'method6': x.get('method6'),
        })
    # WireGuard is PRM-owned, so it is not present in the Proxmox network API.
    # Still expose its configured tunnel networks here so the Networks page
    # represents the complete router data plane.
    try:
        for x in wireguard_status().get('interfaces', []):
            rows.append({
                'iface': x.get('name'), 'type': 'wireguard',
                'cidr': x.get('address4') or '', 'cidr6': x.get('address6') or '',
                'gateway': '', 'gateway6': '',
                'ports': f"UDP {x.get('listen_port') or x.get('listen_port_runtime') or '—'}",
                'comments': 'PRM WireGuard', 'active': x.get('state') == 'UP',
                'method': 'static' if x.get('address4') else 'manual',
                'method6': 'static' if x.get('address6') else 'manual',
            })
    except Exception:
        pass
    rows.sort(key=lambda x: natural_key(x.get('iface')))
    return rows


def _load_json_file(path, default):
    try:
        if Path(path).exists():
            data = json.loads(Path(path).read_text())
            return data
    except Exception:
        pass
    return default


def _atomic_json_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)
    os.chmod(path, 0o600)


def _ipv6_active_modes():
    data = _load_json_file(IPV6_CLIENTS_CONFIG, {})
    return data if isinstance(data, dict) else {}


def _ipv6_pending_modes():
    data = _load_json_file(IPV6_PENDING_CONFIG, {})
    return data if isinstance(data, dict) else {}


def _logical_ipv6_mode(value):
    value = str(value or '').strip().lower()
    if value in ('auto', 'slaac'):
        return 'slaac'
    if value in ('dhcp', 'dhcpv6'):
        return 'dhcpv6'
    if value == 'static':
        return 'static'
    return 'disabled'


def _stage_ipv6_client_mode(iface, method6):
    pending = _ipv6_pending_modes()
    pending[str(iface)] = _logical_ipv6_mode(method6)
    _atomic_json_write(IPV6_PENDING_CONFIG, pending)


def _clear_ipv6_pending():
    try:
        IPV6_PENDING_CONFIG.unlink()
    except FileNotFoundError:
        pass


def _commit_ipv6_pending():
    pending = _ipv6_pending_modes()
    if not pending:
        return
    active = _ipv6_active_modes()
    for iface, mode in pending.items():
        mode = _logical_ipv6_mode(mode)
        if mode in ('slaac', 'dhcpv6', 'static'):
            # Keep Static as an explicit PRM IPv6 mode too.  This lets the
            # boot-time IPv6 policy enforce accept_ra=0/autoconf=0 and remove
            # any stale SLAAC state instead of treating Static like unmanaged.
            active[str(iface)] = mode
        else:
            active.pop(str(iface), None)
    _atomic_json_write(IPV6_CLIENTS_CONFIG, active)
    _clear_ipv6_pending()
    run(['/usr/lib/prm/prm-ipv6-sync'], timeout=30)


def _effective_ipv6_mode(iface, item=None):
    pending = _ipv6_pending_modes()
    if iface in pending:
        return _logical_ipv6_mode(pending.get(iface))
    active = _ipv6_active_modes()
    if iface in active:
        return _logical_ipv6_mode(active.get(iface))
    method = str((item or {}).get('method6') or '').lower()
    return _logical_ipv6_mode(method)


def _table_name(value):
    v = str(value if value is not None else 'main')
    return {'254': 'main', '255': 'local', '253': 'default'}.get(v, v)


def _route_cfg():
    data = _load_json_file(ROUTES_CONFIG, [])
    return data if isinstance(data, list) else []


def _route_key(x):
    metric = x.get('metric')
    try:
        metric = int(metric) if metric not in (None, '') else None
    except Exception:
        metric = None
    return (
        int(x.get('family') or 4), str(x.get('dst') or 'default'),
        str(x.get('gateway') or ''), str(x.get('dev') or ''), metric,
        _table_name(x.get('table') or 'main'),
    )


def _validate_route(data):
    family = int(data.get('family') or 4)
    if family not in (4, 6):
        raise ValueError('Route family must be IPv4 or IPv6')
    dst = str(data.get('dst') or '').strip()
    if not dst:
        raise ValueError('Destination is required')
    if dst != 'default':
        try:
            net = ipaddress.ip_network(dst, strict=False)
        except ValueError:
            raise ValueError('Destination must be a valid CIDR or default')
        if net.version != family:
            raise ValueError('Destination address family does not match the route family')
        dst = str(net)
    gateway = str(data.get('gateway') or '').strip()
    if gateway:
        try:
            ip = ipaddress.ip_address(gateway)
        except ValueError:
            raise ValueError('Gateway must be a valid IP address')
        if ip.version != family:
            raise ValueError('Gateway address family does not match the route family')
    dev = str(data.get('dev') or '').strip()
    if dev and not valid_iface(dev):
        raise ValueError('Invalid interface name')
    if dev and not Path(f'/sys/class/net/{dev}').exists():
        raise ValueError(f'Interface {dev} does not exist')
    if not gateway and not dev:
        raise ValueError('Specify a gateway, an interface, or both')
    metric = data.get('metric')
    if metric in ('', None):
        metric = None
    else:
        try:
            metric = int(metric)
        except Exception:
            raise ValueError('Metric must be an integer')
        if metric < 0 or metric > 4294967295:
            raise ValueError('Metric is out of range')
    table = str(data.get('table') or 'main').strip()
    if not re.fullmatch(r'(?:main|default|local|[1-9][0-9]{0,8})', table):
        raise ValueError('Route table must be main, default, local, or a numeric table ID')
    return {'family': family, 'dst': dst, 'gateway': gateway, 'dev': dev, 'metric': metric, 'table': table}


def _route_cmd(action, r):
    cmd = ['ip', f"-{int(r['family'])}", 'route', action, str(r['dst'])]
    if r.get('gateway'):
        cmd += ['via', str(r['gateway'])]
    if r.get('dev'):
        cmd += ['dev', str(r['dev'])]
    if r.get('metric') is not None:
        cmd += ['metric', str(r['metric'])]
    cmd += ['table', str(r.get('table') or 'main')]
    if action in ('add', 'replace'):
        cmd += ['proto', 'static']
    return cmd


def _runtime_routes():
    result = []
    for family, flag in ((4, '-4'), (6, '-6')):
        for r in run_json(['ip', '-j', flag, 'route', 'show', 'table', 'all']):
            result.append({
                'family': family, 'dst': r.get('dst', 'default'), 'gateway': r.get('gateway') or '',
                'dev': r.get('dev') or '', 'metric': r.get('metric'), 'table': _table_name(r.get('table', 'main')),
                'protocol': r.get('protocol'),
            })
    return result


def route_rows():
    managed = _route_cfg()
    by_key = {_route_key(x): x for x in managed}
    result = []
    seen_managed = set()
    for r in _runtime_routes():
        m = by_key.get(_route_key(r))
        row = dict(r)
        row['managed'] = bool(m)
        row['id'] = m.get('id') if m else None
        row['persistent'] = bool(m)
        if m:
            seen_managed.add(m.get('id'))
        result.append(row)
    # Keep configured routes visible even when their interface is temporarily down.
    for m in managed:
        if m.get('id') in seen_managed:
            continue
        row = dict(m)
        row.update({'managed': True, 'persistent': True, 'protocol': 'static', 'runtime_missing': True})
        result.append(row)
    return result


def _unmanaged_route_conflict(route, ignore_id=None):
    wanted = (route['family'], route['dst'], _table_name(route['table']))
    managed_ids = {x.get('id') for x in _route_cfg()}
    for r in route_rows():
        if (r.get('family'), r.get('dst'), _table_name(r.get('table'))) != wanted:
            continue
        if r.get('managed') and r.get('id') == ignore_id:
            continue
        if not r.get('managed') or r.get('id') in managed_ids:
            return r
    return None


def create_route(data):
    r = _validate_route(data)
    conflict = _unmanaged_route_conflict(r)
    if conflict:
        raise ValueError(f"A route for {r['dst']} already exists in table {r['table']}. PRM will not overwrite it.")
    r['id'] = uuid.uuid4().hex[:12]
    cfg = _route_cfg()
    run(_route_cmd('replace', r))
    cfg.append(r)
    _atomic_json_write(ROUTES_CONFIG, cfg)
    return {'ok': True, 'route': r, 'message': f"Route {r['dst']} added"}


def update_route(route_id, data):
    cfg = _route_cfg()
    old = next((x for x in cfg if x.get('id') == route_id), None)
    if not old:
        raise ValueError('PRM-managed route was not found')
    new = _validate_route(data)
    new['id'] = route_id
    conflict = _unmanaged_route_conflict(new, ignore_id=route_id)
    if conflict and not (conflict.get('managed') and conflict.get('id') == route_id):
        raise ValueError(f"A route for {new['dst']} already exists in table {new['table']}. PRM will not overwrite it.")
    run(_route_cmd('del', old), allow_fail=True)
    try:
        run(_route_cmd('replace', new))
    except Exception:
        run(_route_cmd('replace', old), allow_fail=True)
        raise
    cfg = [new if x.get('id') == route_id else x for x in cfg]
    _atomic_json_write(ROUTES_CONFIG, cfg)
    return {'ok': True, 'route': new, 'message': f"Route {new['dst']} updated"}


def delete_route(route_id):
    cfg = _route_cfg()
    old = next((x for x in cfg if x.get('id') == route_id), None)
    if not old:
        raise ValueError('PRM-managed route was not found')
    run(_route_cmd('del', old), allow_fail=True)
    cfg = [x for x in cfg if x.get('id') != route_id]
    _atomic_json_write(ROUTES_CONFIG, cfg)
    return {'ok': True, 'message': f"Route {old['dst']} deleted"}


def _pve_native_dhcp():
    zones = []
    vnets = []
    try:
        zones = pvesh_json(['get', '/cluster/sdn/zones']) or []
    except Exception:
        zones = []
    try:
        vnets = pvesh_json(['get', '/cluster/sdn/vnets']) or []
    except Exception:
        vnets = []
    zone_map = {str(z.get('zone') or z.get('id') or ''): z for z in zones}
    active = []
    for v in vnets:
        zone_name = str(v.get('zone') or '')
        zone = zone_map.get(zone_name, {})
        backend = zone.get('dhcp')
        if backend in (None, '', 0, '0', False, 'none'):
            continue
        active.append({'vnet': v.get('vnet') or v.get('id'), 'zone': zone_name, 'backend': str(backend)})
    services = []
    out = run(['systemctl', 'list-units', '--type=service', '--all', '--no-legend', '--plain', 'dnsmasq@*.service'], allow_fail=True)
    for line in out.splitlines():
        cols = line.split()
        if cols:
            services.append(cols[0])
    return {'zones': active, 'services': services}


def _dhcp_cfg():
    data = _load_json_file(DHCP_CONFIG, [])
    return data if isinstance(data, list) else []


def _dhcp_reservations():
    data = _load_json_file(DHCP_RESERVATIONS, [])
    return data if isinstance(data, list) else []


def _reservation_name(value):
    name = str(value or '').strip()
    if len(name) > 80:
        raise ValueError('Name must be 80 characters or fewer')
    if any(ord(ch) < 32 for ch in name):
        raise ValueError('Name contains unsupported control characters')
    return name


def _dnsmasq_hostname(value):
    # Reservation names are PRM labels first. Only safe DNS-style names are
    # also passed to dnsmasq as hostnames; labels with spaces/unicode remain
    # visible in PRM without risking an invalid dnsmasq configuration.
    name = str(value or '').strip()
    if not name or len(name) > 63:
        return ''
    if re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9._-]{0,61}[A-Za-z0-9])?', name):
        return name
    return ''


def _dhcp_reservation_lines(d, reservations=None):
    reservations = _dhcp_reservations() if reservations is None else reservations
    lines = []
    for r in reservations:
        if str(r.get('iface') or '') != str(d.get('iface') or ''):
            continue
        try:
            addr = ipaddress.ip_address(str(r.get('address') or ''))
        except ValueError:
            raise ValueError(f"Invalid stored static DHCP address: {r.get('address')}")
        ident = str(r.get('identifier') or '').strip()
        name = _dnsmasq_hostname(r.get('name'))
        if addr.version == 4:
            if not d.get('ipv4_enabled', True):
                raise ValueError(f'Static IPv4 reservation {addr} exists on {d["iface"]}; remove it before disabling DHCPv4')
            subnet = ipaddress.ip_network(d['subnet'], strict=False)
            if addr not in subnet:
                raise ValueError(f'Static IPv4 reservation {addr} is outside {subnet}')
            if not re.fullmatch(r'(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}', ident):
                raise ValueError(f'Static IPv4 reservation {addr} has no valid MAC address')
            parts = [ident.lower()]
            if name:
                parts.append(name)
            parts.append(str(addr))
            lines.append('dhcp-host=' + ','.join(parts))
        else:
            if str(d.get('ipv6_mode') or 'disabled') != 'dhcpv6':
                raise ValueError(f'Static IPv6 reservation {addr} exists on {d["iface"]}; DHCPv6 must stay enabled or the reservation must be removed')
            prefix = ipaddress.ip_network(d['ipv6_prefix'], strict=False)
            if addr not in prefix:
                raise ValueError(f'Static IPv6 reservation {addr} is outside {prefix}')
            if not ident:
                raise ValueError(f'Static IPv6 reservation {addr} has no DHCPv6 DUID/client-id')
            parts = [f'id:{ident}']
            if name:
                parts.append(name)
            parts.append(f'[{addr}]')
            lines.append('dhcp-host=' + ','.join(parts))
    return lines


def _dhcp_service_name(iface):
    if not re.fullmatch(r'[A-Za-z0-9_.-]+', iface):
        raise ValueError('Invalid DHCP interface name')
    return f'prm-dhcp@{iface}.service'


def _dhcp_conf_path(iface):
    return DHCP_DIR / f'{iface}.conf'


def _dhcp_lease_path(iface):
    return DHCP_DIR / f'{iface}.leases'


def _split_ip_list(raw, family):
    out = []
    for token in re.split(r'[ ,;]+', str(raw or '').strip()):
        if not token:
            continue
        ip = ipaddress.ip_address(token)
        if ip.version != family:
            raise ValueError(f'DNS server {token} is not IPv{family}')
        out.append(str(ip))
    return out


def _iface_ipv6_network(iface):
    row = next((x for x in api_interfaces() if x.get('iface') == iface), None) or {}
    candidates = []
    if row.get('configured_ipv6'):
        candidates.append(str(row['configured_ipv6']))
    candidates.extend(row.get('runtime_ipv6') or [])
    for value in candidates:
        try:
            i = ipaddress.IPv6Interface(value)
            return i.network
        except Exception:
            continue
    return None


def _validate_dhcp(data):
    iface = str(data.get('iface') or '').strip()
    if not valid_iface(iface) or not Path(f'/sys/class/net/{iface}').exists():
        raise ValueError('Select an existing interface')
    row = next((x for x in api_interfaces() if x.get('iface') == iface), None)
    if not row or row.get('is_physical'):
        raise ValueError('PRM DHCP can only be attached to a virtual interface')

    ipv4_enabled = bool(data.get('ipv4_enabled', True))
    ipv6_mode = str(data.get('ipv6_mode') or 'disabled').strip().lower()
    if ipv6_mode not in ('disabled', 'slaac', 'dhcpv6'):
        raise ValueError('IPv6 mode must be Disabled, SLAAC or DHCPv6')
    if not ipv4_enabled and ipv6_mode == 'disabled':
        raise ValueError('Enable DHCPv4 or select an IPv6 mode')

    result = {'iface': iface, 'ipv4_enabled': ipv4_enabled, 'ipv6_mode': ipv6_mode}
    lease = str(data.get('lease') or '12h').strip().lower()
    if not re.fullmatch(r'[1-9][0-9]*(?:m|h|d|w)', lease):
        raise ValueError('Lease must look like 30m, 12h, 1d or 1w')
    result['lease'] = lease

    if ipv4_enabled:
        subnet_s = str(data.get('subnet') or '').strip()
        try:
            subnet = ipaddress.ip_network(subnet_s, strict=False)
        except ValueError:
            raise ValueError('Subnet must be a valid IPv4 CIDR')
        if subnet.version != 4:
            raise ValueError('DHCPv4 subnet must be IPv4')
        try:
            start = ipaddress.ip_address(str(data.get('range_start') or '').strip())
            end = ipaddress.ip_address(str(data.get('range_end') or '').strip())
        except ValueError:
            raise ValueError('DHCPv4 range start/end must be valid IPv4 addresses')
        if start.version != 4 or end.version != 4 or start not in subnet or end not in subnet or int(start) > int(end):
            raise ValueError('DHCPv4 range must be ordered and inside the subnet')
        gateway_s = str(data.get('gateway') or '').strip()
        if gateway_s:
            gateway = ipaddress.ip_address(gateway_s)
            if gateway.version != 4 or gateway not in subnet:
                raise ValueError('Gateway must be an IPv4 address inside the subnet')
        result.update({
            'subnet': str(subnet), 'range_start': str(start), 'range_end': str(end),
            'gateway': gateway_s, 'dns': _split_ip_list(data.get('dns'), 4),
        })
    else:
        result.update({'subnet': '', 'range_start': '', 'range_end': '', 'gateway': '', 'dns': []})

    result.update({'ipv6_prefix': '', 'ipv6_range_start': '', 'ipv6_range_end': '', 'dns6': [], 'lease6': '', 'ra_default_route': False})
    if ipv6_mode != 'disabled':
        prefix_s = str(data.get('ipv6_prefix') or '').strip()
        if not prefix_s:
            auto_net = _iface_ipv6_network(iface)
            prefix_s = str(auto_net) if auto_net else ''
        try:
            prefix = ipaddress.ip_network(prefix_s, strict=False)
        except ValueError:
            raise ValueError('IPv6 prefix must be a valid IPv6 CIDR')
        if prefix.version != 6:
            raise ValueError('IPv6 prefix must be IPv6')
        if prefix.prefixlen != 64:
            raise ValueError('SLAAC/DHCPv6 prefix must be /64')
        iface_net = _iface_ipv6_network(iface)
        if not iface_net or not any(ipaddress.IPv6Address(str(a).split('/')[0]) in prefix for a in (row.get('runtime_ipv6') or []) if ':' in str(a)):
            configured = str(row.get('configured_ipv6') or '')
            try:
                configured_ok = bool(configured and ipaddress.IPv6Interface(configured).ip in prefix)
            except Exception:
                configured_ok = False
            if not configured_ok:
                router_ip = ipaddress.IPv6Address(int(prefix.network_address) + 1)
                raise ValueError(
                    f'{iface} needs a static IPv6 router address inside {prefix} before serving SLAAC/DHCPv6. '
                    f'Configure e.g. {router_ip}/{prefix.prefixlen} in Interfaces -> Edit -> Add IPv6 -> Static, apply it, then enable IPv6 DHCP.'
                )
        lease6 = str(data.get('lease6') or lease or '12h').strip().lower()
        if not re.fullmatch(r'[1-9][0-9]*(?:m|h|d|w)', lease6):
            raise ValueError('IPv6 lease/RA lifetime must look like 30m, 12h, 1d or 1w')
        result.update({'ipv6_prefix': str(prefix), 'dns6': _split_ip_list(data.get('dns6'), 6), 'lease6': lease6, 'ra_default_route': bool(data.get('ra_default_route', True))})
        if ipv6_mode == 'dhcpv6':
            try:
                start6 = ipaddress.ip_address(str(data.get('ipv6_range_start') or '').strip())
                end6 = ipaddress.ip_address(str(data.get('ipv6_range_end') or '').strip())
            except ValueError:
                raise ValueError('DHCPv6 range start/end must be valid IPv6 addresses')
            if start6.version != 6 or end6.version != 6 or start6 not in prefix or end6 not in prefix or int(start6) > int(end6):
                raise ValueError('DHCPv6 range must be ordered and inside the IPv6 prefix')
            result['ipv6_range_start'] = str(start6)
            result['ipv6_range_end'] = str(end6)

    native = _pve_native_dhcp()
    if any(str(x.get('vnet')) == iface for x in native['zones']):
        raise ValueError(f'{iface} is already served by native Proxmox SDN DHCP; PRM will not create a duplicate DHCP/RA server')
    return result


def _write_dhcp_conf(d, reservations=None):
    DHCP_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(DHCP_DIR, 0o700)
    lines = [
        'port=0',
        f"interface={d['iface']}",
        'bind-dynamic',
        f"dhcp-leasefile={_dhcp_lease_path(d['iface'])}",
        'log-dhcp',
    ]
    if d.get('ipv4_enabled', True):
        net = ipaddress.ip_network(d['subnet'])
        lines += [
            'dhcp-authoritative',
            f"dhcp-range={d['range_start']},{d['range_end']},{net.netmask},{d['lease']}",
        ]
        if d.get('gateway'):
            lines.append(f"dhcp-option=option:router,{d['gateway']}")
        if d.get('dns'):
            lines.append('dhcp-option=option:dns-server,' + ','.join(d['dns']))

    mode6 = d.get('ipv6_mode', 'disabled')
    if mode6 != 'disabled':
        prefix = ipaddress.ip_network(d['ipv6_prefix'])
        lines.append('enable-ra')
        # IPv6 default gateways are learned from Router Advertisements, not
        # DHCPv6. In DHCPv6 mode PRM deliberately enables SLAAC too: dnsmasq
        # advertises the prefix with the A bit set while continuing to allocate
        # stateful DHCPv6 IA_NA addresses. This gives router/client platforms both
        # address mechanisms while RA remains authoritative for the default route.
        # A zero router lifetime keeps RA/DHCPv6/SLAAC active but suppresses the route.
        if not d.get('ra_default_route', True):
            lines.append(f"ra-param={d['iface']},0,0")
        if mode6 == 'slaac':
            lines.append(f"dhcp-range={prefix.network_address},ra-only,{prefix.prefixlen},{d['lease6']}")
        elif mode6 == 'dhcpv6':
            lines.append(f"dhcp-range={d['ipv6_range_start']},{d['ipv6_range_end']},slaac,{prefix.prefixlen},{d['lease6']}")
        if d.get('dns6'):
            wrapped = ','.join(f'[{x}]' for x in d['dns6'])
            lines.append('dhcp-option=option6:dns-server,' + wrapped)

    reservation_lines = _dhcp_reservation_lines(d, reservations)
    if reservation_lines:
        lines.append('# PRM static DHCP reservations')
        lines.extend(reservation_lines)

    path = _dhcp_conf_path(d['iface'])
    path.write_text('\n'.join(lines) + '\n')
    os.chmod(path, 0o600)
    run(['/usr/sbin/dnsmasq', '--test', f'--conf-file={path}'])


def _parse_dnsmasq_leases(path, iface='', source='PRM'):
    leases = []
    if not path.exists():
        return leases
    try:
        for line in path.read_text(errors='replace').splitlines():
            cols = line.split()
            if not cols or cols[0] == 'duid' or len(cols) < 4:
                continue
            try:
                ip = ipaddress.ip_address(cols[2])
            except Exception:
                continue
            row = {
                'iface': iface, 'address': str(ip), 'family': 'IPv4' if ip.version == 4 else 'IPv6',
                'type': 'DHCPv4' if ip.version == 4 else 'DHCPv6', 'expires': cols[0],
                'hostname': '' if cols[3] == '*' else cols[3], 'source': source,
                'client_id': '', 'mac': '', 'state': 'LEASED',
            }
            if ip.version == 4:
                row['mac'] = cols[1]
                row['client_id'] = cols[4] if len(cols) > 4 and cols[4] != '*' else ''
            else:
                row['iaid'] = cols[1]
                row['client_id'] = cols[4] if len(cols) > 4 and cols[4] != '*' else ''
            leases.append(row)
    except Exception:
        pass
    return leases


def _dhcp_leases(iface):
    return _parse_dnsmasq_leases(_dhcp_lease_path(iface), iface=iface, source='PRM')


def _managed_dhcp_record(iface):
    return next((dict(x) for x in _dhcp_cfg() if str(x.get('iface') or '') == str(iface)), None)


def _reservation_identifier_for_lease(lease, family):
    if int(family) == 4:
        ident = str(lease.get('mac') or '').strip().lower()
        if not re.fullmatch(r'(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}', ident):
            raise ValueError('This IPv4 lease has no usable MAC address for a static reservation')
        return ident, 'mac'
    ident = str(lease.get('client_id') or '').strip()
    if not ident:
        raise ValueError('This DHCPv6 lease has no DUID/client-id; it cannot be pinned safely')
    return ident, 'duid'


def _local_ip_owner(address):
    """Return interface name when address is already configured locally."""
    target = str(address)
    for iface, fams in _runtime_address_map().items():
        for value in (fams.get('ipv4') or []) + (fams.get('ipv6') or []):
            if str(value).split('/', 1)[0] == target:
                return iface
    return ''


def _probe_address_in_use(iface, addr):
    """Best-effort L2 duplicate check for a proposed fixed DHCP address.

    IPv4 uses arping DAD: exit 0 means no reply/duplicate was found. IPv6 uses
    Neighbor Discovery: exit 0 means a node answered for that on-link address.
    Lease/reservation/local-address checks are authoritative and run separately;
    this probe catches devices that are online but not present in dnsmasq state.
    """
    try:
        if addr.version == 4 and shutil.which('arping'):
            p = subprocess.run(
                ['arping', '-D', '-q', '-c', '2', '-w', '2', '-I', iface, str(addr)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4,
            )
            # iputils arping -D returns 0 when DAD succeeds (no replies).
            return p.returncode != 0
        if addr.version == 6 and shutil.which('ndisc6'):
            p = subprocess.run(
                ['ndisc6', '-q', '-r', '2', '-w', '500', str(addr), iface],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4,
            )
            # ndisc6 returns 0 when a neighbour advertisement is received.
            return p.returncode == 0
    except Exception:
        pass
    return False


def _validate_reservation_target(d, iface, lease, target, ident, reservations):
    family = target.version
    if family == 4:
        if not d.get('ipv4_enabled', True):
            raise ValueError('DHCPv4 is not enabled on this interface')
        network = ipaddress.ip_network(d['subnet'], strict=False)
        if target not in network:
            raise ValueError(f'Static IPv4 address must be inside {network}')
        if target in (network.network_address, network.broadcast_address):
            raise ValueError('Network and broadcast addresses cannot be used as static DHCP addresses')
        gateway = str(d.get('gateway') or '').strip()
        if gateway and str(target) == gateway:
            raise ValueError(f'{target} is the configured gateway and cannot be assigned to a DHCP client')
    else:
        if str(d.get('ipv6_mode') or 'disabled') != 'dhcpv6':
            raise ValueError('Static IPv6 reservations require DHCPv6 mode')
        network = ipaddress.ip_network(d['ipv6_prefix'], strict=False)
        if target not in network:
            raise ValueError(f'Static IPv6 address must be inside {network}')
        if target == network.network_address:
            raise ValueError('The IPv6 subnet-router anycast/prefix address cannot be used as a DHCPv6 reservation')

    owner = _local_ip_owner(target)
    if owner:
        raise ValueError(f'{target} is already configured on local interface {owner}')

    for r in reservations:
        if str(r.get('iface') or '') != iface or int(r.get('family') or 0) != family:
            continue
        if str(r.get('address') or '') == str(target):
            if str(r.get('identifier') or '') != ident:
                raise ValueError(f'{target} is already reserved for another client')
        if str(r.get('identifier') or '') == ident:
            raise ValueError(f"This client already has static reservation {r.get('address')} on {iface}")

    # dnsmasq active lease collision. Re-using the client's current dynamic
    # address is valid; the same address leased to another identifier is not.
    for other in _dhcp_leases(iface):
        if str(other.get('address') or '') != str(target):
            continue
        try:
            other_ident, _ = _reservation_identifier_for_lease(other, family)
        except ValueError:
            other_ident = ''
        if other_ident and other_ident != ident:
            raise ValueError(f'{target} is currently leased to another DHCP client')

    current = str(lease.get('address') or '')
    if str(target) != current and _probe_address_in_use(iface, target):
        raise ValueError(f'{target} appears to be in use by another device on {iface}')


def _apply_dhcp_reservations(iface, reservations):
    d = _managed_dhcp_record(iface)
    if not d:
        raise ValueError('PRM-managed DHCP/RA configuration was not found')
    old_conf = _dhcp_conf_path(iface).read_text(errors='replace') if _dhcp_conf_path(iface).exists() else None
    try:
        _write_dhcp_conf(d, reservations=reservations)
        run(['systemctl', 'restart', _dhcp_service_name(iface)])
        _atomic_json_write(DHCP_RESERVATIONS, reservations)
    except Exception:
        if old_conf is None:
            _dhcp_conf_path(iface).unlink(missing_ok=True)
        else:
            _dhcp_conf_path(iface).write_text(old_conf)
            os.chmod(_dhcp_conf_path(iface), 0o600)
            run(['systemctl', 'restart', _dhcp_service_name(iface)], allow_fail=True)
        raise


def create_dhcp_reservation(data):
    iface = str(data.get('iface') or '').strip()
    lease_address = str(data.get('lease_address') or data.get('address') or '').strip()
    requested_address = str(data.get('address') or lease_address).strip()
    name = _reservation_name(data.get('name'))
    d = _managed_dhcp_record(iface)
    if not d:
        raise ValueError('Static reservations are supported only for PRM-managed DHCP services')
    try:
        lease_addr = ipaddress.ip_address(lease_address)
        target = ipaddress.ip_address(requested_address)
    except ValueError:
        raise ValueError('Static IP address is invalid')
    if target.version != lease_addr.version:
        raise ValueError('Static IP address must use the same IP family as the current lease')
    lease = next((x for x in _dhcp_leases(iface) if str(x.get('address')) == str(lease_addr)), None)
    if not lease:
        raise ValueError('The DHCP lease is no longer active; refresh the Leases table and try again')

    ident, ident_type = _reservation_identifier_for_lease(lease, target.version)
    reservations = _dhcp_reservations()
    _validate_reservation_target(d, iface, lease, target, ident, reservations)

    record = {
        'id': uuid.uuid4().hex[:12], 'iface': iface, 'family': target.version, 'address': str(target),
        'identifier_type': ident_type, 'identifier': ident, 'name': name, 'created_at': int(time.time()),
    }
    new_reservations = reservations + [record]
    _apply_dhcp_reservations(iface, new_reservations)
    moved = str(target) != str(lease_addr)
    suffix = f' (current lease was {lease_addr})' if moved else ''
    return {'ok': True, 'id': record['id'], 'message': f'{target} is now a static DHCP reservation on {iface}{suffix}'}


def delete_dhcp_reservation(reservation_id):
    reservations = _dhcp_reservations()
    record = next((r for r in reservations if str(r.get('id')) == str(reservation_id)), None)
    if not record:
        raise ValueError('Static DHCP reservation was not found')
    iface = str(record.get('iface') or '')
    new_reservations = [r for r in reservations if str(r.get('id')) != str(reservation_id)]
    _apply_dhcp_reservations(iface, new_reservations)
    return {
        'ok': True,
        'message': f"Static reservation {record.get('address')} removed. The client returns to dynamic allocation on its next DHCP cycle.",
    }


def _annotate_dhcp_leases(leases, reservations):
    by_key = {(str(r.get('iface') or ''), str(r.get('address') or '')): r for r in reservations}
    seen = set()
    out = []
    for lease in leases:
        row = dict(lease)
        key = (str(row.get('iface') or ''), str(row.get('address') or ''))
        r = by_key.get(key)
        if r:
            seen.add(key)
            row['static'] = True
            row['reservation_id'] = r.get('id')
            row['reservation_name'] = r.get('name') or ''
        else:
            row['static'] = False
            row['reservation_id'] = ''
            row['reservation_name'] = ''
        row['can_static'] = row.get('source') == 'PRM' and row.get('type') in ('DHCPv4', 'DHCPv6') and bool(row.get('mac') if row.get('type') == 'DHCPv4' else row.get('client_id'))
        out.append(row)
    for r in reservations:
        key = (str(r.get('iface') or ''), str(r.get('address') or ''))
        if key in seen:
            continue
        family = int(r.get('family') or 4)
        out.append({
            'iface': r.get('iface') or '', 'address': r.get('address') or '',
            'family': 'IPv4' if family == 4 else 'IPv6', 'type': 'DHCPv4' if family == 4 else 'DHCPv6',
            'expires': 'static', 'hostname': '', 'reservation_name': r.get('name') or '',
            'source': 'PRM reservation', 'client_id': r.get('identifier') if family == 6 else '',
            'mac': r.get('identifier') if family == 4 else '', 'state': 'STATIC', 'static': True,
            'reservation_id': r.get('id') or '', 'can_static': False,
        })
    return out


def _slaac_neighbors(iface, prefix_s):
    rows = []
    try:
        prefix = ipaddress.ip_network(prefix_s, strict=False)
    except Exception:
        return rows
    text = run(['ip', '-6', 'neigh', 'show', 'dev', iface], allow_fail=True)
    seen = set()
    for line in text.splitlines():
        cols = line.split()
        if not cols:
            continue
        try:
            addr = ipaddress.IPv6Address(cols[0])
        except Exception:
            continue
        if addr.is_link_local or addr not in prefix or str(addr) in seen:
            continue
        seen.add(str(addr))
        mac = ''
        state = cols[-1].upper() if cols else ''
        if 'lladdr' in cols:
            i = cols.index('lladdr')
            if i + 1 < len(cols):
                mac = cols[i + 1]
        rows.append({
            'iface': iface, 'address': str(addr), 'family': 'IPv6', 'type': 'SLAAC',
            'expires': '', 'hostname': '', 'source': 'PRM RA / NDP', 'client_id': '',
            'mac': mac, 'state': state or 'OBSERVED',
        })
    return rows


def _native_dnsmasq_leases(native):
    rows = []
    base = Path('/var/lib/misc')
    if not base.exists():
        return rows
    for path in base.glob('dnsmasq.*.leases'):
        zone = path.name[len('dnsmasq.'):-len('.leases')]
        rows.extend(_parse_dnsmasq_leases(path, iface=zone, source='Proxmox SDN'))
    return rows


def create_dhcp(data):
    d = _validate_dhcp(data)
    cfg = _dhcp_cfg()
    if any(x.get('iface') == d['iface'] for x in cfg):
        raise ValueError(f"DHCP/RA on {d['iface']} is already managed by PRM")
    if not shutil.which('dnsmasq'):
        raise ValueError('dnsmasq-base is not installed')
    d['id'] = d['iface']
    _write_dhcp_conf(d)
    service = _dhcp_service_name(d['iface'])
    try:
        run(['systemctl', 'enable', '--now', service])
    except Exception as e:
        run(['systemctl', 'disable', '--now', service], allow_fail=True)
        raise ValueError(f'Unable to start DHCP/RA on {d["iface"]}: {e}')
    cfg.append(d)
    _atomic_json_write(DHCP_CONFIG, cfg)
    fw_warning = ''
    try:
        sync_dhcp_firewall_rules(cfg)
    except Exception as e:
        fw_warning = f' Firewall rule sync warning: {e}'
    return {'ok': True, 'message': f"DHCP/IPv6 service enabled on {d['iface']}. Automatic Proxmox firewall permits synchronized." + fw_warning}


def update_dhcp(iface, data):
    cfg = _dhcp_cfg()
    old = next((x for x in cfg if x.get('iface') == iface), None)
    if not old:
        raise ValueError('PRM-managed DHCP/RA configuration was not found')
    body = dict(data)
    body['iface'] = iface
    d = _validate_dhcp(body)
    d['id'] = iface
    _write_dhcp_conf(d)
    run(['systemctl', 'restart', _dhcp_service_name(iface)])
    cfg = [d if x.get('iface') == iface else x for x in cfg]
    _atomic_json_write(DHCP_CONFIG, cfg)
    fw_warning = ''
    try:
        sync_dhcp_firewall_rules(cfg)
    except Exception as e:
        fw_warning = f' Firewall rule sync warning: {e}'
    return {'ok': True, 'message': f'DHCP/IPv6 service on {iface} updated. Automatic Proxmox firewall permits synchronized.' + fw_warning}


def sync_dhcp_runtime():
    """Regenerate saved PRM dnsmasq configs and restart only active instances.

    Used by package upgrades so an existing DHCPv6 service immediately gains the
    current RA/SLAAC behaviour without requiring the administrator to edit/save it.
    This touches only PRM-owned files under /var/lib/prm/dhcp.
    """
    cfg = _dhcp_cfg()
    reservations = _dhcp_reservations()
    failed = []
    for d in cfg:
        iface = str(d.get('iface') or '').strip()
        if not iface:
            continue
        try:
            _write_dhcp_conf(d, reservations=reservations)
            run(['systemctl', 'try-restart', _dhcp_service_name(iface)], allow_fail=True)
        except Exception as e:
            failed.append(f'{iface}: {e}')
    try:
        sync_dhcp_firewall_rules(cfg)
    except Exception as e:
        failed.append(f'firewall: {e}')
    if failed:
        print('PRM DHCP sync warning: ' + '; '.join(failed), file=sys.stderr)
        return 1
    return 0


def delete_dhcp(iface):
    cfg = _dhcp_cfg()
    old = next((x for x in cfg if x.get('iface') == iface), None)
    if not old:
        raise ValueError('PRM-managed DHCP/RA configuration was not found')
    run(['systemctl', 'disable', '--now', _dhcp_service_name(iface)], allow_fail=True)
    _dhcp_conf_path(iface).unlink(missing_ok=True)
    _dhcp_lease_path(iface).unlink(missing_ok=True)
    reservations = [r for r in _dhcp_reservations() if str(r.get('iface') or '') != str(iface)]
    _atomic_json_write(DHCP_RESERVATIONS, reservations)
    cfg = [x for x in cfg if x.get('iface') != iface]
    _atomic_json_write(DHCP_CONFIG, cfg)
    fw_warning = ''
    try:
        sync_dhcp_firewall_rules(cfg)
    except Exception as e:
        fw_warning = f' Firewall rule sync warning: {e}'
    return {'ok': True, 'message': f'DHCP/IPv6 service on {iface} deleted. Automatic Proxmox firewall permits synchronized.' + fw_warning}


def dhcp_status():
    native = _pve_native_dhcp()
    reservations = _dhcp_reservations()
    managed = []
    all_leases = []
    for original in _dhcp_cfg():
        x = dict(original)
        # Backward compatibility with v0.2.6 DHCPv4-only records.
        x.setdefault('ipv4_enabled', True)
        x.setdefault('ipv6_mode', 'disabled')
        x.setdefault('ipv6_prefix', '')
        x.setdefault('ipv6_range_start', '')
        x.setdefault('ipv6_range_end', '')
        x.setdefault('dns6', [])
        x.setdefault('lease6', x.get('lease') or '12h')
        x.setdefault('ra_default_route', True)
        service = _dhcp_service_name(str(x.get('iface')))
        x['service'] = service
        x['state'] = run(['systemctl', 'is-active', service], allow_fail=True).strip() or 'inactive'
        x['leases'] = _dhcp_leases(str(x.get('iface')))
        if x.get('ipv6_mode') in ('slaac', 'dhcpv6') and x.get('ipv6_prefix'):
            x['slaac_observed'] = _slaac_neighbors(str(x.get('iface')), x.get('ipv6_prefix'))
        else:
            x['slaac_observed'] = []
        all_leases.extend(x['leases'])
        all_leases.extend(x['slaac_observed'])
        managed.append(x)
    all_leases.extend(_native_dnsmasq_leases(native))
    all_leases = _annotate_dhcp_leases(all_leases, reservations)
    all_leases.sort(key=lambda x: (natural_key(x.get('iface')), x.get('family', ''), x.get('address', '')))
    clients = []
    for x in api_interfaces():
        if x.get('dhcp4') or x.get('dhcp4_detected') or x.get('dhcp6'):
            clients.append({
                'iface': x.get('iface'), 'ipv4': x.get('runtime_ipv4'), 'ipv6': x.get('runtime_ipv6'),
                'dhcp4': bool(x.get('dhcp4') or x.get('dhcp4_detected')), 'dhcp6': bool(x.get('dhcp6')),
            })
    return {
        'backend': {'name': 'dnsmasq-base', 'available': bool(shutil.which('dnsmasq')), 'mode': 'per-interface dual-stack'},
        'native_pve': native, 'managed': managed, 'clients': clients, 'leases': all_leases,
    }

NAT_CONFIG = STATE / 'nat.json'
PRM_SYSCTL = Path('/etc/sysctl.d/99-prm-router.conf')


def _nat_cfg():
    data = _load_json_file(NAT_CONFIG, [])
    if not isinstance(data, list):
        return []
    # v0.4.2 introduces explicit source/destination interfaces.  Normalize
    # older rules in memory so upgrades keep their original behaviour.
    out = []
    for raw in data:
        x = dict(raw) if isinstance(raw, dict) else {}
        if not x:
            continue
        if 'source_ifaces' not in x:
            kind = str(x.get('kind') or '').lower()
            if kind == 'snat':
                x['source_ifaces'] = list(x.get('internal_ifaces') or ['*'])
                x['destination_iface'] = x.get('external_iface') or ''
            else:
                incoming = x.get('external_iface') or ''
                x['source_ifaces'] = [incoming] if incoming else ['*']
                legacy_dst = [i for i in (x.get('internal_ifaces') or []) if i != '*']
                x['destination_iface'] = legacy_dst[0] if legacy_dst else ''
        out.append(x)
    return out


def _virtual_interfaces():
    return [x for x in display_interfaces() if x.get('iface') != 'lo' and not (x.get('type') == 'eth' or x.get('is_physical'))]


def _local_interface_networks(iface, family):
    rows = [x for x in display_interfaces() if x.get('iface') == iface]
    if not rows:
        return []
    x = rows[0]
    vals = []
    configured = x.get('configured_ipv4') if family == 4 else x.get('configured_ipv6')
    if configured:
        vals.append(configured)
    vals.extend(x.get('runtime_ipv4') or [] if family == 4 else x.get('runtime_ipv6') or [])
    nets = []
    for value in vals:
        try:
            net = ipaddress.ip_interface(value).network
            if net.version == family and str(net) not in nets:
                nets.append(str(net))
        except Exception:
            continue
    return nets


def _parse_ports(value):
    value = str(value or '').strip()
    if not value:
        return []
    ports = []
    for token in re.split(r'[\s,]+', value):
        if not token:
            continue
        if '-' in token:
            a, b = token.split('-', 1)
            try:
                a, b = int(a), int(b)
            except Exception:
                raise ValueError(f'Invalid port range: {token}')
            if not (1 <= a <= b <= 65535):
                raise ValueError(f'Invalid port range: {token}')
            ports.append(f'{a}-{b}')
        else:
            try:
                p = int(token)
            except Exception:
                raise ValueError(f'Invalid port: {token}')
            if not 1 <= p <= 65535:
                raise ValueError(f'Invalid port: {token}')
            ports.append(str(p))
    return ports


def _wireguard_listen_ports():
    """Return configured and currently running WireGuard UDP listen ports.

    DMZ/exposed-host rules must never steal these host-local UDP listeners.
    Include configured PRM interfaces even while administratively down so a
    later interface start does not require the DMZ rule to be edited again.
    """
    ports = set()
    try:
        for iface in (_wg_cfg().get('interfaces') or []):
            try:
                port = int(iface.get('listen_port') or 0)
            except Exception:
                port = 0
            if 1 <= port <= 65535:
                ports.add(port)
    except Exception:
        pass
    try:
        runtime = _wg_runtime_dump()
        for row in (runtime.get('interfaces') or {}).values():
            try:
                port = int(row.get('listen_port') or 0)
            except Exception:
                port = 0
            if 1 <= port <= 65535:
                ports.add(port)
    except Exception:
        pass
    return sorted(ports)


def _validate_port_expr(value, field='port'):
    value = str(value or '').strip()
    if not value:
        return ''
    ports = _parse_ports(value)
    if len(ports) != 1:
        raise ValueError(f'{field} accepts one port or one range')
    return ports[0]


def _iface_exists(name):
    return bool(name and Path(f'/sys/class/net/{name}').exists())


def _validate_nat(data):
    family = int(data.get('family') or 4)
    if family not in (4, 6):
        raise ValueError('NAT family must be NAT44 or NAT66')
    kind = str(data.get('kind') or '').strip().lower()
    if kind not in ('snat', 'dnat', 'dmz'):
        raise ValueError('NAT type must be SNAT, DNAT or DMZ')
    name = str(data.get('name') or '').strip() or f'{kind.upper()} rule'

    # Source scope may be one or more virtual router interfaces, including
    # PRM WireGuard interfaces.  '*' means all virtual interfaces.
    requested = data.get('source_ifaces', data.get('internal_ifaces'))
    if not isinstance(requested, list):
        requested = []
    requested = [str(x).strip() for x in requested if str(x).strip()]
    if '*' in requested or not requested:
        source_ifaces = ['*']
    else:
        virtual_names = {str(x.get('iface')) for x in _virtual_interfaces()}
        bad = [x for x in requested if x not in virtual_names]
        if bad:
            raise ValueError('Only virtual interfaces can be selected as NAT source: ' + ', '.join(bad))
        source_ifaces = list(dict.fromkeys(requested))

    destination_iface = str(data.get('destination_iface') or data.get('external_iface') or '').strip()
    if not valid_iface(destination_iface) or not _iface_exists(destination_iface):
        raise ValueError('Select a valid destination/outgoing interface')

    result = {
        'family': family, 'kind': kind, 'name': name,
        'source_ifaces': source_ifaces, 'destination_iface': destination_iface,
        # Keep legacy keys for compatibility with older UI/state tools.
        'internal_ifaces': source_ifaces, 'external_iface': destination_iface,
        'enabled': bool(data.get('enabled', True)),
    }
    af = ipaddress.IPv4Address if family == 4 else ipaddress.IPv6Address
    nf = ipaddress.IPv4Network if family == 4 else ipaddress.IPv6Network

    # Optional source match is useful for a single WireGuard peer (/32 or /128)
    # as well as normal subnets.
    src = str(data.get('source_cidr') or '').strip()
    if src:
        try:
            src = str(nf(src, strict=False))
        except Exception:
            raise ValueError('Source network is not a valid IPv4/IPv6 CIDR for this NAT family')
    result['source_cidr'] = src

    if kind == 'snat':
        if not src and source_ifaces == ['*']:
            raise ValueError('Source network is required when NAT source is All virtual interfaces')
        mode = str(data.get('snat_mode') or 'masquerade').lower()
        if mode not in ('masquerade', 'address'):
            raise ValueError('SNAT translation must be Masquerade or Static address')
        result['snat_mode'] = mode
        addr = str(data.get('snat_address') or '').strip()
        if mode == 'address':
            try:
                if af(addr).version != family:
                    raise ValueError
            except Exception:
                raise ValueError('Enter a valid translated source address')
        result['snat_address'] = addr if mode == 'address' else ''
        return result

    external_address = str(data.get('external_address') or '').strip()
    if external_address:
        try:
            if af(external_address).version != family:
                raise ValueError
        except Exception:
            raise ValueError('External/original destination address does not match the NAT family')
    result['external_address'] = external_address

    target = str(data.get('target_address') or '').strip()
    try:
        if af(target).version != family:
            raise ValueError
    except Exception:
        raise ValueError('Target address does not match the NAT family')
    result['target_address'] = target

    # Validate the translated target against the explicitly selected destination
    # interface when that interface has known local networks.  This supports
    # wg -> vmbr, vmbr -> wg and bridge-to-bridge translations alike.
    networks = _local_interface_networks(destination_iface, family)
    target_ip = ipaddress.ip_address(target)
    if networks and not any(target_ip in ipaddress.ip_network(n, strict=False) for n in networks):
        raise ValueError('Target address is not inside a network configured on the selected destination interface')

    if kind == 'dnat':
        proto = str(data.get('protocol') or 'tcp').strip().lower()
        if proto not in ('tcp', 'udp', 'both', 'all'):
            raise ValueError('Protocol must be TCP, UDP, TCP+UDP or All')
        ext_port = _validate_port_expr(data.get('external_port'), 'External port')
        target_port = _validate_port_expr(data.get('target_port'), 'Target port')
        if proto == 'all' and (ext_port or target_port):
            raise ValueError('Ports cannot be used when Protocol is All')
        if proto != 'all' and not ext_port:
            raise ValueError('External port is required for TCP/UDP DNAT')
        if target_port and '-' in ext_port and '-' not in target_port:
            raise ValueError('A port range must map to a port range of the same size')
        if target_port and '-' in ext_port and '-' in target_port:
            a1, a2 = map(int, ext_port.split('-'))
            b1, b2 = map(int, target_port.split('-'))
            if (a2 - a1) != (b2 - b1):
                raise ValueError('External and target port ranges must have the same size')
        result.update({'protocol': proto, 'external_port': ext_port, 'target_port': target_port})
    else:
        exclusions = _parse_ports(data.get('exclude_ports') or '22,8005,8006')
        for required in ('8005', '8006'):
            if required not in exclusions:
                exclusions.append(required)
        result['exclude_ports'] = ','.join(exclusions)
    return result

def _nft_quote(value):
    return '"' + str(value).replace('\\', '\\\\').replace('"', '\\"') + '"'


def _nft_addr_token(family, addr, port=''):
    if not port:
        return str(addr)
    return f'[{addr}]:{port}' if family == 6 else f'{addr}:{port}'


def _iface_match(ifaces):
    if not ifaces or ifaces == ['*']:
        return ''
    if len(ifaces) == 1:
        return f'iifname {_nft_quote(ifaces[0])} '
    return 'iifname { ' + ', '.join(_nft_quote(x) for x in ifaces) + ' } '


def _nat_rule_lines(rule):
    if not rule.get('enabled', True):
        return []
    family = int(rule['family'])
    af_keyword = 'ip' if family == 4 else 'ip6'
    kind = rule['kind']
    rid = rule['id']
    cmt = _nft_quote(f'prm:{rid}')
    source_ifaces = list(rule.get('source_ifaces') or rule.get('internal_ifaces') or ['*'])
    destination_iface = str(rule.get('destination_iface') or rule.get('external_iface') or '')
    lines = []

    source_match = _iface_match(source_ifaces)
    if rule.get('source_cidr'):
        source_match += f"{af_keyword} saddr {rule['source_cidr']} "

    if kind == 'snat':
        # Source NAT is evaluated in postrouting.  Do not bind masquerade to
        # iifname here: on Proxmox a guest may traverse fwbr+/tap/bridge
        # plumbing before reaching the routed IP path, so the original ingress
        # device is not a reliable selector.  The selected source interfaces
        # define the source networks; the live rule matches those CIDRs plus
        # the actual outgoing interface, which is the standard router NAT form.
        sources = []
        if rule.get('source_cidr'):
            sources = [rule['source_cidr']]
        elif source_ifaces != ['*']:
            for iface in source_ifaces:
                sources.extend(_local_interface_networks(iface, family))
        sources = list(dict.fromkeys(sources))
        if not sources:
            raise ValueError('Could not determine a source network for SNAT. Select an interface with an IP network or enter Source network / peer explicitly.')
        for source in sources:
            expr = f'{af_keyword} saddr {source} oifname {_nft_quote(destination_iface)} counter '
            if rule.get('snat_mode') == 'address':
                expr += f"snat to {rule['snat_address']} comment {cmt}"
            else:
                expr += f'masquerade comment {cmt}'
            lines.append(('postrouting', expr))
        return lines

    # DNAT/DMZ match traffic entering the selected source interface(s).  The
    # selected destination interface is used to validate the translated target;
    # routing after DNAT chooses that interface normally.
    expr_base = source_match
    if rule.get('external_address'):
        expr_base += f"{af_keyword} daddr {rule['external_address']} "
    if kind == 'dnat':
        proto = rule.get('protocol', 'tcp')
        ext_port = rule.get('external_port') or ''
        target_port = rule.get('target_port') or ext_port
        expr = expr_base
        if proto == 'tcp':
            expr += f'tcp dport {ext_port} '
        elif proto == 'udp':
            expr += f'udp dport {ext_port} '
        elif proto == 'both':
            expr += f'meta l4proto {{ tcp, udp }} th dport {ext_port} '
        target = _nft_addr_token(family, rule['target_address'], target_port if proto != 'all' else '')
        expr += f'counter dnat to {target} comment {cmt}'
        lines.append(('prerouting', expr))
        return lines

    excluded = _parse_ports(rule.get('exclude_ports'))
    if excluded:
        pset = '{ ' + ', '.join(excluded) + ' }' if len(excluded) > 1 else excluded[0]
        lines.append(('prerouting', expr_base + f'meta l4proto {{ tcp, udp }} th dport {pset} return comment {_nft_quote(f"prm-exclude:{rid}")}'))

    # WireGuard listeners are host-local UDP services.  A catch-all DMZ DNAT
    # must not redirect them to the exposed host.  Keep this separate from the
    # administrator's TCP/UDP excluded-port list so TCP on the same number can
    # still be forwarded if desired.
    wg_ports = [str(x) for x in _wireguard_listen_ports()]
    if wg_ports:
        pset = '{ ' + ', '.join(wg_ports) + ' }' if len(wg_ports) > 1 else wg_ports[0]
        lines.append(('prerouting', expr_base + f'udp dport {pset} return comment {_nft_quote(f"prm-wg-exclude:{rid}")}'))

    lines.append(('prerouting', expr_base + f'counter dnat to {rule["target_address"]} comment {cmt}'))
    return lines

def _enabled_nat_cfg(cfg):
    """Return only enabled PRM NAT rules.

    Disabled rules stay persisted in nat.json but must not create runtime tables,
    hooks or conntrack-zone helpers.
    """
    return [dict(x) for x in (cfg or []) if isinstance(x, dict) and x.get('enabled', True)]


def _nat_expr_prefixlen(expr, family):
    """Return source-prefix specificity for a generated SNAT expression."""
    keyword = 'ip' if int(family) == 4 else 'ip6'
    m = re.search(rf'\b{keyword}\s+saddr\s+([^\s]+)', str(expr or ''))
    if not m:
        return -1
    try:
        return ipaddress.ip_network(m.group(1), strict=False).prefixlen
    except Exception:
        return -1


def _nat_rule_display_specificity(rule):
    """Best-effort SNAT specificity used only to make the UI match runtime order."""
    if str(rule.get('kind') or '').lower() != 'snat':
        return -1
    family = int(rule.get('family') or 4)
    cidr = str(rule.get('source_cidr') or '').strip()
    if cidr:
        try:
            return ipaddress.ip_network(cidr, strict=False).prefixlen
        except Exception:
            return -1
    specs = []
    for iface in (rule.get('source_ifaces') or rule.get('internal_ifaces') or []):
        if iface == '*':
            continue
        for net in _local_interface_networks(iface, family):
            try:
                specs.append(ipaddress.ip_network(net, strict=False).prefixlen)
            except Exception:
                pass
    return max(specs) if specs else -1


def _nat_effective_managed_order(cfg):
    """Return rules in the order PRM presents/evaluates their NAT intent.

    DNAT rules are newest-first so a newly created explicit port-forward is
    evaluated before older overlapping DNAT entries.  DMZ is always last and
    therefore behaves as a catch-all fallback.  SNAT is ordered from the most
    specific source prefix to the broadest; ties keep the saved order.
    """
    indexed = list(enumerate([x for x in (cfg or []) if isinstance(x, dict)]))
    out = []
    for fam in (4, 6):
        rows = [(idx, rule) for idx, rule in indexed if int(rule.get('family') or 4) == fam]
        dnats = [(idx, rule) for idx, rule in rows if str(rule.get('kind') or '').lower() == 'dnat']
        snats = [(idx, rule) for idx, rule in rows if str(rule.get('kind') or '').lower() == 'snat']
        dmzs = [(idx, rule) for idx, rule in rows if str(rule.get('kind') or '').lower() == 'dmz']
        other = [(idx, rule) for idx, rule in rows if str(rule.get('kind') or '').lower() not in ('dnat', 'snat', 'dmz')]
        out.extend(rule for idx, rule in sorted(dnats, key=lambda item: item[0], reverse=True))
        out.extend(rule for idx, rule in sorted(snats, key=lambda item: (-_nat_rule_display_specificity(item[1]), item[0])))
        out.extend(rule for idx, rule in other)
        out.extend(rule for idx, rule in sorted(dmzs, key=lambda item: item[0]))
    return out


def _nft_batch_for_nat(cfg):
    """Build a fresh nftables transaction with deterministic NAT priority.

    Explicit DNAT always precedes DMZ in prerouting, making DMZ a true fallback.
    New DNAT entries are placed above older DNAT entries.  SNAT is evaluated in
    postrouting and is sorted by source-prefix specificity so host/peer rules
    beat broader subnet masquerade rules when they overlap.

    Table deletion is intentionally done outside this batch.  This makes boot
    restore deterministic even when the tables do not exist yet.
    """
    enabled = _enabled_nat_cfg(cfg)
    lines = []
    for fam, table in ((4, 'prm_nat44'), (6, 'prm_nat66')):
        family_rules = [x for x in enabled if int(x.get('family') or 4) == fam]
        if not family_rules:
            continue
        nftfam = 'ip' if fam == 4 else 'ip6'
        lines += [
            f'add table {nftfam} {table}',
            f'add chain {nftfam} {table} prerouting {{ type nat hook prerouting priority -90; policy accept; }}',
            f'add chain {nftfam} {table} postrouting {{ type nat hook postrouting priority 110; policy accept; }}',
        ]

        # PREROUTING priority: explicit DNAT first (newest first), DMZ last.
        dnats = [x for x in family_rules if str(x.get('kind') or '').lower() == 'dnat']
        dmzs = [x for x in family_rules if str(x.get('kind') or '').lower() == 'dmz']
        for rule in reversed(dnats):
            for chain, expr in _nat_rule_lines(rule):
                if chain == 'prerouting':
                    lines.append(f'add rule {nftfam} {table} {chain} {expr}')
        for rule in dmzs:
            for chain, expr in _nat_rule_lines(rule):
                if chain == 'prerouting':
                    lines.append(f'add rule {nftfam} {table} {chain} {expr}')

        # POSTROUTING priority: most-specific SNAT source before broader rules.
        post = []
        seq = 0
        for rule in family_rules:
            if str(rule.get('kind') or '').lower() != 'snat':
                continue
            for chain, expr in _nat_rule_lines(rule):
                if chain == 'postrouting':
                    post.append((_nat_expr_prefixlen(expr, fam), seq, expr))
                    seq += 1
        for _prefix, _seq, expr in sorted(post, key=lambda item: (-item[0], item[1])):
            lines.append(f'add rule {nftfam} {table} postrouting {expr}')
    return ('\n'.join(lines) + '\n') if lines else ''

def _ensure_nat_tables():
    if not shutil.which('nft'):
        raise ValueError('nftables is not installed')
    for fam, table in (('ip', 'prm_nat44'), ('ip6', 'prm_nat66')):
        run(['nft', 'add', 'table', fam, table], allow_fail=True)


PRM_CT_ZONE_COMMENT = 'prm-nat-ct-zone'

def _nat_needs_ct_zone(cfg, family=4):
    """Return True when PRM has any enabled NAT rule for this address family.

    Proxmox guests with the VM firewall enabled traverse fwbr+ and can require a
    dedicated conntrack zone when NAT is in use.  Keep the helper active for the
    complete PRM NAT lifecycle (SNAT/Masquerade, DNAT and DMZ), not only source
    NAT.  IPv4 and IPv6 are handled independently so NAT44 and NAT66 can be
    enabled or removed without affecting each other.
    """
    fam = int(family)
    return any(
        int(x.get('family') or 4) == fam
        and x.get('enabled', True)
        and str(x.get('kind') or '').lower() in ('snat', 'dnat', 'dmz')
        for x in (cfg or [])
    )

def _ct_zone_rule_text(family=4):
    tool = 'iptables-save' if int(family) == 4 else 'ip6tables-save'
    if not shutil.which(tool):
        return ''
    return run([tool, '-t', 'raw'], allow_fail=True)

def _ct_zone_equivalent_present(family=4):
    text = _ct_zone_rule_text(family)
    if not text:
        return False
    # Accept both PRM-owned and manually configured Proxmox-recommended rules.
    for line in text.splitlines():
        if '-A PREROUTING' not in line:
            continue
        if '-i fwbr+' in line and '-j CT' in line and '--zone 1' in line:
            return True
    return False

def _ct_zone_owned_present(family=4):
    return PRM_CT_ZONE_COMMENT in _ct_zone_rule_text(family)

def _sync_nat_conntrack_zone(cfg=None):
    """Install/remove only PRM-owned fwbr conntrack-zone helper rules.

    This deliberately does not edit /etc/network/interfaces. Persistence is
    provided by prm-nat.service, and PRM rechecks the helper after firewall
    reloads. A manually configured equivalent rule is respected and untouched.
    """
    if cfg is None:
        cfg = _nat_cfg()
    result = {'ipv4': False, 'ipv6': False}
    for family, tool in ((4, 'iptables'), (6, 'ip6tables')):
        needed = _nat_needs_ct_zone(cfg, family)
        if not shutil.which(tool):
            # IPv6 helper is optional on systems without ip6tables; IPv4 is
            # expected on Proxmox but do not break NAT table synchronization.
            continue
        owned = _ct_zone_owned_present(family)
        equivalent = _ct_zone_equivalent_present(family)
        spec = ['-t', 'raw', '-I', 'PREROUTING', '1', '-i', 'fwbr+', '-m', 'comment',
                '--comment', PRM_CT_ZONE_COMMENT, '-j', 'CT', '--zone', '1']
        delete_spec = ['-t', 'raw', '-D', 'PREROUTING', '-i', 'fwbr+', '-m', 'comment',
                       '--comment', PRM_CT_ZONE_COMMENT, '-j', 'CT', '--zone', '1']
        if needed:
            if not equivalent:
                run([tool] + spec)
            result['ipv4' if family == 4 else 'ipv6'] = True
        elif owned:
            # Remove only our exact commented rule. Never remove a manual rule.
            for _ in range(8):
                if not _ct_zone_owned_present(family):
                    break
                run([tool] + delete_spec, allow_fail=True)
    return result


def _write_forwarding_sysctl(family):
    current = {}
    if PRM_SYSCTL.exists():
        for line in PRM_SYSCTL.read_text(errors='replace').splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                k, v = line.split('=', 1)
                current[k.strip()] = v.strip()
    if family == 4:
        current['net.ipv4.ip_forward'] = '1'
        run(['sysctl', '-w', 'net.ipv4.ip_forward=1'], allow_fail=True)
    else:
        current['net.ipv6.conf.all.forwarding'] = '1'
        run(['sysctl', '-w', 'net.ipv6.conf.all.forwarding=1'], allow_fail=True)
        # Per-interface RA/SLAAC policy is owned by prm-ipv6-sync.  Do not
        # infer accept_ra from default-route membership: a Static WAN must stay
        # Static even while this host forwards IPv6.
    PRM_SYSCTL.parent.mkdir(parents=True, exist_ok=True)
    body = ['# Managed by VE Router Manager. Created only after router/NAT features are enabled.']
    body += [f'{k} = {current[k]}' for k in sorted(current)]
    PRM_SYSCTL.write_text('\n'.join(body) + '\n')
    os.chmod(PRM_SYSCTL, 0o644)


def set_forwarding(family, enable=True):
    family = int(family)
    if family not in (4, 6):
        raise ValueError('Forwarding family must be IPv4 or IPv6')
    enabled = bool(enable)
    key = 'net.ipv4.ip_forward' if family == 4 else 'net.ipv6.conf.all.forwarding'
    run(['sysctl', '-w', f'{key}={1 if enabled else 0}'])

    current = {}
    if PRM_SYSCTL.exists():
        for line in PRM_SYSCTL.read_text(errors='replace').splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                k, v = line.split('=', 1)
                current[k.strip()] = v.strip()
    current[key] = '1' if enabled else '0'

    # Per-interface IPv6 mode policy is independent from forwarding.  SLAAC
    # and DHCPv6 explicitly opt into RA via prm-ipv6-sync; Static explicitly
    # keeps accept_ra=0/autoconf=0.

    PRM_SYSCTL.parent.mkdir(parents=True, exist_ok=True)
    body = ['# Managed by VE Router Manager. Router/NAT forwarding controls.']
    body += [f'{k} = {current[k]}' for k in sorted(current)]
    PRM_SYSCTL.write_text('\n'.join(body) + '\n')
    os.chmod(PRM_SYSCTL, 0o644)

    fam = 'IPv4' if family == 4 else 'IPv6'
    warning = ''
    if not enabled and any(int(x.get('family') or 4) == family and x.get('enabled', True) for x in _nat_cfg()):
        warning = f' Active PRM {"NAT44" if family == 4 else "NAT66"} rules remain configured but will not route traffic while forwarding is disabled.'
    return {'ok': True, 'family': family, 'enabled': enabled, 'message': f'{fam} forwarding {"enabled" if enabled else "disabled"} and made persistent.' + warning}


def set_ipv6_forwarding(enable=True):
    # Kept for backward compatibility with the v0.3.1 API endpoint.
    return set_forwarding(6, enable)


def _forwarding_preference(family):
    key = 'net.ipv4.ip_forward' if int(family) == 4 else 'net.ipv6.conf.all.forwarding'
    if not PRM_SYSCTL.exists():
        return None
    try:
        for line in PRM_SYSCTL.read_text(errors='replace').splitlines():
            if '=' not in line or line.lstrip().startswith('#'):
                continue
            k, v = line.split('=', 1)
            if k.strip() == key:
                return v.strip() == '1'
    except Exception:
        pass
    return None


def _apply_forwarding_preference(family, default_enable=False):
    pref = _forwarding_preference(family)
    if pref is None:
        if default_enable:
            _write_forwarding_sysctl(family)
        return
    key = 'net.ipv4.ip_forward' if int(family) == 4 else 'net.ipv6.conf.all.forwarding'
    run(['sysctl', '-w', f'{key}={1 if pref else 0}'], allow_fail=True)
    if int(family) == 6 and pref:
        preserve = {iface for iface, mode in _ipv6_active_modes().items() if _logical_ipv6_mode(mode) in ('slaac', 'dhcpv6')}
        for iface in sorted(preserve, key=natural_key):
            if valid_iface(iface) and _iface_exists(iface):
                run(['sysctl', '-w', f'net.ipv6.conf.{iface}.accept_ra=2'], allow_fail=True)


def _remove_prm_nat_tables():
    if not shutil.which('nft'):
        return
    run(['nft', 'delete', 'table', 'ip', 'prm_nat44'], allow_fail=True)
    run(['nft', 'delete', 'table', 'ip6', 'prm_nat66'], allow_fail=True)


def _nat_runtime_ready(cfg):
    """Check whether saved NAT rules can be materialized against live links.

    During Proxmox boot pvesh/network discovery may become available a little
    later than systemd's network-online target.  Recreating an interface-scoped
    SNAT before its bridge has an address would produce no source CIDR.  This
    readiness check prevents the one-shot restore from racing that condition.
    """
    enabled = _enabled_nat_cfg(cfg)
    if not enabled:
        return True, ''
    missing = []
    for rule in enabled:
        dst = str(rule.get('destination_iface') or rule.get('external_iface') or '').strip()
        if dst and not _iface_exists(dst):
            missing.append(dst)
        source_ifaces = list(rule.get('source_ifaces') or rule.get('internal_ifaces') or ['*'])
        if source_ifaces != ['*']:
            for iface in source_ifaces:
                if not _iface_exists(str(iface)):
                    missing.append(str(iface))
        if str(rule.get('kind') or '').lower() == 'snat' and not str(rule.get('source_cidr') or '').strip():
            fam = int(rule.get('family') or 4)
            nets = []
            if source_ifaces != ['*']:
                for iface in source_ifaces:
                    nets.extend(_local_interface_networks(str(iface), fam))
            if not nets:
                label = ','.join(str(x) for x in source_ifaces) if source_ifaces else 'source interface'
                missing.append(f'{label}:network')
    if missing:
        return False, ', '.join(sorted(set(missing), key=natural_key))
    return True, ''


def sync_nat_rules(cfg=None):
    """Rebuild PRM runtime NAT from the supplied configuration.

    This is deliberately a replace operation: remove PRM-owned NAT44/NAT66
    tables first, then create the active families and rules from scratch.  The
    same function is used by Create/Edit/Delete and by boot restore, so boot is
    behaviourally identical to creating the rules again in the GUI.
    """
    if cfg is None:
        cfg = _nat_cfg()
    enabled = _enabled_nat_cfg(cfg)

    # Always discard stale PRM runtime tables first.  If there are no enabled
    # rules we stop here and leave no PRM NAT hooks/helper behind.
    _remove_prm_nat_tables()
    if not enabled:
        _sync_nat_conntrack_zone([])
        return 0

    if not shutil.which('nft'):
        raise ValueError('nftables is not installed')

    batch = _nft_batch_for_nat(enabled)
    if not batch.strip():
        _sync_nat_conntrack_zone([])
        return 0
    path = STATE / 'prm-nat.nft'
    path.write_text(batch)
    os.chmod(path, 0o600)

    # Validate exactly what will be installed, then create it on a clean PRM
    # runtime state.  No pre-existing PRM table is required for validation.
    run(['nft', '-c', '-f', str(path)])
    run(['nft', '-f', str(path)])

    # Proxmox VM-firewall traffic traverses fwbr+. Restore conntrack-zone
    # helpers only for the address families that actually have active NAT.
    _sync_nat_conntrack_zone(enabled)
    if any(int(x.get('family') or 4) == 4 for x in enabled):
        _apply_forwarding_preference(4, default_enable=True)
    if any(int(x.get('family') or 4) == 6 for x in enabled):
        _apply_forwarding_preference(6, default_enable=True)
    return 0


def restore_nat_on_boot(timeout=45):
    """One-shot boot restore of saved PRM NAT state.

    If no active NAT rules are configured, create nothing.  If rules exist,
    wait briefly for their interfaces/addresses to appear and then rebuild the
    runtime tables and CT-zone helpers exactly as a fresh GUI Create would.
    This is bounded boot-time waiting, not a watchdog or background poll.
    """
    cfg = _nat_cfg()
    enabled = _enabled_nat_cfg(cfg)
    if not enabled:
        _remove_prm_nat_tables()
        _sync_nat_conntrack_zone([])
        print('PRM NAT restore: no enabled NAT rules; nothing to install', flush=True)
        return 0

    deadline = time.monotonic() + max(1, int(timeout))
    last_reason = ''
    while True:
        ready, reason = _nat_runtime_ready(enabled)
        if ready:
            break
        last_reason = reason
        if time.monotonic() >= deadline:
            raise RuntimeError('PRM NAT restore timed out waiting for interfaces/networks: ' + (last_reason or 'unknown'))
        time.sleep(1)

    # A full replace is intentional here.  It also repairs a boot where a
    # firewall/network service removed a PRM hook after the previous shutdown.
    sync_nat_rules(enabled)
    fams = []
    if any(int(x.get('family') or 4) == 4 for x in enabled):
        fams.append('NAT44')
    if any(int(x.get('family') or 4) == 6 for x in enabled):
        fams.append('NAT66')
    print('PRM NAT restore: recreated ' + '/'.join(fams) + f' from {NAT_CONFIG}', flush=True)
    return 0

def create_nat(data):
    rule = _validate_nat(data)
    rule['id'] = uuid.uuid4().hex[:12]
    cfg = _nat_cfg()
    cfg.append(rule)
    sync_nat_rules(cfg)
    _atomic_json_write(NAT_CONFIG, cfg)
    fam = 'NAT44' if rule['family'] == 4 else 'NAT66'
    return {'ok': True, 'rule': rule, 'message': f"{fam} {rule['kind'].upper()} rule created"}


def update_nat(rule_id, data):
    cfg = _nat_cfg()
    old = next((x for x in cfg if x.get('id') == rule_id), None)
    if not old:
        raise ValueError('PRM-managed NAT rule was not found')
    new = _validate_nat(data)
    new['id'] = rule_id
    candidate = [new if x.get('id') == rule_id else x for x in cfg]
    sync_nat_rules(candidate)
    _atomic_json_write(NAT_CONFIG, candidate)
    return {'ok': True, 'rule': new, 'message': f"{('NAT44' if new['family']==4 else 'NAT66')} {new['kind'].upper()} rule updated"}


def delete_nat(rule_id):
    cfg = _nat_cfg()
    old = next((x for x in cfg if x.get('id') == rule_id), None)
    if not old:
        raise ValueError('PRM-managed NAT rule was not found')
    candidate = [x for x in cfg if x.get('id') != rule_id]
    sync_nat_rules(candidate)
    _atomic_json_write(NAT_CONFIG, candidate)
    return {'ok': True, 'message': f"{('NAT44' if old['family']==4 else 'NAT66')} {old['kind'].upper()} rule deleted"}


def _parse_nft_nat_rows():
    text = run(['nft', '-a', 'list', 'ruleset'], allow_fail=True) if shutil.which('nft') else ''
    rows = []
    family = table = chain = ''
    for raw in text.splitlines():
        line = raw.strip()
        mt = re.match(r'^table\s+(\S+)\s+(\S+)\s*\{', line)
        if mt:
            family, table = mt.groups()
            chain = ''
            continue
        mc = re.match(r'^chain\s+(\S+)\s*\{', line)
        if mc:
            chain = mc.group(1)
            continue
        low = line.lower()
        if not any(x in low for x in ('dnat to', 'snat to', 'masquerade', ' redirect')):
            continue
        counter = re.search(r'counter packets\s+(\d+)\s+bytes\s+(\d+)', line)
        comment = re.search(r'comment\s+"([^"]+)"', line)
        handle = re.search(r'#\s*handle\s+(\d+)', line)
        kind = 'DNAT' if 'dnat to' in low else 'SNAT' if 'snat to' in low or 'masquerade' in low else 'REDIRECT'
        # Compact description for the UI; keep the raw rule only for diagnostics.
        iif = re.search(r'iifname\s+"([^"]+)"', line)
        oif = re.search(r'oifname\s+"([^"]+)"', line)
        saddr = re.search(r'\b(?:ip|ip6)\s+saddr\s+([^\s]+)', line)
        daddr = re.search(r'\b(?:ip|ip6)\s+daddr\s+([^\s]+)', line)
        trans = re.search(r'\b(?:dnat|snat)\s+to\s+([^\s]+)', line)
        left = []
        if iif: left.append(iif.group(1))
        if saddr: left.append(saddr.group(1))
        if daddr: left.append('to ' + daddr.group(1))
        if oif: left.append('out ' + oif.group(1))
        action = ('masquerade' if 'masquerade' in low else
                  ('DNAT → ' + trans.group(1) if 'dnat to' in low and trans else
                   ('SNAT → ' + trans.group(1) if 'snat to' in low and trans else kind)))
        summary = (' · '.join(left) + (' · ' if left else '') + action).strip()
        rows.append({
            'nft_family': family, 'family': 4 if family == 'ip' else 6 if family == 'ip6' else None,
            'table': table, 'chain': chain, 'kind': kind, 'rule': line, 'summary': summary,
            'packets': int(counter.group(1)) if counter else None,
            'bytes': int(counter.group(2)) if counter else None,
            'comment': comment.group(1) if comment else '', 'handle': handle.group(1) if handle else None,
        })
    return rows


def nat_status():
    if not shutil.which('nft'):
        return {'available': False, 'rules': [], 'managed': [], 'forwarding4': False, 'forwarding6': False}
    runtime = _parse_nft_nat_rows()
    counts = {}
    system = []
    for row in runtime:
        m = re.fullmatch(r'prm:([0-9a-fA-F]+)', row.get('comment') or '')
        if m:
            rid = m.group(1)
            acc = counts.setdefault(rid, {'packets': 0, 'bytes': 0, 'runtime_rules': 0})
            acc['packets'] += int(row.get('packets') or 0)
            acc['bytes'] += int(row.get('bytes') or 0)
            acc['runtime_rules'] += 1
        elif row.get('table') not in ('prm_nat44', 'prm_nat66'):
            row['managed'] = False
            system.append(row)
    managed = []
    wg_auto_ports = ','.join(str(x) for x in _wireguard_listen_ports())
    for x in _nat_effective_managed_order(_nat_cfg()):
        row = dict(x)
        row.update(counts.get(str(x.get('id')), {'packets': 0, 'bytes': 0, 'runtime_rules': 0}))
        row['managed'] = True
        if str(row.get('kind') or '').lower() == 'dmz':
            row['auto_exclude_udp_ports'] = wg_auto_ports
        managed.append(row)
    def read_bool(path):
        try: return Path(path).read_text().strip() == '1'
        except Exception: return False
    return {
        'available': True, 'managed': managed, 'system': system,
        'rules': managed + system,
        'forwarding4': read_bool('/proc/sys/net/ipv4/ip_forward'),
        'forwarding6': read_bool('/proc/sys/net/ipv6/conf/all/forwarding'),
        'ct_zone4': _ct_zone_equivalent_present(4),
        'ct_zone6': _ct_zone_equivalent_present(6),
    }


FIREWALL_MARK_RE = re.compile(r'^\[PRM:([0-9a-fA-F]{8,32})\](?:\s+(.*))?$')


def _firewall_marker(comment):
    m = FIREWALL_MARK_RE.match(str(comment or '').strip())
    if not m:
        return None, str(comment or '')
    return m.group(1).lower(), (m.group(2) or '')


def _firewall_comment(rule_id, comment):
    text = str(comment or '').strip()
    return f'[PRM:{rule_id}]' + (f' {text}' if text else '')


def _invalidate_firewall_cache():
    with FIREWALL_CACHE_LOCK:
        FIREWALL_CACHE['ts'] = 0.0
        FIREWALL_CACHE['data'] = None


def _firewall_guest_kind(kind):
    node = node_name()
    try:
        rows = pvesh_json(['get', f'/nodes/{node}/{kind}']) or []
    except Exception:
        rows = []
    result = []
    for row in rows:
        vmid = row.get('vmid')
        if vmid is None:
            continue
        result.append({
            'scope': kind,
            'vmid': int(vmid),
            'name': row.get('name') or row.get('hostname') or f'{kind.upper()} {vmid}',
            'status': row.get('status') or 'unknown',
            'label': f"{vmid} · {row.get('name') or row.get('hostname') or kind.upper()}",
        })
    return result


def _firewall_guests():
    # QEMU and LXC discovery are independent API calls, so run them in parallel.
    guests = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(_firewall_guest_kind, kind) for kind in ('qemu', 'lxc')]
        for fut in futures:
            try:
                guests.extend(fut.result())
            except Exception:
                pass
    guests.sort(key=lambda x: (x['vmid'], x['scope']))
    return guests


def _firewall_rule_endpoint(scope, vmid=None):
    node = node_name()
    if scope == 'host':
        return f'/nodes/{node}/firewall/rules'
    if scope in ('qemu', 'lxc'):
        if vmid is None:
            raise ValueError('Select a VM/LXC target')
        return f'/nodes/{node}/{scope}/{int(vmid)}/firewall/rules'
    if scope == 'cluster':
        return '/cluster/firewall/rules'
    raise ValueError('Unsupported firewall scope')


def _firewall_forward_capability():
    usage = run(['pvesh', 'usage', f'/nodes/{node_name()}/firewall/rules', '-v'], allow_fail=True).lower()
    api_forward = 'forward' in usage
    nft_service = run(['systemctl', 'is-active', 'proxmox-firewall.service'], allow_fail=True).strip() == 'active'
    legacy_service = run(['systemctl', 'is-active', 'pve-firewall.service'], allow_fail=True).strip() == 'active'
    backend = 'nftables' if nft_service else ('legacy' if legacy_service else 'unknown')
    return {'api_forward': api_forward, 'nft_backend_active': nft_service, 'legacy_backend_active': legacy_service, 'backend': backend}


def _firewall_list_scope(scope, vmid=None, target_name=None):
    endpoint = _firewall_rule_endpoint(scope, vmid)
    try:
        rows = pvesh_json(['get', endpoint]) or []
    except Exception as e:
        return [], str(e)
    out = []
    for row in rows:
        x = dict(row)
        marker, clean_comment = _firewall_marker(x.get('comment'))
        x['scope'] = scope
        x['vmid'] = vmid
        x['target'] = target_name or ('Datacenter' if scope == 'cluster' else 'Proxmox Node')
        x['managed'] = bool(marker)
        x['prm_id'] = marker
        x['display_comment'] = clean_comment if marker else (x.get('comment') or '')
        x['automatic'] = bool(marker and (clean_comment.startswith('Automatic DHCP') or clean_comment.startswith('Automatic WireGuard') or clean_comment.startswith('Automatic IPv6 ICMP')))
        out.append(x)
    return out, None


def _firewall_options_file(path):
    p = Path(path)
    if not p.exists():
        return {}
    section = None
    out = {}
    try:
        for raw in p.read_text(errors='replace').splitlines():
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            if line.startswith('[') and line.endswith(']'):
                section = line[1:-1].strip().upper()
                continue
            if section == 'OPTIONS' and ':' in line:
                k, v = line.split(':', 1)
                out[k.strip()] = v.strip()
    except Exception:
        return {}
    return out


def _cluster_firewall_options_via_proxmox_parser():
    """Read cluster firewall options with Proxmox's own parser.

    PVE 9 builds affected by Proxmox bug #7942 can fail specifically in
    `pvesh get /cluster/firewall/options` because of the API schema, while the
    underlying Proxmox parser and the firewall daemon still work.  Calling the
    parser directly gives us the same persisted cluster.fw interpretation the
    firewall engine uses, without implementing our own config parser.
    """
    perl = (
        'my $c=PVE::Firewall::load_clusterfw_conf(); '
        'my $o=$c->{options} // {}; '
        'print JSON::PP::encode_json($o);'
    )
    out = run(['perl', '-MPVE::Firewall', '-MJSON::PP', '-e', perl])
    return json.loads(out or '{}')


def _firewall_get_options(scope):
    """Read Proxmox firewall options.

    Writes are always performed through the Proxmox API.  For display/state we
    intentionally prefer the persisted pmxcfs configuration because that is
    what the Proxmox GUI/firewall engine ultimately consumes.  PVE 9 builds can
    fail specifically on GET /cluster/firewall/options, and API responses may
    omit values which are not explicitly set.
    """
    if scope == 'cluster':
        endpoint = '/cluster/firewall/options'
        path = '/etc/pve/firewall/cluster.fw'
    elif scope == 'host':
        endpoint = f'/nodes/{node_name()}/firewall/options'
        path = f'/etc/pve/nodes/{node_name()}/host.fw'
    else:
        raise ValueError('Firewall option scope must be cluster or host')

    file_opts = _firewall_options_file(path)
    out = dict(file_opts)
    out['_state_source'] = 'pmxcfs'
    try:
        api_opts = pvesh_json(['get', endpoint]) or {}
        out['_api_options'] = api_opts
        # API can return useful fields which are omitted from the file because
        # they use defaults. Never overwrite an explicit persisted value.
        for key, value in api_opts.items():
            if key not in out:
                out[key] = value
        if 'enable' in api_opts and 'enable' in file_opts:
            file_enabled = str(file_opts.get('enable', '0')).strip().lower() in ('1', 'yes', 'true', 'on')
            api_enabled = str(api_opts.get('enable', '0')).strip().lower() in ('1', 'yes', 'true', 'on')
            if file_enabled != api_enabled:
                out['_state_mismatch'] = True
    except Exception as e:
        out['_api_error'] = str(e)
    return out

def _guest_has_firewall_config(vmid):
    return Path(f'/etc/pve/firewall/{int(vmid)}.fw').exists()


def _effective_cluster_policies(options):
    options = options or {}
    return {
        'policy_in': str(options.get('policy_in') or 'DROP').upper(),
        'policy_out': str(options.get('policy_out') or 'ACCEPT').upper(),
        'policy_forward': str(options.get('policy_forward') or 'ACCEPT').upper(),
    }


def _effective_host_policies(options):
    options = options or {}
    return {
        'policy_in': str(options.get('policy_in') or 'DROP').upper(),
        'policy_out': str(options.get('policy_out') or 'ACCEPT').upper(),
    }


def firewall_status(force=False):
    now = time.monotonic()
    if not force:
        with FIREWALL_CACHE_LOCK:
            cached = FIREWALL_CACHE.get('data')
            age = now - float(FIREWALL_CACHE.get('ts') or 0.0)
            if cached is not None and age < FIREWALL_CACHE_TTL:
                out = dict(cached)
                out['cache_hit'] = True
                out['cache_age_ms'] = int(age * 1000)
                return out

    started = time.monotonic()
    guests = []
    rules = []
    errors = []

    # Every API query below is independent.  The old implementation queried
    # Datacenter -> Host -> every VM/LXC sequentially, which became slow on
    # hosts with many guests.  Only guests with an actual Proxmox firewall
    # config file need a rules request; all requests run in parallel.
    jobs = [
        ('cluster', None, 'Datacenter'),
        ('host', None, 'Proxmox Host'),
    ]

    max_workers = min(12, max(4, len(jobs)))
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_firewall_list_scope, scope, vmid, label): (scope, vmid, label) for scope, vmid, label in jobs}
        option_futures = {
            pool.submit(_firewall_get_options, 'cluster'): 'cluster',
            pool.submit(_firewall_get_options, 'host'): 'host',
            pool.submit(_firewall_forward_capability): 'forward',
        }
        for fut in as_completed(futures):
            scope, vmid, label = futures[fut]
            try:
                rows, err = fut.result()
            except Exception as e:
                rows, err = [], str(e)
            rules.extend(rows)
            if err:
                errors.append(f'{label}: {err}')
        option_results = {}
        for fut, key in option_futures.items():
            try:
                option_results[key] = fut.result()
            except Exception as e:
                option_results[key] = {}
                errors.append(f'{key} options: {e}')

    # Preserve actual Proxmox rule order inside each scope.  Different scopes
    # are grouped predictably for a stable GUI.
    scope_order = {'cluster': 0, 'host': 1}
    rules.sort(key=lambda x: (
        scope_order.get(x.get('scope'), 9),
        int(x.get('vmid') or 0),
        int(x.get('pos') if x.get('pos') is not None else 999999),
    ))

    cluster_options = option_results.get('cluster') or {}
    host_options = option_results.get('host') or {}
    if cluster_options.get('_state_mismatch'):
        errors.append(
            'Datacenter firewall state mismatch: Proxmox API/Web GUI and cluster.fw disagree; '
            'PRM is displaying the API/Web GUI state.'
        )
    if host_options.get('_state_mismatch'):
        errors.append(
            'Node firewall state mismatch: Proxmox API/Web GUI and host.fw disagree; '
            'PRM is displaying the API/Web GUI state.'
        )
    result = {
        'available': True,
        'rules': rules,
        'guests': guests,
        'host_options': host_options,
        'cluster_options': cluster_options,
        'cluster_policies': _effective_cluster_policies(cluster_options),
        'host_policies': _effective_host_policies(host_options),
        'forward': option_results.get('forward') or {},
        'errors': errors,
        'cache_hit': False,
        'cache_age_ms': 0,
        'load_ms': int((time.monotonic() - started) * 1000),
        'queried_guest_firewalls': 0,
    }
    with FIREWALL_CACHE_LOCK:
        FIREWALL_CACHE['ts'] = time.monotonic()
        FIREWALL_CACHE['data'] = result
    return dict(result)


def _bool_option(value):
    return str(value if value is not None else '0').strip().lower() in ('1', 'yes', 'true', 'on')


def _firewall_backend():
    """Return the firewall backend that Proxmox is configured to use.

    proxmox-firewall.service is commonly active even when the nftables backend
    is not selected.  The authoritative selector is the node firewall option
    `nftables: 1` in host.fw.
    """
    host_path = f'/etc/pve/nodes/{node_name()}/host.fw'
    host_opts = _firewall_options_file(host_path)
    if _bool_option(host_opts.get('nftables')):
        return 'nftables'
    return 'legacy'


def _firewall_has_host_accept_port(port):
    """Check persisted host rules for an enabled TCP ACCEPT rule for port.

    This intentionally accepts a rule with or without source/interface limits;
    its purpose is a conservative PRM lockout guard, not policy analysis.
    """
    try:
        rows, _ = _firewall_list_scope('host', None, 'Proxmox Host')
    except Exception:
        return False
    wanted = str(int(port))
    for r in rows:
        if str(r.get('type') or '').lower() != 'in':
            continue
        if str(r.get('action') or '').upper() != 'ACCEPT':
            continue
        if not _bool_option(r.get('enable', 1)):
            continue
        proto = str(r.get('proto') or '').lower()
        if proto not in ('tcp', ''):
            continue
        dport = str(r.get('dport') or '')
        parts = re.split(r'[,;\s]+', dport) if dport else []
        for part in parts:
            if part == wanted:
                return True
            if ':' in part or '-' in part:
                sep = ':' if ':' in part else '-'
                try:
                    lo, hi = [int(x) for x in part.split(sep, 1)]
                    if lo <= int(port) <= hi:
                        return True
                except Exception:
                    pass
    return False


def _firewall_safety_check():
    """Validate the firewall before forcing a runtime reload.

    Proxmox provides automatic management exceptions for its own services in
    common setups, but PRM TCP/8005 is not a Proxmox service.  If effective
    INPUT policy is DROP, require an explicit host ACCEPT for 8005 before a
    restart can make the new policy effective.  8006/22 are reported as
    warnings if no explicit rule exists because Proxmox may allow them through
    the management IPSet.
    """
    cluster = _firewall_get_options('cluster') or {}
    host = _firewall_get_options('host') or {}
    cluster_enabled = _bool_option(cluster.get('enable'))
    host_enabled = _bool_option(host.get('enable'))
    policy_in = str(cluster.get('policy_in') or 'DROP').upper()
    warnings = []
    if cluster_enabled and host_enabled and policy_in == 'DROP':
        if not _firewall_has_host_accept_port(8005):
            raise RuntimeError(
                'Firewall apply blocked to protect PRM access: Datacenter INPUT policy is DROP '
                'and no enabled Node INPUT ACCEPT TCP/8005 rule was found. Add an allow rule '
                'for TCP/8005 from your management network, then apply again.'
            )
        for port, label in ((8006, 'Proxmox WebGUI'), (22, 'SSH')):
            if not _firewall_has_host_accept_port(port):
                warnings.append(
                    f'No explicit Host INPUT ACCEPT TCP/{port} rule found for {label}; '
                    'Proxmox management-IPSet exceptions may still allow it.'
                )
    return warnings


def _apply_firewall_runtime(*, safety=True, force=False):
    """Compile, restart the selected Proxmox firewall backend and verify it.

    The configuration remains owned by Proxmox.  This helper only forces the
    already-persisted configuration into the kernel so a host reboot is not
    required after PRM changes.
    """
    warnings = _firewall_safety_check() if safety else []

    # Validate legacy-compatible Proxmox firewall syntax before touching the
    # running ruleset.  pve-firewall compile is useful even on hosts where the
    # nftables backend is selected because it catches malformed config early.
    compile_out = ''
    if shutil.which('pve-firewall'):
        try:
            compile_out = run(['pve-firewall', 'compile'], timeout=45)
        except Exception as e:
            raise RuntimeError(f'Firewall configuration was saved but not applied: compile failed: {e}')

    backend = _firewall_backend()
    cluster_enabled = _bool_option(_firewall_options_file('/etc/pve/firewall/cluster.fw').get('enable'))

    if backend == 'nftables':
        if not shutil.which('systemctl'):
            raise RuntimeError('systemctl is required to reload proxmox-firewall')
        run(['systemctl', 'restart', 'proxmox-firewall.service'], timeout=45)
        active = run(['systemctl', 'is-active', 'proxmox-firewall.service'], allow_fail=True).strip()
        if active != 'active':
            raise RuntimeError('proxmox-firewall.service did not return to active state after restart')
        if cluster_enabled:
            nft = run(['nft', 'list', 'table', 'inet', 'proxmox-firewall'], allow_fail=True) if shutil.which('nft') else ''
            if not nft:
                # Give the daemon a short window to compile/install the table.
                for _ in range(10):
                    time.sleep(0.2)
                    nft = run(['nft', 'list', 'table', 'inet', 'proxmox-firewall'], allow_fail=True) if shutil.which('nft') else ''
                    if nft:
                        break
                if not nft:
                    warnings.append('nftables backend restarted, but table inet proxmox-firewall was not observed yet.')
    else:
        if shutil.which('pve-firewall'):
            run(['pve-firewall', 'restart'], timeout=45)
        else:
            run(['systemctl', 'restart', 'pve-firewall.service'], timeout=45)
        status = run(['pve-firewall', 'status'], allow_fail=True).strip() if shutil.which('pve-firewall') else ''
        active = run(['systemctl', 'is-active', 'pve-firewall.service'], allow_fail=True).strip()
        if active != 'active':
            raise RuntimeError('pve-firewall.service did not return to active state after restart')
        if cluster_enabled:
            rules = run(['iptables-save'], allow_fail=True) if shutil.which('iptables-save') else ''
            if 'PVEFW-INPUT' not in rules:
                for _ in range(10):
                    time.sleep(0.2)
                    rules = run(['iptables-save'], allow_fail=True) if shutil.which('iptables-save') else ''
                    if 'PVEFW-INPUT' in rules:
                        break
                if 'PVEFW-INPUT' not in rules:
                    raise RuntimeError(
                        'pve-firewall restarted, but PVEFW runtime chains were not installed. '
                        f'Status: {status or "unknown"}'
                    )

    try:
        _sync_nat_conntrack_zone(_nat_cfg())
    except Exception as e:
        warnings.append(f'PRM NAT conntrack-zone helper could not be refreshed after firewall reload: {e}')
    _invalidate_firewall_cache()
    return {
        'backend': backend,
        'cluster_enabled': cluster_enabled,
        'warnings': warnings,
        'compile_output': compile_out[-2000:] if compile_out else '',
    }


def _firewall_set_enabled_with_pve_library(scope, requested):
    """Fallback using Proxmox's own firewall parser/serializer and locks.

    Some PVE 9 combinations have shown inconsistent behaviour for the cluster
    firewall options endpoint from pvesh even though rule CRUD works.  This is
    intentionally *not* a text-file edit: it calls PVE::Firewall's official
    load/save helpers under the same locks used by the API implementation.
    """
    val = '1' if requested else '0'
    if scope == 'cluster':
        perl = (
            'my $v=shift @ARGV; '
            'PVE::Firewall::lock_clusterfw_conf(10, sub { '
            'my $c=PVE::Firewall::load_clusterfw_conf(); '
            '$c->{options} //= {}; $c->{options}->{enable}=int($v); '
            'PVE::Firewall::save_clusterfw_conf($c); });'
        )
    elif scope == 'host':
        perl = (
            'my $v=shift @ARGV; '
            'PVE::Firewall::lock_hostfw_conf(10, sub { '
            'my $c=PVE::Firewall::load_clusterfw_conf(); '
            'my $h=PVE::Firewall::load_hostfw_conf($c); '
            '$h->{options} //= {}; $h->{options}->{enable}=int($v); '
            'PVE::Firewall::save_hostfw_conf($h); });'
        )
    else:
        raise ValueError('Firewall library scope must be cluster or host')
    run(['perl', '-MPVE::Firewall', '-e', perl, val])


def set_firewall_enabled(scope, enable=True):
    scope = str(scope or '').strip().lower()
    requested = bool(enable)
    if scope in ('datacenter', 'cluster'):
        endpoint = '/cluster/firewall/options'
        label = 'Datacenter firewall'
        verify_file = '/etc/pve/firewall/cluster.fw'
        canonical_scope = 'cluster'
    elif scope in ('host', 'node'):
        endpoint = f'/nodes/{node_name()}/firewall/options'
        label = 'Host firewall'
        verify_file = f'/etc/pve/nodes/{node_name()}/host.fw'
        canonical_scope = 'host'
    else:
        raise ValueError('Firewall scope must be Datacenter or Host')

    # First use the supported Proxmox API, exactly like other PRM firewall
    # operations.  Do not send any policy values in this request.
    api_error = ''
    try:
        run(['pvesh', 'set', endpoint, '--enable', '1' if requested else '0'])
    except Exception as e:
        api_error = str(e)
    _invalidate_firewall_cache()

    def persisted_state():
        opts = _firewall_options_file(verify_file)
        raw = opts.get('enable')
        enabled = str(raw if raw is not None else '0').strip().lower() in ('1', 'yes', 'true', 'on')
        return enabled, opts

    # Give pmxcfs/API a short window to persist.
    actual, persisted = persisted_state()
    for _ in range(8):
        if actual == requested:
            break
        time.sleep(0.15)
        actual, persisted = persisted_state()

    fallback_used = False
    fallback_error = ''
    if actual != requested:
        # PVE 9 fallback: use Proxmox's own PVE::Firewall implementation under
        # its native config lock.  This preserves syntax and pmxcfs semantics
        # and fixes only the enable bit; rules/policies are untouched.
        fallback_used = True
        try:
            _firewall_set_enabled_with_pve_library(canonical_scope, requested)
        except Exception as e:
            fallback_error = str(e)
        _invalidate_firewall_cache()
        for _ in range(12):
            actual, persisted = persisted_state()
            if actual == requested:
                break
            time.sleep(0.15)

    if actual != requested:
        details = []
        if api_error:
            details.append(f'API: {api_error}')
        if fallback_error:
            details.append(f'PVE::Firewall fallback: {fallback_error}')
        raise RuntimeError(
            f'{label} could not be changed. '
            f'Requested={"ENABLED" if requested else "DISABLED"}, '
            f'persisted enable={persisted.get("enable", "unset")}. '
            + (' | '.join(details) if details else 'Proxmox did not persist the requested state.')
        )

    # Force the verified persisted state into the kernel immediately. This
    # removes the need for a Proxmox host reboot after toggling the firewall.
    # Enabling performs the management lockout guard; disabling is always
    # allowed so a bad firewall configuration can be recovered from.
    apply_info = _apply_firewall_runtime(safety=requested, force=True)

    # Ask the installed firewall engine for its runtime state after reload.
    legacy_status = run(['pve-firewall', 'status'], allow_fail=True).strip() if shutil.which('pve-firewall') else ''
    proxmox_fw_status = run(['systemctl', 'is-active', 'proxmox-firewall.service'], allow_fail=True).strip()
    pve_fw_service = run(['systemctl', 'is-active', 'pve-firewall.service'], allow_fail=True).strip()

    engine_bits = []
    if proxmox_fw_status:
        engine_bits.append(f'proxmox-firewall={proxmox_fw_status}')
    if pve_fw_service:
        engine_bits.append(f'pve-firewall.service={pve_fw_service}')
    if legacy_status:
        engine_bits.append(f'pve-firewall status={legacy_status}')

    return {
        'ok': True,
        'scope': canonical_scope,
        'enabled': actual,
        'verified': True,
        'state_source': 'pmxcfs',
        'api_error': api_error,
        'fallback_used': fallback_used,
        'engine_status': '; '.join(engine_bits),
        'runtime_backend': apply_info.get('backend'),
        'warnings': apply_info.get('warnings', []),
        'message': f'{label} {"enabled" if actual else "disabled"} in Proxmox and firewall runtime reloaded'
            + (' (PVE::Firewall fallback used)' if fallback_used else ''),
    }


def set_firewall_policies(body):
    scope = str(body.get('scope') or 'cluster').strip().lower()
    if scope in ('datacenter', 'cluster'):
        endpoint = '/cluster/firewall/options'
        current = _firewall_get_options('cluster') or {}
        canonical_scope = 'cluster'
        label = 'Datacenter'
        supports_forward = _firewall_forward_capability().get('api_forward', False)
    elif scope in ('host', 'node'):
        endpoint = f'/nodes/{node_name()}/firewall/options'
        current = _firewall_get_options('host') or {}
        canonical_scope = 'host'
        label = 'Host'
        supports_forward = False
    else:
        raise ValueError('Policy scope must be Datacenter or Host')

    requested = {
        'policy_in': str(body.get('policy_in') or current.get('policy_in') or 'DROP').upper(),
        'policy_out': str(body.get('policy_out') or current.get('policy_out') or 'ACCEPT').upper(),
    }
    # PRM deliberately exposes ACCEPT/DROP here, matching the requested simple
    # router-oriented policy editor. Explicit REJECT remains available as a rule.
    for key in ('policy_in', 'policy_out'):
        if requested[key] not in ('ACCEPT', 'DROP'):
            raise ValueError(f'{key} must be ACCEPT or DROP')

    args = ['pvesh', 'set', endpoint, '--policy_in', requested['policy_in'], '--policy_out', requested['policy_out']]
    if canonical_scope == 'cluster' and supports_forward:
        requested['policy_forward'] = str(body.get('policy_forward') or current.get('policy_forward') or 'ACCEPT').upper()
        if requested['policy_forward'] not in ('ACCEPT', 'DROP'):
            raise ValueError('policy_forward must be ACCEPT or DROP')
        args += ['--policy_forward', requested['policy_forward']]

    run(args)
    _invalidate_firewall_cache()
    apply_info = _apply_firewall_runtime(safety=True)
    # Re-read the persisted state for the modal after save.
    options = _firewall_get_options(canonical_scope)
    effective = _effective_cluster_policies(options) if canonical_scope == 'cluster' else _effective_host_policies(options)
    return {
        'ok': True,
        'scope': canonical_scope,
        'policies': effective,
        'runtime_backend': apply_info.get('backend'),
        'warnings': apply_info.get('warnings', []),
        'message': f'{label} default firewall policies updated in Proxmox and runtime reloaded',
    }

def _firewall_build_args(body, *, rule_id=None):
    scope = str(body.get('scope') or 'host').lower()
    if scope not in ('cluster', 'host'):
        raise ValueError('PRM manages Datacenter and Node firewall rules only; configure VM/LXC firewalls in Proxmox.')
    direction = str(body.get('direction') or body.get('type') or 'in').lower()
    if direction == 'input':
        direction = 'in'
    elif direction == 'output':
        direction = 'out'
    if direction not in ('in', 'out', 'forward'):
        raise ValueError('Direction must be INPUT, OUTPUT or FORWARD')
    if scope in ('qemu', 'lxc') and direction == 'forward':
        raise ValueError('Proxmox VM/LXC firewall supports INPUT and OUTPUT only. FORWARD is a host/VNet rule.')
    action = str(body.get('action') or 'ACCEPT').upper()
    if action not in ('ACCEPT', 'DROP', 'REJECT'):
        raise ValueError('Action must be ACCEPT, DROP or REJECT')
    if direction == 'forward' and action == 'REJECT':
        raise ValueError('Proxmox nftables FORWARD rules do not support REJECT; use ACCEPT or DROP')
    if direction == 'forward':
        cap = _firewall_forward_capability()
        if cap.get('legacy_backend_active') and not cap.get('nft_backend_active'):
            raise ValueError('FORWARD requires the nftables-based proxmox-firewall backend. The legacy pve-firewall backend would ignore this rule.')
    rid = (rule_id or uuid.uuid4().hex[:12]).lower()
    args = ['--type', direction, '--action', action, '--enable', '1' if bool(body.get('enable', True)) else '0']
    macro = str(body.get('macro') or '').strip()
    proto = str(body.get('proto') or '').strip()
    sport = str(body.get('sport') or '').strip()
    dport = str(body.get('dport') or '').strip()
    icmp_type = str(body.get('icmp_type') or '').strip()

    # A Proxmox firewall macro is a named service definition such as SSH, HTTP
    # or HTTPS.  Older PRM UI versions allowed users to type a numeric port in
    # the Macro field, which then became `--macro 22` and Proxmox rejected it
    # with "unknown macro '22'".  Be forgiving when upgrading: if the value
    # only contains port-list/range syntax, treat it as a destination port for
    # TCP/UDP rather than as a macro.
    if macro and re.fullmatch(r'[0-9][0-9,:\-\s]*', macro):
        if dport and dport != macro:
            raise ValueError('A numeric Macro value conflicts with Destination port. Clear Macro and keep the port in Destination port.')
        if proto.lower() not in ('tcp', 'udp'):
            raise ValueError('A numeric port is not a Proxmox macro. Select TCP or UDP and enter the value in Destination port.')
        dport = dport or macro
        macro = ''

    fields = {'iface': 'iface', 'source': 'source', 'dest': 'dest', 'log': 'log'}
    for key, opt in fields.items():
        value = str(body.get(key) or '').strip()
        if not value or (key == 'log' and value.lower() == 'nolog'):
            continue
        args += [f'--{opt}', value]
    if macro:
        if sport or dport or icmp_type:
            raise ValueError('Proxmox service Macro cannot be combined with source/destination ports or ICMP type. Use either a Macro or explicit protocol/ports.')
        args += ['--macro', macro]
    else:
        if proto and proto.lower() not in ('any', 'all'):
            args += ['--proto', proto]
        for value, opt in ((sport, 'sport'), (dport, 'dport'), (icmp_type, 'icmp-type')):
            if value:
                args += [f'--{opt}', value]
    args += ['--comment', _firewall_comment(rid, body.get('comment'))]
    return scope, body.get('vmid'), rid, args


def create_firewall_rule(body):
    scope, vmid, rid, args = _firewall_build_args(body)
    endpoint = _firewall_rule_endpoint(scope, vmid)
    run(['pvesh', 'create', endpoint] + args)
    _invalidate_firewall_cache()
    apply_info = _apply_firewall_runtime(safety=True)
    return {
        'ok': True, 'id': rid, 'runtime_backend': apply_info.get('backend'),
        'warnings': apply_info.get('warnings', []),
        'message': 'Firewall rule created in Proxmox and runtime reloaded',
    }


def _find_prm_firewall_rule(rule_id):
    rule_id = str(rule_id or '').lower()
    if not re.fullmatch(r'[0-9a-f]{8,32}', rule_id):
        raise ValueError('Invalid PRM firewall rule ID')
    status = firewall_status(force=True)
    for row in status.get('rules', []):
        if row.get('prm_id') == rule_id and row.get('scope') in ('cluster', 'host'):
            return row
    raise ValueError('PRM firewall rule not found. It may have been changed directly in Proxmox.')


def update_firewall_rule(rule_id, body):
    current = _find_prm_firewall_rule(rule_id)
    if current.get('automatic'):
        raise ValueError('Automatic PRM firewall rules are read-only')
    scope = current.get('scope')
    vmid = current.get('vmid')
    # Scope/guest is intentionally immutable while editing; moving a rule between
    # Proxmox objects would change ordering semantics, so create a new rule instead.
    merged = dict(body)
    merged['scope'] = scope
    merged['vmid'] = vmid
    _, _, _, args = _firewall_build_args(merged, rule_id=rule_id)
    pos = current.get('pos')
    if pos is None:
        raise ValueError('Firewall rule position is unavailable')
    endpoint = _firewall_rule_endpoint(scope, vmid)
    run(['pvesh', 'set', f'{endpoint}/{int(pos)}'] + args)
    _invalidate_firewall_cache()
    apply_info = _apply_firewall_runtime(safety=True)
    return {
        'ok': True, 'id': rule_id, 'runtime_backend': apply_info.get('backend'),
        'warnings': apply_info.get('warnings', []),
        'message': 'Firewall rule updated in Proxmox and runtime reloaded',
    }


def delete_firewall_rule(rule_id):
    current = _find_prm_firewall_rule(rule_id)
    if current.get('automatic'):
        raise ValueError('Automatic PRM firewall rules are read-only')
    pos = current.get('pos')
    if pos is None:
        raise ValueError('Firewall rule position is unavailable')
    endpoint = _firewall_rule_endpoint(current.get('scope'), current.get('vmid'))
    run(['pvesh', 'delete', f'{endpoint}/{int(pos)}'])
    _invalidate_firewall_cache()
    apply_info = _apply_firewall_runtime(safety=True)
    return {
        'ok': True, 'runtime_backend': apply_info.get('backend'),
        'warnings': apply_info.get('warnings', []),
        'message': 'Firewall rule deleted from Proxmox and runtime reloaded',
    }



def _ipv6_icmp_firewall_rule_id():
    """Stable PRM rule id for the host ICMPv6 safety permit."""
    return uuid.uuid5(uuid.NAMESPACE_URL, 'prm://firewall/host/ipv6-icmp').hex[:12]


def _ipv6_icmp_firewall_rule_matches(row, body):
    return (
        str(row.get('type') or '').lower() == 'in'
        and str(row.get('action') or '').upper() == 'ACCEPT'
        and _bool_option(row.get('enable', 1))
        and str(row.get('proto') or '').lower() == 'ipv6-icmp'
        and not str(row.get('iface') or '').strip()
        and not str(row.get('source') or '').strip()
        and not str(row.get('dest') or '').strip()
    )


def sync_ipv6_icmp_firewall_rule(*, apply_runtime=True):
    """Keep the PRM host ICMPv6 safety permit in Proxmox Firewall.

    With a host INPUT DROP policy, blocking ICMPv6 breaks core IPv6 control
    traffic (including NDP/RA/error delivery) and can make IPv6 appear dead.
    PRM therefore owns one narrow protocol-level INPUT ACCEPT rule.  It is
    marked automatic/read-only in the PRM UI and persisted by Proxmox itself.
    """
    rid = _ipv6_icmp_firewall_rule_id()
    body = {
        'scope': 'host', 'direction': 'in', 'action': 'ACCEPT', 'enable': True,
        'proto': 'ipv6-icmp',
        'comment': 'Automatic IPv6 ICMP host access',
    }
    endpoint = _firewall_rule_endpoint('host')
    rows, err = _firewall_list_scope('host', None, 'Proxmox Host')
    if err:
        raise RuntimeError(f'Unable to read Proxmox Host firewall rules: {err}')

    current = next((r for r in rows if r.get('managed') and r.get('prm_id') == rid), None)
    _, _, _, args = _firewall_build_args(body, rule_id=rid)
    changed = False
    if current is None:
        run(['pvesh', 'create', endpoint] + args)
        changed = True
    elif (not _ipv6_icmp_firewall_rule_matches(current, body)
          or str(current.get('display_comment') or '') != body['comment']):
        pos = current.get('pos')
        if pos is None:
            raise RuntimeError(f'Automatic IPv6 ICMP firewall rule {rid} has no Proxmox position')
        run(['pvesh', 'set', f'{endpoint}/{int(pos)}'] + args)
        changed = True

    if changed:
        _invalidate_firewall_cache()
        if apply_runtime:
            _apply_firewall_runtime(safety=True)
    return {'changed': changed, 'rules': 1, 'id': rid}

def _dhcp_firewall_rule_id(iface, family):
    """Stable PRM rule id for an automatically managed DHCP host rule."""
    fam = 6 if int(family) == 6 else 4
    return uuid.uuid5(uuid.NAMESPACE_URL, f'prm://dhcp/{fam}/{iface}').hex[:12]


def _dhcp_firewall_desired(cfg=None):
    cfg = _dhcp_cfg() if cfg is None else cfg
    desired = {}
    for d in cfg or []:
        iface = str(d.get('iface') or '').strip()
        if not iface or not valid_iface(iface):
            continue
        if bool(d.get('ipv4_enabled', True)):
            rid = _dhcp_firewall_rule_id(iface, 4)
            desired[rid] = {
                'scope': 'host', 'direction': 'in', 'action': 'ACCEPT', 'enable': True,
                'iface': iface, 'proto': 'udp', 'dport': '67',
                'comment': f'Automatic DHCPv4 server access on {iface}',
            }
        if str(d.get('ipv6_mode') or 'disabled').lower() == 'dhcpv6':
            rid = _dhcp_firewall_rule_id(iface, 6)
            desired[rid] = {
                'scope': 'host', 'direction': 'in', 'action': 'ACCEPT', 'enable': True,
                'iface': iface, 'proto': 'udp', 'dport': '547',
                'comment': f'Automatic DHCPv6 server access on {iface}',
            }
    return desired


def _dhcp_firewall_rule_matches(row, body):
    return (
        str(row.get('type') or '').lower() == 'in'
        and str(row.get('action') or '').upper() == 'ACCEPT'
        and _bool_option(row.get('enable', 1))
        and str(row.get('iface') or '') == str(body.get('iface') or '')
        and str(row.get('proto') or '').lower() == 'udp'
        and str(row.get('dport') or '') == str(body.get('dport') or '')
    )


def sync_dhcp_firewall_rules(cfg=None, *, apply_runtime=True):
    """Persist host INPUT permits required by active PRM DHCP servers.

    Proxmox Firewall can use a default INPUT DROP policy. tcpdump on a bridge
    still sees client broadcasts in that case, but dnsmasq never receives
    UDP/67 or UDP/547. Keep narrow per-interface ACCEPT rules in Proxmox's own
    host firewall configuration so they survive reboot and firewall reloads.
    """
    desired = _dhcp_firewall_desired(cfg)
    endpoint = _firewall_rule_endpoint('host')
    rows, err = _firewall_list_scope('host', None, 'Proxmox Host')
    if err:
        raise RuntimeError(f'Unable to read Proxmox Host firewall rules: {err}')

    auto_rows = [r for r in rows if r.get('managed') and str(r.get('display_comment') or '').startswith('Automatic DHCP')]
    changed = False

    # Remove stale PRM automatic DHCP permits in descending position order,
    # because deleting a Proxmox firewall rule renumbers later positions.
    stale = [r for r in auto_rows if r.get('prm_id') not in desired]
    for row in sorted(stale, key=lambda x: int(x.get('pos') or 0), reverse=True):
        if row.get('pos') is not None:
            run(['pvesh', 'delete', f"{endpoint}/{int(row['pos'])}"])
            changed = True

    if stale:
        rows, err = _firewall_list_scope('host', None, 'Proxmox Host')
        if err:
            raise RuntimeError(f'Unable to re-read Proxmox Host firewall rules: {err}')

    by_id = {r.get('prm_id'): r for r in rows if r.get('managed')}
    for rid, body in desired.items():
        current = by_id.get(rid)
        _, _, _, args = _firewall_build_args(body, rule_id=rid)
        if current is None:
            run(['pvesh', 'create', endpoint] + args)
            changed = True
            continue
        if not _dhcp_firewall_rule_matches(current, body) or str(current.get('display_comment') or '') != body['comment']:
            pos = current.get('pos')
            if pos is None:
                raise RuntimeError(f'Automatic DHCP firewall rule {rid} has no Proxmox position')
            run(['pvesh', 'set', f'{endpoint}/{int(pos)}'] + args)
            changed = True

    if changed:
        _invalidate_firewall_cache()
        if apply_runtime:
            _apply_firewall_runtime(safety=True)
    return {'changed': changed, 'rules': len(desired)}


def _wireguard_firewall_rule_id(name):
    return uuid.uuid5(uuid.NAMESPACE_URL, f'prm://wireguard/listener/{name}').hex[:12]


def _wireguard_firewall_desired(cfg=None):
    cfg = _wg_cfg() if cfg is None else cfg
    desired = {}
    for iface in (cfg.get('interfaces') or []):
        if not iface.get('enabled', True):
            continue
        name = str(iface.get('name') or '').strip()
        if not name or not valid_iface(name):
            continue
        try:
            port = int(iface.get('listen_port') or 51820)
        except Exception:
            continue
        if not 1 <= port <= 65535:
            continue
        wan_iface = str(iface.get('wan_iface') or '').strip()
        rid = _wireguard_firewall_rule_id(name)
        desired[rid] = {
            'scope': 'host', 'direction': 'in', 'action': 'ACCEPT', 'enable': True,
            'iface': wan_iface if valid_iface(wan_iface) else '',
            'proto': 'udp', 'dport': str(port),
            'comment': f'Automatic WireGuard listener {name} UDP/{port}' + (f' on {wan_iface}' if wan_iface else ''),
        }
    return desired


def _wireguard_firewall_rule_matches(row, body):
    return (
        str(row.get('type') or '').lower() == 'in'
        and str(row.get('action') or '').upper() == 'ACCEPT'
        and _bool_option(row.get('enable', 1))
        and str(row.get('iface') or '') == str(body.get('iface') or '')
        and str(row.get('proto') or '').lower() == 'udp'
        and str(row.get('dport') or '') == str(body.get('dport') or '')
    )


def sync_wireguard_firewall_rules(cfg=None, *, apply_runtime=True):
    """Persist host INPUT permits for active PRM WireGuard listeners."""
    desired = _wireguard_firewall_desired(cfg)
    endpoint = _firewall_rule_endpoint('host')
    rows, err = _firewall_list_scope('host', None, 'Proxmox Host')
    if err:
        raise RuntimeError(f'Unable to read Proxmox Host firewall rules: {err}')

    auto_rows = [r for r in rows if r.get('managed') and str(r.get('display_comment') or '').startswith('Automatic WireGuard')]
    changed = False
    stale = [r for r in auto_rows if r.get('prm_id') not in desired]
    for row in sorted(stale, key=lambda x: int(x.get('pos') or 0), reverse=True):
        if row.get('pos') is not None:
            run(['pvesh', 'delete', f"{endpoint}/{int(row['pos'])}"])
            changed = True

    if stale:
        rows, err = _firewall_list_scope('host', None, 'Proxmox Host')
        if err:
            raise RuntimeError(f'Unable to re-read Proxmox Host firewall rules: {err}')

    by_id = {r.get('prm_id'): r for r in rows if r.get('managed')}
    for rid, body in desired.items():
        current = by_id.get(rid)
        _, _, _, args = _firewall_build_args(body, rule_id=rid)
        if current is None:
            run(['pvesh', 'create', endpoint] + args)
            changed = True
            continue
        if not _wireguard_firewall_rule_matches(current, body) or str(current.get('display_comment') or '') != body['comment']:
            pos = current.get('pos')
            if pos is None:
                raise RuntimeError(f'Automatic WireGuard firewall rule {rid} has no Proxmox position')
            run(['pvesh', 'set', f'{endpoint}/{int(pos)}'] + args)
            changed = True

    if changed:
        _invalidate_firewall_cache()
        if apply_runtime:
            _apply_firewall_runtime(safety=True)
    return {'changed': changed, 'rules': len(desired)}


def _refresh_dmz_after_wireguard_change():
    """Rebuild PRM NAT so DMZ auto-exclusions track WG listen ports."""
    try:
        cfg = _nat_cfg()
        if any(x.get('enabled', True) and str(x.get('kind') or '').lower() == 'dmz' for x in cfg):
            sync_nat_rules(cfg)
    except Exception as e:
        print(f'PRM WireGuard/DMZ refresh warning: {e}', file=sys.stderr)



def _wg_cfg():
    data = _load_json_file(WIREGUARD_CONFIG, {'interfaces': []})
    if not isinstance(data, dict):
        data = {'interfaces': []}
    if not isinstance(data.get('interfaces'), list):
        data['interfaces'] = []
    return data


def _wg_save(cfg):
    _atomic_json_write(WIREGUARD_CONFIG, cfg)
    try:
        os.chmod(WIREGUARD_CONFIG, 0o600)
    except Exception:
        pass


def _wg_key_valid(value):
    return bool(re.fullmatch(r'[A-Za-z0-9+/]{43}=', str(value or '').strip()))


def _wg_genkey():
    if not shutil.which('wg'):
        raise ValueError('wireguard-tools is not installed')
    p = subprocess.run(['wg', 'genkey'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or 'wg genkey failed').strip())
    key = p.stdout.strip()
    if not _wg_key_valid(key):
        raise RuntimeError('WireGuard generated an invalid private key')
    return key


def _wg_pubkey(private_key):
    p = subprocess.run(['wg', 'pubkey'], input=str(private_key).strip() + '\n', stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
    if p.returncode != 0:
        raise ValueError((p.stderr or 'Invalid WireGuard private key').strip())
    return p.stdout.strip()


def _wg_genpsk():
    p = subprocess.run(['wg', 'genpsk'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or 'wg genpsk failed').strip())
    return p.stdout.strip()


def _wg_find_iface(name, cfg=None):
    cfg = cfg or _wg_cfg()
    return next((x for x in cfg.get('interfaces', []) if x.get('name') == name), None)


def _wg_find_peer(peer_id, cfg=None):
    cfg = cfg or _wg_cfg()
    for iface in cfg.get('interfaces', []):
        for peer in iface.get('peers', []):
            if peer.get('id') == peer_id:
                return iface, peer
    return None, None


def _wg_normalize_iface_address(value, family, field):
    value = str(value or '').strip()
    if not value:
        return ''
    try:
        ipi = ipaddress.ip_interface(value)
    except Exception:
        raise ValueError(f'{field} must be a valid IPv{family} address/CIDR')
    if ipi.version != family:
        raise ValueError(f'{field} must be IPv{family}')
    return str(ipi)


def _wg_normalize_peer_address(value, family, iface_cidr, field):
    value = str(value or '').strip()
    if not value:
        return ''
    try:
        addr = ipaddress.ip_address(value.split('/')[0])
    except Exception:
        raise ValueError(f'{field} must be a valid IPv{family} address')
    if addr.version != family:
        raise ValueError(f'{field} must be IPv{family}')
    if iface_cidr:
        net = ipaddress.ip_interface(iface_cidr).network
        if addr not in net:
            raise ValueError(f'{field} must be inside WireGuard network {net}')
        if addr == ipaddress.ip_interface(iface_cidr).ip:
            raise ValueError(f'{field} cannot be the WireGuard server address')
    prefix = 32 if family == 4 else 128
    return f'{addr}/{prefix}'


def _wg_network_catalog():
    rows = []
    seen = set()
    for x in api_interfaces():
        if x.get('is_physical') or x.get('type') == 'eth':
            continue
        iface = str(x.get('iface') or '')
        values = []
        if x.get('configured_ipv4'):
            values.append(x.get('configured_ipv4'))
        values.extend(x.get('runtime_ipv4') or [])
        if x.get('configured_ipv6'):
            values.append(x.get('configured_ipv6'))
        values.extend(x.get('runtime_ipv6') or [])
        for value in values:
            try:
                net = ipaddress.ip_interface(value).network
            except Exception:
                continue
            if net.version == 6 and net.network_address.is_link_local:
                continue
            key = (iface, str(net))
            if key in seen:
                continue
            seen.add(key)
            rows.append({'iface': iface, 'cidr': str(net), 'family': net.version, 'label': f'{iface} · {net}'})
    rows.sort(key=lambda x: (natural_key(x['iface']), x['family'], x['cidr']))
    return rows


def _wg_endpoint_suggestion():
    defaults = default_route_ifaces()
    for iface in sorted(defaults, key=natural_key):
        for cidr in runtime_addresses(iface).get('ipv4', []):
            try:
                ip = ipaddress.ip_interface(cidr).ip
                if not ip.is_loopback and not ip.is_link_local:
                    return str(ip)
            except Exception:
                pass
    for iface in sorted(defaults, key=natural_key):
        for cidr in runtime_addresses(iface).get('ipv6', []):
            try:
                ip = ipaddress.ip_interface(cidr).ip
                if ip.is_global:
                    return str(ip)
            except Exception:
                pass
    return ''


def _wg_wan_ifaces():
    defaults = default_route_ifaces()
    rows = []
    for x in api_interfaces():
        name = str(x.get('iface') or '')
        if not name:
            continue
        if name in defaults or x.get('is_default_route'):
            rows.append(name)
    if not rows:
        rows = [str(x.get('iface')) for x in api_interfaces() if x.get('iface')]
    return sorted(set(rows), key=natural_key)


def _wg_next_peer_address(iface, family):
    cidr = iface.get('address4') if family == 4 else iface.get('address6')
    if not cidr:
        return ''
    ipi = ipaddress.ip_interface(cidr)
    net = ipi.network
    used = {ipi.ip}
    for peer in iface.get('peers', []):
        v = peer.get('address4') if family == 4 else peer.get('address6')
        if v:
            try:
                used.add(ipaddress.ip_interface(v).ip)
            except Exception:
                pass
    start = int(net.network_address) + 2
    limit = min(int(net.broadcast_address) if family == 4 else int(net.network_address) + 65535, start + 4096)
    for num in range(start, limit + 1):
        addr = ipaddress.ip_address(num)
        if addr not in used and addr in net:
            return str(addr)
    return ''


def _wg_next_ula_iface_address(cfg=None):
    """Return a free PRM WireGuard ULA interface address from fd00::/8.

    Keep allocation deterministic and easy to read (fd00:<n>::1/64), while
    avoiding IPv6 networks already configured on the host or in PRM WireGuard.
    """
    cfg = cfg or _wg_cfg()
    used = []
    try:
        for item in run_json(['ip', '-j', '-6', 'address', 'show']):
            for ai in item.get('addr_info', []):
                local = ai.get('local')
                prefix = ai.get('prefixlen')
                if not local or prefix is None or str(local).lower().startswith('fe80:'):
                    continue
                try:
                    used.append(ipaddress.ip_interface(f'{local}/{prefix}').network)
                except Exception:
                    pass
    except Exception:
        pass
    for iface in cfg.get('interfaces', []):
        value = iface.get('address6')
        if value:
            try:
                used.append(ipaddress.ip_interface(value).network)
            except Exception:
                pass
    for n in range(1, 65536):
        candidate = ipaddress.ip_network(f'fd00:{n:x}::/64')
        if any(candidate.overlaps(net) for net in used if getattr(net, 'version', 0) == 6):
            continue
        return f'fd00:{n:x}::1/64'
    # The /8 is enormous; this fallback should never be needed in practice.
    return 'fd00:ffff::1/64'


def _wg_validate_interface(data, current=None):
    name = str(data.get('name') or (current or {}).get('name') or '').strip()
    if not valid_iface(name) or not re.fullmatch(r'[A-Za-z0-9_=+.-]{1,15}', name):
        raise ValueError('WireGuard interface name is invalid')
    if current and name != current.get('name'):
        raise ValueError('WireGuard interface name cannot be changed while editing')
    if not current and (Path(f'/sys/class/net/{name}').exists() or (WG_DIR / f'{name}.conf').exists()):
        raise ValueError(f'Interface/config {name} already exists on the host')
    address4 = _wg_normalize_iface_address(data.get('address4'), 4, 'IPv4 address')
    use_ipv6 = bool(data.get('use_ipv6', bool((current or {}).get('address6'))))
    raw_address6 = str(data.get('address6') or '').strip() if use_ipv6 else ''
    if use_ipv6 and not raw_address6:
        raw_address6 = _wg_next_ula_iface_address()
    address6 = _wg_normalize_iface_address(raw_address6, 6, 'IPv6 address') if raw_address6 else ''
    if current and not address6 and any(peer.get('address6') or peer.get('internet6') for peer in (current.get('peers') or [])):
        raise ValueError('Remove IPv6 from WireGuard peers before disabling IPv6 on this interface')
    if not address4 and not address6:
        raise ValueError('Configure at least one WireGuard IPv4 or IPv6 address')
    try:
        listen_port = int(data.get('listen_port') or 51820)
    except Exception:
        raise ValueError('Listen port must be a number')
    if not 1 <= listen_port <= 65535:
        raise ValueError('Listen port must be between 1 and 65535')
    endpoint = str(data.get('endpoint') or '').strip()
    if endpoint.startswith('http://') or endpoint.startswith('https://'):
        raise ValueError('Endpoint must be a hostname or IP address, without http:// or https://')
    dns = str(data.get('dns') or '').strip()
    wan_iface = str(data.get('wan_iface') or '').strip()
    if wan_iface and (not valid_iface(wan_iface) or not _iface_exists(wan_iface)):
        raise ValueError('WAN interface is not present on this host')
    mtu = str(data.get('mtu') or '').strip()
    if mtu:
        try:
            mtu_i = int(mtu)
        except Exception:
            raise ValueError('MTU must be a number')
        if not 576 <= mtu_i <= 9000:
            raise ValueError('MTU must be between 576 and 9000')
        mtu = mtu_i
    private_key = (current or {}).get('private_key') or _wg_genkey()
    public_key = _wg_pubkey(private_key)
    return {
        'name': name, 'address4': address4, 'address6': address6, 'use_ipv6': bool(address6),
        'listen_port': listen_port, 'endpoint': endpoint, 'dns': dns,
        'wan_iface': wan_iface, 'mtu': mtu or '', 'private_key': private_key,
        'public_key': public_key, 'enabled': bool(data.get('enabled', (current or {}).get('enabled', True))),
        'peers': list((current or {}).get('peers') or []),
    }


def _wg_expand_access(values):
    catalog = _wg_network_catalog()
    allowed = {x['cidr'] for x in catalog}
    if not isinstance(values, list):
        values = []
    vals = [str(x).strip() for x in values if str(x).strip()]
    if '*' in vals:
        return sorted(allowed)
    bad = [x for x in vals if x not in allowed]
    if bad:
        raise ValueError('Unknown Proxmox network(s): ' + ', '.join(bad))
    return list(dict.fromkeys(vals))


def _wg_normalize_network_list(value):
    if isinstance(value, list):
        tokens = value
    else:
        tokens = re.split(r'[\s,;]+', str(value or ''))
    out = []
    for token in tokens:
        token = str(token).strip()
        if not token:
            continue
        try:
            out.append(str(ipaddress.ip_network(token, strict=False)))
        except Exception:
            raise ValueError(f'Invalid remote network: {token}')
    return list(dict.fromkeys(out))


def _wg_validate_peer(data, iface, current=None):
    ptype = str(data.get('type') or (current or {}).get('type') or 'client').strip().lower()
    if ptype not in ('client', 'site'):
        raise ValueError('Peer type must be Remote Access or Site-to-Site')
    name = str(data.get('name') or '').strip()
    if not name:
        raise ValueError('Peer name is required')
    address4 = _wg_normalize_peer_address(data.get('address4'), 4, iface.get('address4'), 'Peer IPv4') if data.get('address4') else ''
    address6 = _wg_normalize_peer_address(data.get('address6'), 6, iface.get('address6'), 'Peer IPv6') if data.get('address6') else ''
    if ptype == 'client' and not address4 and not address6:
        raise ValueError('Remote Access peer requires an IPv4 and/or IPv6 VPN address')
    # Prevent duplicate tunnel addresses inside this interface.
    current_id = (current or {}).get('id')
    for other in iface.get('peers', []):
        if other.get('id') == current_id:
            continue
        if address4 and other.get('address4') == address4:
            raise ValueError('This WireGuard IPv4 address is already assigned to another peer')
        if address6 and other.get('address6') == address6:
            raise ValueError('This WireGuard IPv6 address is already assigned to another peer')

    access_networks = _wg_expand_access(data.get('access_networks') or [])
    remote_networks = _wg_normalize_network_list(data.get('remote_networks') or []) if ptype == 'site' else []
    endpoint = str(data.get('endpoint') or '').strip() if ptype == 'site' else ''
    endpoint_port = str(data.get('endpoint_port') or '').strip() if ptype == 'site' else ''
    if endpoint_port:
        try:
            ep = int(endpoint_port)
        except Exception:
            raise ValueError('Remote endpoint port must be a number')
        if not 1 <= ep <= 65535:
            raise ValueError('Remote endpoint port must be between 1 and 65535')
        endpoint_port = ep
    else:
        endpoint_port = 51820

    if ptype == 'client':
        private_key = (current or {}).get('private_key') or _wg_genkey()
        public_key = _wg_pubkey(private_key)
    else:
        private_key = ''
        public_key = str(data.get('public_key') or (current or {}).get('public_key') or '').strip()
        if not _wg_key_valid(public_key):
            raise ValueError('Enter the remote site WireGuard public key')

    use_psk = bool(data.get('use_psk', bool((current or {}).get('preshared_key'))))
    psk = (current or {}).get('preshared_key') or ''
    if use_psk and not psk:
        psk = _wg_genpsk()
    if not use_psk:
        psk = ''
    keepalive = data.get('persistent_keepalive', 25 if ptype == 'client' else 0)
    try:
        keepalive = int(keepalive or 0)
    except Exception:
        raise ValueError('Persistent keepalive must be a number')
    if not 0 <= keepalive <= 65535:
        raise ValueError('Persistent keepalive must be between 0 and 65535 seconds')
    internet4 = bool(data.get('internet4', False))
    internet6 = bool(data.get('internet6', False))
    if internet4 and not iface.get('address4'):
        raise ValueError('IPv4 Internet access requires IPv4 on the WireGuard interface')
    if internet6 and not iface.get('address6'):
        raise ValueError('IPv6 Internet access requires IPv6 on the WireGuard interface')
    if (internet4 or internet6) and not iface.get('wan_iface'):
        raise ValueError('Select a WAN interface on the WireGuard interface before enabling Internet access')
    dns = str(data.get('dns') or '').strip()
    return {
        'id': (current or {}).get('id') or uuid.uuid4().hex[:12],
        'name': name, 'type': ptype, 'address4': address4, 'address6': address6,
        'private_key': private_key, 'public_key': public_key, 'preshared_key': psk,
        'access_networks': access_networks, 'remote_networks': remote_networks,
        'internet4': internet4, 'internet6': internet6, 'dns': dns,
        'endpoint': endpoint, 'endpoint_port': endpoint_port,
        'persistent_keepalive': keepalive,
    }


def _wg_peer_server_allowed(peer):
    out = []
    if peer.get('address4'):
        out.append(peer['address4'])
    if peer.get('address6'):
        out.append(peer['address6'])
    if peer.get('type') == 'site':
        out.extend(peer.get('remote_networks') or [])
    return list(dict.fromkeys(out))


def _wg_write_conf(iface):
    WG_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(WG_DIR, 0o700)
    lines = ['[Interface]']
    addresses = [x for x in (iface.get('address4'), iface.get('address6')) if x]
    lines.append('Address = ' + ', '.join(addresses))
    lines.append(f"ListenPort = {int(iface.get('listen_port') or 51820)}")
    lines.append(f"PrivateKey = {iface['private_key']}")
    # PRM deliberately does not let wg-quick create policy-routing rules. All
    # remote-site routes are installed explicitly in the normal main table.
    lines.append('Table = off')
    if iface.get('mtu'):
        lines.append(f"MTU = {int(iface['mtu'])}")
    lines.append('PostUp = /usr/lib/prm/prm-wireguard-hook up %i')
    lines.append('PostDown = /usr/lib/prm/prm-wireguard-hook down %i')
    for peer in iface.get('peers', []):
        allowed = _wg_peer_server_allowed(peer)
        if not allowed:
            continue
        lines += ['', '[Peer]', f"# PRM peer: {peer.get('name','peer')} [{peer.get('id','')}]", f"PublicKey = {peer['public_key']}"]
        if peer.get('preshared_key'):
            lines.append(f"PresharedKey = {peer['preshared_key']}")
        lines.append('AllowedIPs = ' + ', '.join(allowed))
        if peer.get('type') == 'site' and peer.get('endpoint'):
            ep = _wg_endpoint_token(peer['endpoint'], peer.get('endpoint_port') or 51820)
            lines.append(f'Endpoint = {ep}')
        if int(peer.get('persistent_keepalive') or 0) > 0:
            lines.append(f"PersistentKeepalive = {int(peer['persistent_keepalive'])}")
    path = WG_DIR / f"{iface['name']}.conf"
    tmp = path.with_suffix('.conf.tmp')
    tmp.write_text('\n'.join(lines) + '\n')
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)
    os.chmod(path, 0o600)
    return path


def _wg_endpoint_token(host, port):
    host = str(host or '').strip()
    if ':' in host and not host.startswith('['):
        host = f'[{host}]'
    return f'{host}:{int(port)}'


def _wg_runtime_dump():
    result = {'interfaces': {}, 'peers': {}}
    if not shutil.which('wg'):
        return result
    out = run(['wg', 'show', 'all', 'dump'], allow_fail=True)
    for line in out.splitlines():
        cols = line.split('\t')
        if len(cols) == 5:
            name = cols[0]
            result['interfaces'][name] = {'public_key': cols[2], 'listen_port': int(cols[3] or 0), 'fwmark': cols[4]}
        elif len(cols) >= 9:
            name, pub = cols[0], cols[1]
            result['peers'][(name, pub)] = {
                'endpoint': cols[3] if cols[3] != '(none)' else '',
                'allowed_ips': cols[4].split(',') if cols[4] else [],
                'latest_handshake': int(cols[5] or 0),
                'rx_bytes': int(cols[6] or 0), 'tx_bytes': int(cols[7] or 0),
                'persistent_keepalive': int(cols[8] or 0),
            }
    return result


def _wg_source_networks(peer, family):
    vals = []
    addr = peer.get('address4') if family == 4 else peer.get('address6')
    if addr:
        vals.append(addr)
    if peer.get('type') == 'site':
        for n in peer.get('remote_networks') or []:
            try:
                if ipaddress.ip_network(n, strict=False).version == family:
                    vals.append(n)
            except Exception:
                pass
    return list(dict.fromkeys(vals))


def _wg_sync_nft(cfg=None):
    if not shutil.which('nft'):
        return
    cfg = cfg or _wg_cfg()
    for fam, table in (('inet', 'prm_wireguard'), ('ip', 'prm_wg_nat44'), ('ip6', 'prm_wg_nat66')):
        run(['nft', 'delete', 'table', fam, table], allow_fail=True)
    lines = [
        'add table inet prm_wireguard',
        'add chain inet prm_wireguard forward { type filter hook forward priority -40; policy accept; }',
        'add table ip prm_wg_nat44',
        'add chain ip prm_wg_nat44 postrouting { type nat hook postrouting priority 112; policy accept; }',
        'add table ip6 prm_wg_nat66',
        'add chain ip6 prm_wg_nat66 postrouting { type nat hook postrouting priority 112; policy accept; }',
    ]
    catalog = _wg_network_catalog()
    all_local = {4: [x['cidr'] for x in catalog if x['family'] == 4], 6: [x['cidr'] for x in catalog if x['family'] == 6]}
    for iface in cfg.get('interfaces', []):
        if not iface.get('enabled', True):
            continue
        wgname = iface.get('name')
        wan = iface.get('wan_iface')
        for peer in iface.get('peers', []):
            selected = set(peer.get('access_networks') or [])
            for family in (4, 6):
                af = 'ip' if family == 4 else 'ip6'
                sources = _wg_source_networks(peer, family)
                if not sources:
                    continue
                local_nets = all_local[family]
                allowed_local = [n for n in local_nets if n in selected]
                blocked_local = [n for n in local_nets if n not in selected]
                for src in sources:
                    for dst in allowed_local:
                        lines.append(f'add rule inet prm_wireguard forward iifname {_nft_quote(wgname)} {af} saddr {src} {af} daddr {dst} counter accept comment {_nft_quote("prm-wg-access:"+peer["id"])}')
                    for dst in blocked_local:
                        lines.append(f'add rule inet prm_wireguard forward iifname {_nft_quote(wgname)} {af} saddr {src} {af} daddr {dst} counter drop comment {_nft_quote("prm-wg-block:"+peer["id"])}')
                    internet = bool(peer.get('internet4') if family == 4 else peer.get('internet6'))
                    if wan:
                        if internet:
                            nftfam = 'ip' if family == 4 else 'ip6'
                            table = 'prm_wg_nat44' if family == 4 else 'prm_wg_nat66'
                            lines.append(f'add rule {nftfam} {table} postrouting {af} saddr {src} oifname {_nft_quote(wan)} counter masquerade comment {_nft_quote("prm-wg-nat:"+peer["id"])}')
                        else:
                            lines.append(f'add rule inet prm_wireguard forward iifname {_nft_quote(wgname)} {af} saddr {src} oifname {_nft_quote(wan)} counter drop comment {_nft_quote("prm-wg-nointernet:"+peer["id"])}')
    path = STATE / 'prm-wireguard.nft'
    path.write_text('\n'.join(lines) + '\n')
    os.chmod(path, 0o600)
    run(['nft', '-c', '-f', str(path)])
    run(['nft', '-f', str(path)])


def _wg_sync_routes(iface_name=None, cfg=None):
    cfg = cfg or _wg_cfg()
    for iface in cfg.get('interfaces', []):
        name = iface.get('name')
        if iface_name and name != iface_name:
            continue
        if not iface.get('enabled', True) or not _iface_exists(name):
            continue
        for peer in iface.get('peers', []):
            if peer.get('type') != 'site':
                continue
            for net in peer.get('remote_networks') or []:
                try:
                    network = ipaddress.ip_network(net, strict=False)
                except Exception:
                    continue
                cmd = ['ip'] + (['-6'] if network.version == 6 else ['-4']) + ['route', 'replace', str(network), 'dev', name, 'proto', 'static']
                run(cmd, allow_fail=True)


def _wg_apply_forwarding(cfg=None):
    cfg = cfg or _wg_cfg()
    need4 = need6 = False
    for iface in cfg.get('interfaces', []):
        if not iface.get('enabled', True):
            continue
        for peer in iface.get('peers', []):
            if peer.get('address4') and (peer.get('access_networks') or peer.get('internet4') or peer.get('remote_networks')):
                need4 = True
            if peer.get('address6') and (peer.get('access_networks') or peer.get('internet6') or peer.get('remote_networks')):
                need6 = True
            for n in peer.get('remote_networks') or []:
                try:
                    if ipaddress.ip_network(n, strict=False).version == 4:
                        need4 = True
                    else:
                        need6 = True
                except Exception:
                    pass
    if need4:
        set_forwarding(4, True)
    if need6:
        set_forwarding(6, True)


def _wg_sync_runtime(iface_name=None, cfg=None):
    cfg = cfg or _wg_cfg()
    _wg_apply_forwarding(cfg)
    _wg_sync_routes(iface_name, cfg)
    _wg_sync_nft(cfg)


def wireguard_hook(action, iface):
    try:
        if str(action).lower() == 'up':
            _wg_sync_runtime(iface)
        else:
            _wg_sync_nft()
        return 0
    except Exception as e:
        print(f'PRM WireGuard hook warning: {e}', file=sys.stderr)
        return 0


def _wg_restart_interface(iface, old_conf=None):
    name = iface['name']
    service = f'wg-quick@{name}.service'
    if iface.get('enabled', True):
        run(['systemctl', 'enable', service], allow_fail=True)
        try:
            run(['systemctl', 'restart', service], timeout=45)
        except Exception:
            if old_conf is not None:
                (WG_DIR / f'{name}.conf').write_text(old_conf)
                os.chmod(WG_DIR / f'{name}.conf', 0o600)
                run(['systemctl', 'restart', service], allow_fail=True)
            raise
    else:
        run(['systemctl', 'disable', '--now', service], allow_fail=True)


def create_wireguard_interface(data):
    cfg = _wg_cfg()
    iface = _wg_validate_interface(data)
    cfg['interfaces'].append(iface)
    _wg_save(cfg)
    _wg_write_conf(iface)
    try:
        _wg_restart_interface(iface)
    except Exception as e:
        cfg['interfaces'] = [x for x in cfg['interfaces'] if x.get('name') != iface['name']]
        _wg_save(cfg)
        run(['systemctl', 'disable', '--now', f"wg-quick@{iface['name']}.service"], allow_fail=True)
        (WG_DIR / f"{iface['name']}.conf").unlink(missing_ok=True)
        raise RuntimeError(f'WireGuard interface could not be started: {e}')
    _wg_sync_runtime(iface['name'], cfg)
    sync_wireguard_firewall_rules(cfg)
    _refresh_dmz_after_wireguard_change()
    return {'ok': True, 'message': f"WireGuard interface {iface['name']} created", 'interface': iface['name']}


def update_wireguard_interface(name, data):
    cfg = _wg_cfg()
    old_cfg = json.loads(json.dumps(cfg))
    current = _wg_find_iface(name, cfg)
    if not current:
        raise ValueError('PRM-managed WireGuard interface not found')
    new = _wg_validate_interface({**data, 'name': name}, current=current)
    path = WG_DIR / f'{name}.conf'
    old_conf = path.read_text() if path.exists() else None
    cfg['interfaces'] = [new if x.get('name') == name else x for x in cfg['interfaces']]
    _wg_save(cfg)
    _wg_write_conf(new)
    try:
        _wg_restart_interface(new, old_conf=old_conf)
    except Exception:
        _wg_save(old_cfg)
        if old_conf is not None:
            path.write_text(old_conf)
            os.chmod(path, 0o600)
            run(['systemctl', 'restart', f'wg-quick@{name}.service'], allow_fail=True)
        raise
    _wg_sync_runtime(name, cfg)
    sync_wireguard_firewall_rules(cfg)
    _refresh_dmz_after_wireguard_change()
    return {'ok': True, 'message': f'WireGuard interface {name} updated'}


def delete_wireguard_interface(name):
    cfg = _wg_cfg()
    current = _wg_find_iface(name, cfg)
    if not current:
        raise ValueError('PRM-managed WireGuard interface not found')
    run(['systemctl', 'disable', '--now', f'wg-quick@{name}.service'], allow_fail=True)
    (WG_DIR / f'{name}.conf').unlink(missing_ok=True)
    cfg['interfaces'] = [x for x in cfg['interfaces'] if x.get('name') != name]
    _wg_save(cfg)
    _wg_sync_nft(cfg)
    sync_wireguard_firewall_rules(cfg)
    _refresh_dmz_after_wireguard_change()
    return {'ok': True, 'message': f'WireGuard interface {name} deleted'}


def set_wireguard_interface_state(name, state):
    cfg = _wg_cfg()
    iface = _wg_find_iface(name, cfg)
    if not iface:
        raise ValueError('PRM-managed WireGuard interface not found')
    state = str(state or '').lower()
    if state not in ('up', 'down'):
        raise ValueError('State must be up or down')
    old = bool(iface.get('enabled', True))
    iface['enabled'] = state == 'up'
    _wg_save(cfg)
    try:
        _wg_restart_interface(iface)
        _wg_sync_runtime(name, cfg)
        sync_wireguard_firewall_rules(cfg)
        _refresh_dmz_after_wireguard_change()
    except Exception:
        iface['enabled'] = old
        _wg_save(cfg)
        raise
    return {'ok': True, 'message': f'{name} set {state.upper()}'}


def create_wireguard_peer(data):
    cfg = _wg_cfg()
    old_cfg = json.loads(json.dumps(cfg))
    iface_name = str(data.get('interface') or '').strip()
    iface = _wg_find_iface(iface_name, cfg)
    if not iface:
        raise ValueError('Select a PRM-managed WireGuard interface')
    peer = _wg_validate_peer(data, iface)
    iface['peers'].append(peer)
    path = WG_DIR / f'{iface_name}.conf'
    old_conf = path.read_text() if path.exists() else None
    _wg_save(cfg)
    _wg_write_conf(iface)
    try:
        _wg_restart_interface(iface, old_conf=old_conf)
    except Exception:
        _wg_save(old_cfg)
        if old_conf is not None:
            path.write_text(old_conf)
            os.chmod(path, 0o600)
            run(['systemctl', 'restart', f'wg-quick@{iface_name}.service'], allow_fail=True)
        raise
    _wg_sync_runtime(iface_name, cfg)
    return {'ok': True, 'id': peer['id'], 'message': f"WireGuard peer {peer['name']} created"}


def update_wireguard_peer(peer_id, data):
    cfg = _wg_cfg()
    old_cfg = json.loads(json.dumps(cfg))
    iface, current = _wg_find_peer(peer_id, cfg)
    if not iface or not current:
        raise ValueError('PRM-managed WireGuard peer not found')
    new = _wg_validate_peer(data, iface, current=current)
    iface['peers'] = [new if x.get('id') == peer_id else x for x in iface['peers']]
    path = WG_DIR / f"{iface['name']}.conf"
    old_conf = path.read_text() if path.exists() else None
    _wg_save(cfg)
    _wg_write_conf(iface)
    try:
        _wg_restart_interface(iface, old_conf=old_conf)
    except Exception:
        _wg_save(old_cfg)
        if old_conf is not None:
            path.write_text(old_conf)
            os.chmod(path, 0o600)
            run(['systemctl', 'restart', f"wg-quick@{iface['name']}.service"], allow_fail=True)
        raise
    _wg_sync_runtime(iface['name'], cfg)
    return {'ok': True, 'message': f"WireGuard peer {new['name']} updated"}


def delete_wireguard_peer(peer_id):
    cfg = _wg_cfg()
    old_cfg = json.loads(json.dumps(cfg))
    iface, current = _wg_find_peer(peer_id, cfg)
    if not iface or not current:
        raise ValueError('PRM-managed WireGuard peer not found')
    path = WG_DIR / f"{iface['name']}.conf"
    old_conf = path.read_text() if path.exists() else None
    iface['peers'] = [x for x in iface['peers'] if x.get('id') != peer_id]
    _wg_save(cfg)
    _wg_write_conf(iface)
    try:
        _wg_restart_interface(iface, old_conf=old_conf)
    except Exception:
        _wg_save(old_cfg)
        if old_conf is not None:
            path.write_text(old_conf)
            os.chmod(path, 0o600)
            run(['systemctl', 'restart', f"wg-quick@{iface['name']}.service"], allow_fail=True)
        raise
    _wg_sync_runtime(iface['name'], cfg)
    return {'ok': True, 'message': f"WireGuard peer {current['name']} deleted"}


def _wg_client_address(peer_addr, iface_addr):
    if not peer_addr or not iface_addr:
        return ''
    ip = ipaddress.ip_interface(peer_addr).ip
    prefix = ipaddress.ip_interface(iface_addr).network.prefixlen
    return f'{ip}/{prefix}'


def wireguard_client_config(peer_id):
    cfg = _wg_cfg()
    iface, peer = _wg_find_peer(peer_id, cfg)
    if not iface or not peer:
        raise ValueError('PRM-managed WireGuard peer not found')
    if peer.get('type') != 'client' or not peer.get('private_key'):
        raise ValueError('Client configuration is available only for Remote Access peers generated by PRM')
    endpoint_host = iface.get('endpoint') or _wg_endpoint_suggestion()
    if not endpoint_host:
        raise ValueError('Configure Endpoint host/IP on the WireGuard interface before generating client config')
    addresses = []
    a4 = _wg_client_address(peer.get('address4'), iface.get('address4'))
    a6 = _wg_client_address(peer.get('address6'), iface.get('address6'))
    if a4: addresses.append(a4)
    if a6: addresses.append(a6)
    allowed = []
    selected_networks = list(peer.get('access_networks') or [])
    # Keep selected bridge prefixes even when a full-tunnel default route is
    # enabled. A client's local connected route is more specific than 0.0.0.0/0
    # (or ::/0), so dropping the selected prefixes here can make vmbr networks
    # unreachable whenever the remote LAN overlaps or wins by route specificity.
    # The explicit bridge prefixes ensure PRM network access and Internet VPN can
    # be enabled at the same time.
    if peer.get('internet4'):
        allowed.append('0.0.0.0/0')
    elif iface.get('address4'):
        ii = ipaddress.ip_interface(iface['address4'])
        allowed.append(f'{ii.ip}/32')
    if peer.get('internet6'):
        allowed.append('::/0')
    elif iface.get('address6'):
        ii = ipaddress.ip_interface(iface['address6'])
        allowed.append(f'{ii.ip}/128')
    for net in selected_networks:
        try:
            fam = ipaddress.ip_network(net, strict=False).version
        except Exception:
            continue
        allowed.append(net)
    allowed = list(dict.fromkeys(allowed))
    dns = peer.get('dns') or iface.get('dns') or ''
    lines = ['[Interface]', f"PrivateKey = {peer['private_key']}", 'Address = ' + ', '.join(addresses)]
    if dns:
        lines.append('DNS = ' + dns)
    lines += ['', '[Peer]', f"PublicKey = {iface['public_key']}"]
    if peer.get('preshared_key'):
        lines.append(f"PresharedKey = {peer['preshared_key']}")
    lines.append('AllowedIPs = ' + ', '.join(allowed))
    lines.append('Endpoint = ' + _wg_endpoint_token(endpoint_host, iface.get('listen_port') or 51820))
    if int(peer.get('persistent_keepalive') or 0) > 0:
        lines.append(f"PersistentKeepalive = {int(peer['persistent_keepalive'])}")
    text = '\n'.join(lines) + '\n'
    svg = ''
    if shutil.which('qrencode'):
        p = subprocess.run(['qrencode', '-t', 'SVG', '-o', '-'], input=text, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        if p.returncode == 0:
            svg = p.stdout
    return {'ok': True, 'interface': iface['name'], 'peer': peer['name'], 'config': text, 'qr_svg': svg}


def wireguard_status():
    cfg = _wg_cfg()
    runtime = _wg_runtime_dump()
    catalog = _wg_network_catalog()
    managed = []
    managed_names = set()
    now = int(time.time())
    for iface in cfg.get('interfaces', []):
        x = dict(iface)
        # Never expose private keys through the general status endpoint.
        x.pop('private_key', None)
        managed_names.add(iface.get('name'))
        rt = runtime['interfaces'].get(iface.get('name'), {})
        x['runtime_exists'] = _iface_exists(iface.get('name'))
        x['state'] = 'UP' if x['runtime_exists'] else 'DOWN'
        x['runtime_addresses'] = runtime_addresses(iface.get('name')) if x['runtime_exists'] else {'ipv4': [], 'ipv6': []}
        x['listen_port_runtime'] = rt.get('listen_port')
        peers = []
        for peer in iface.get('peers', []):
            p = dict(peer)
            p['has_psk'] = bool(peer.get('preshared_key'))
            p.pop('private_key', None)
            p.pop('preshared_key', None)
            prt = runtime['peers'].get((iface.get('name'), peer.get('public_key')), {})
            hs = int(prt.get('latest_handshake') or 0)
            p.update({
                'latest_handshake': hs, 'handshake_age': (now - hs) if hs else None,
                'rx_bytes': int(prt.get('rx_bytes') or 0), 'tx_bytes': int(prt.get('tx_bytes') or 0),
                'runtime_endpoint': prt.get('endpoint') or '',
                'online': bool(hs and now - hs < 180),
                'has_client_config': peer.get('type') == 'client' and bool(peer.get('private_key')),
            })
            peers.append(p)
        x['peers'] = peers
        x['peer_count'] = len(peers)
        x['managed'] = True
        managed.append(x)
    unmanaged = []
    for name, rt in runtime['interfaces'].items():
        if name in managed_names:
            continue
        unmanaged.append({
            'name': name, 'public_key': rt.get('public_key'), 'listen_port': rt.get('listen_port'),
            'state': 'UP', 'peer_count': sum(1 for k in runtime['peers'] if k[0] == name),
            'runtime_addresses': runtime_addresses(name), 'managed': False, 'peers': [],
        })
    return {
        'available': bool(shutil.which('wg')),
        'interfaces': managed + unmanaged,
        'networks': catalog,
        'wan_ifaces': _wg_wan_ifaces(),
        'endpoint_suggestion': _wg_endpoint_suggestion(),
        'ipv6_suggestion': _wg_next_ula_iface_address(cfg),
        'policy_routing': False,
        'routing_mode': 'main table / connected routes; site-to-site routes are installed explicitly',
        'firewall_note': 'Proxmox Firewall remains authoritative and may still need FORWARD rules between WireGuard and bridge networks.',
    }

def wireguard_live_status():
    """Lightweight peer monitor for the WireGuard page (safe to poll)."""
    cfg = _wg_cfg()
    runtime = _wg_runtime_dump()
    now = int(time.time())
    peers = []
    interfaces = []
    for iface in cfg.get('interfaces', []):
        name = str(iface.get('name') or '')
        interfaces.append({'name': name, 'state': 'UP' if _iface_exists(name) else 'DOWN'})
        for peer in iface.get('peers', []):
            prt = runtime['peers'].get((name, peer.get('public_key')), {})
            hs = int(prt.get('latest_handshake') or 0)
            peers.append({
                'id': peer.get('id'), 'interface': name,
                'latest_handshake': hs,
                'handshake_age': (now - hs) if hs else None,
                'online': bool(hs and now - hs < 180),
                'rx_bytes': int(prt.get('rx_bytes') or 0),
                'tx_bytes': int(prt.get('tx_bytes') or 0),
                'runtime_endpoint': prt.get('endpoint') or '',
            })
    return {'timestamp': now, 'interfaces': interfaces, 'peers': peers}


def ipv6_status():
    addrs = []
    for item in run_json(['ip', '-j', '-6', 'address', 'show']):
        for ai in item.get('addr_info', []):
            if ai.get('family') != 'inet6':
                continue
            addrs.append({'iface': item.get('ifname'), 'address': f"{ai.get('local')}/{ai.get('prefixlen')}", 'scope': ai.get('scope')})
    forwarding = Path('/proc/sys/net/ipv6/conf/all/forwarding').read_text().strip() if Path('/proc/sys/net/ipv6/conf/all/forwarding').exists() else '0'
    return {'forwarding': forwarding == '1', 'addresses': addrs}


def system_status():
    return {
        'hostname': socket.gethostname(), 'node': node_name(),
        'pve_version': run(['pveversion'], allow_fail=True).strip(),
        'kernel': run(['uname', '-r'], allow_fail=True).strip(),
        'uptime': run(['uptime', '-p'], allow_fail=True).strip(),
        'prm_version': VERSION, 'prm_port': load_config().get('port', 8005), 'proxmox_port': 8006,
        'pveproxy': run(['systemctl', 'is-active', 'pveproxy.service'], allow_fail=True).strip() or 'unknown',
        'prm_service': run(['systemctl', 'is-active', 'prm.service'], allow_fail=True).strip() or 'unknown',
    }


# ---------------- Proxmox network mutation helpers ----------------

def current_iface(iface):
    if not valid_iface(iface):
        raise ValueError('Invalid interface name')
    try:
        return pvesh_json(['get', f'/nodes/{node_name()}/network/{iface}']) or {}
    except Exception:
        # A staged deletion can make the Proxmox API stop returning an interface
        # while it is still active in /etc/network/interfaces. Keep it visible.
        active = _parse_interfaces_file('/etc/network/interfaces').get(iface)
        if active:
            return active
        raise ValueError(f'Interface {iface} was not found')


def _has_pending_network_changes():
    return bool(_pending_change_map())


def _normalize_network_file_permissions(*paths):
    """Keep Proxmox network config readable by pveproxy/pvedaemon.

    Some staged-network workflows may create interfaces.new with restrictive
    permissions.  If that file is promoted on Apply, /etc/network/interfaces
    can inherit mode 0600 and disappear from the Proxmox Network GUI.
    PRM therefore enforces the normal root:root 0644 metadata without changing
    file contents.
    """
    for item in paths:
        path = Path(item)
        if not path.exists():
            continue
        os.chown(path, 0, 0)
        os.chmod(path, 0o644)


def _backup_transaction():
    tx = uuid.uuid4().hex[:12]
    d = ROLLBACK_DIR / tx
    d.mkdir(parents=True, exist_ok=False)
    active = Path('/etc/network/interfaces')
    staged = Path('/etc/network/interfaces.new')
    if not active.exists():
        raise RuntimeError('/etc/network/interfaces was not found')
    _normalize_network_file_permissions(active, staged)
    shutil.copy2(active, d / 'interfaces')
    had_pending = False
    if staged.exists():
        try:
            had_pending = active.read_bytes() != staged.read_bytes()
        except Exception:
            had_pending = True
        shutil.copy2(staged, d / 'interfaces.new')
    for src, name in ((IPV6_CLIENTS_CONFIG, 'ipv6-clients.json'), (IPV6_PENDING_CONFIG, 'ipv6-pending.json')):
        if src.exists():
            shutil.copy2(src, d / name)
        else:
            (d / (name + '.absent')).touch()
    meta = {'tx': tx, 'created': int(time.time()), 'node': node_name(), 'had_pending': had_pending}
    (d / 'meta.json').write_text(json.dumps(meta))
    return tx, had_pending

def _cleanup_tx(tx):
    d = ROLLBACK_DIR / tx
    if d.exists():
        shutil.rmtree(d, ignore_errors=True)


def _schedule_rollback(tx):
    seconds = max(30, min(300, int(load_config().get('rollback_seconds', 90))))
    unit = f'prm-net-rollback-{tx}'
    run(['systemd-run', '--quiet', f'--unit={unit}', f'--on-active={seconds}s', '/usr/lib/prm/prm-rollback', tx])
    return seconds


def _cancel_rollback(tx):
    unit = f'prm-net-rollback-{tx}'
    run(['systemctl', 'stop', f'{unit}.timer'], allow_fail=True)
    run(['systemctl', 'stop', f'{unit}.service'], allow_fail=True)
    run(['systemctl', 'reset-failed', f'{unit}.service'], allow_fail=True)
    _cleanup_tx(tx)


def confirm_network(tx):
    if not re.fullmatch(r'[a-f0-9]{12}', str(tx or '')) or not (ROLLBACK_DIR / tx).exists():
        raise ValueError('Unknown or expired rollback transaction')
    _cancel_rollback(tx)
    return {'ok': True, 'message': 'Network configuration confirmed and kept'}


def revert_network(tx):
    if not re.fullmatch(r'[a-f0-9]{12}', str(tx or '')) or not (ROLLBACK_DIR / tx).exists():
        raise ValueError('Unknown or expired rollback transaction')
    run(['/usr/lib/prm/prm-rollback', tx], timeout=90)
    return {'ok': True, 'message': 'Previous network configuration restored'}


def _wait_task(upid, timeout=75):
    upid = str(upid or '').strip()
    if not upid.startswith('UPID:'):
        return
    deadline = time.time() + timeout
    while time.time() < deadline:
        status = pvesh_json(['get', f'/nodes/{node_name()}/tasks/{upid}/status']) or {}
        if status.get('status') == 'stopped':
            if status.get('exitstatus') not in (None, 'OK'):
                raise RuntimeError(f"Proxmox network reload failed: {status.get('exitstatus')}")
            return
        time.sleep(0.5)
    raise RuntimeError('Timed out waiting for Proxmox network reload')


def apply_network():
    # Ensure staged config cannot be promoted with mode 0600.
    _normalize_network_file_permissions('/etc/network/interfaces', '/etc/network/interfaces.new')
    out = run(['pvesh', 'set', f'/nodes/{node_name()}/network']).strip()
    _wait_task(out)
    # Applying interfaces.new may replace the active file; normalize again.
    _normalize_network_file_permissions('/etc/network/interfaces', '/etc/network/interfaces.new')
    return {'ok': True, 'message': 'Proxmox network configuration applied'}


def _staged_file():
    p = Path('/etc/network/interfaces.new')
    if not p.exists():
        raise RuntimeError('Proxmox did not create /etc/network/interfaces.new')
    _normalize_network_file_permissions(p)
    return p


def _replace_iface_method(path, iface, family, method):
    # Needed because the Proxmox network update API exposes method but currently
    # derives it as static/manual from address fields. DHCP/auto methods that are
    # already present are readable, but cannot be reliably written through that API.
    text = path.read_text()
    family_token = 'inet' if family == 4 else 'inet6'
    pattern = re.compile(rf'^(\s*iface\s+{re.escape(iface)}\s+{family_token}\s+)\S+(\s*)$', re.M)
    if pattern.search(text):
        text = pattern.sub(rf'\1{method}\2', text, count=1)
    else:
        lines = text.splitlines()
        insert_at = None
        for i, line in enumerate(lines):
            if re.match(rf'^\s*iface\s+{re.escape(iface)}\s+', line):
                insert_at = i + 1
                while insert_at < len(lines) and (lines[insert_at].startswith(' ') or lines[insert_at].startswith('\t')):
                    insert_at += 1
        if insert_at is None:
            raise RuntimeError(f'Could not locate interface stanza for {iface}')
        lines.insert(insert_at, f'iface {iface} {family_token} {method}')
        text = '\n'.join(lines) + ('\n' if text.endswith('\n') else '')
    path.write_text(text)
    _normalize_network_file_permissions(path)


def _set_dynamic_methods(iface, method4=None, method6=None):
    p = _staged_file()
    text = p.read_text() if p.exists() else ''
    if method4 in ('dhcp', 'auto'):
        _replace_iface_method(p, iface, 4, method4)
    elif method4 == 'manual' and re.search(rf'^\s*iface\s+{re.escape(iface)}\s+inet\s+', text, re.M):
        _replace_iface_method(p, iface, 4, 'manual')

    # Proxmox VE 9 currently ships an ifupdown2 version where `inet6 auto`
    # is unreliable (especially beside IPv4 DHCP).  PRM therefore keeps the
    # persistent Proxmox stanza as inet6 manual and runs the selected dynamic
    # IPv6 client independently after Apply.  Static IPv6 remains native PVE.
    if method6 in ('auto', 'slaac', 'dhcp', 'dhcpv6'):
        _replace_iface_method(p, iface, 6, 'manual')
        _stage_ipv6_client_mode(iface, method6)
    elif method6 == 'manual':
        text = p.read_text() if p.exists() else ''
        if re.search(rf'^\s*iface\s+{re.escape(iface)}\s+inet6\s+', text, re.M):
            _replace_iface_method(p, iface, 6, 'manual')
        _stage_ipv6_client_mode(iface, 'disabled')
    elif method6 == 'static':
        # Static means exactly static: remember the mode so Apply/boot disables
        # RA/SLAAC on this interface and removes previously learned dynamic
        # global addresses/routes without touching the configured static IPv6.
        _stage_ipv6_client_mode(iface, 'static')


def _delete_props_args(props):
    props = [p for p in props if p]
    return ['--delete', ','.join(props)] if props else []


def _static_ipv6_api_args(cidr6):
    """Return Proxmox API args for a static IPv6 host address.

    Use address6/netmask6 instead of cidr6.  This avoids pvesh CIDRv6
    parser differences between PVE releases while still using the official
    node network API.
    """
    value = str(cidr6 or '').strip()
    if not value:
        raise ValueError('IPv6 CIDR is required for Static mode')
    try:
        iface6 = ipaddress.IPv6Interface(value)
    except ValueError:
        raise ValueError('IPv6 address must look like fd04:10:100:100::1/64')
    return ['--address6', str(iface6.ip), '--netmask6', str(iface6.network.prefixlen)]


def _address_args(data):
    args = []
    mode4 = str(data.get('ipv4_mode') or 'manual')
    if mode4 == 'static':
        cidr = str(data.get('cidr') or '').strip()
        if not cidr:
            raise ValueError('IPv4 CIDR is required for Static mode')
        ipaddress.IPv4Interface(cidr)
        args += ['--cidr', cidr]
        if str(data.get('gateway') or '').strip():
            ipaddress.IPv4Address(str(data['gateway']).strip())
            args += ['--gateway', str(data['gateway']).strip()]
    mode6 = str(data.get('ipv6_mode') or 'manual')
    if mode6 == 'static':
        cidr6 = str(data.get('cidr6') or '').strip()
        args += _static_ipv6_api_args(cidr6)
        if str(data.get('gateway6') or '').strip():
            ipaddress.IPv6Address(str(data['gateway6']).strip())
            args += ['--gateway6', str(data['gateway6']).strip()]
    return args


def _common_create_args(data):
    args = _address_args(data)
    if data.get('autostart', True):
        args += ['--autostart', '1']
    if str(data.get('comments') or '').strip():
        args += ['--comments', str(data['comments']).strip()]
    if str(data.get('mtu') or '').strip():
        mtu = int(data['mtu'])
        if mtu < 1280 or mtu > 65520:
            raise ValueError('MTU must be between 1280 and 65520')
        args += ['--mtu', str(mtu)]
    return args


def _safe_mutation(mutator, description, post_apply=None):
    if not shutil.which('ifreload'):
        raise ValueError('ifupdown2/ifreload is required for safe live network changes')
    tx, had_pending = _backup_transaction()
    try:
        mutator()
        apply_network()
        if post_apply:
            post_apply()
        seconds = _schedule_rollback(tx)
        return {
            'ok': True,
            'message': description,
            'transaction': tx,
            'rollback_seconds': seconds,
            'included_existing_pending': had_pending,
        }
    except Exception:
        # Restore both the active config and any staged config that existed before
        # this PRM transaction. The rollback helper also reapplies the active file.
        run(['/usr/lib/prm/prm-rollback', tx], timeout=90, allow_fail=True)
        raise


def _stage_mutation(mutator, description):
    # Proxmox network API writes to /etc/network/interfaces.new.  PRM must not
    # auto-apply CRUD operations: the operator reviews the full pending diff
    # and explicitly applies it afterwards.  This prevents an unrelated stale
    # pending change from being committed together with a simple interface edit.
    mutator()
    _normalize_network_file_permissions('/etc/network/interfaces', '/etc/network/interfaces.new')
    changes = pending_network_status()
    return {
        'ok': True,
        'message': description + ' (pending; not applied)',
        'pending': changes,
        'requires_apply': True,
    }

def _validate_pending_before_apply():
    _normalize_network_file_permissions('/etc/network/interfaces', '/etc/network/interfaces.new')
    active = _parse_interfaces_file('/etc/network/interfaces')
    staged = _parse_interfaces_file('/etc/network/interfaces.new')
    if not Path('/etc/network/interfaces.new').exists():
        raise ValueError('There are no pending Proxmox network changes')
    active_nonlo = {k:v for k,v in active.items() if k != 'lo'}
    staged_nonlo = {k:v for k,v in staged.items() if k != 'lo'}
    if active_nonlo and not staged_nonlo:
        raise ValueError('Safety check failed: pending configuration contains no network interfaces. Revert pending changes instead of applying them.')
    # Never allow an explicit Apply to remove the interface carrying the current
    # default route without a replacement with the same name in staged config.
    defaults = default_route_ifaces()
    missing_defaults = sorted(i for i in defaults if i in active_nonlo and i not in staged_nonlo)
    if missing_defaults:
        raise ValueError('Safety check failed: pending configuration removes current default-route interface(s): ' + ', '.join(missing_defaults))
    return True

def apply_existing_pending():
    if not _has_pending_network_changes():
        return {'ok': True, 'message': 'There are no pending Proxmox network changes'}
    _validate_pending_before_apply()
    return _safe_mutation(lambda: None, 'Pending Proxmox network configuration applied', post_apply=_commit_ipv6_pending)


def discard_existing_pending():
    if not Path('/etc/network/interfaces.new').exists():
        return {'ok': True, 'message': 'There are no pending Proxmox network changes'}
    run(['pvesh', 'delete', f'/nodes/{node_name()}/network'])
    _clear_ipv6_pending()
    _normalize_network_file_permissions('/etc/network/interfaces')
    return {'ok': True, 'message': 'Pending Proxmox network changes reverted'}

def create_interface(data):
    typ = str(data.get('type') or '').strip().lower()
    iface = str(data.get('iface') or '').strip()
    if not valid_iface(iface):
        raise ValueError('Invalid interface name')
    if typ not in ('bridge', 'bond', 'vlan'):
        raise ValueError('Supported interface types: bridge, bond, vlan')

    def mutate():
        cmd = ['pvesh', 'create', f'/nodes/{node_name()}/network', '--type', typ, '--iface', iface]
        cmd += _common_create_args(data)
        if typ == 'bridge':
            if not iface.startswith('vmbr'):
                raise ValueError('Linux Bridge name should start with vmbr')
            port = str(data.get('bridge_port') or '').strip()
            if port and port.lower() != 'none':
                if port not in physical_interfaces() and not current_iface(port):
                    raise ValueError('Unknown bridge port')
                cmd += ['--bridge_ports', port]
            if data.get('vlan_aware'):
                cmd += ['--bridge_vlan_aware', '1']
        elif typ == 'bond':
            if not iface.startswith('bond'):
                raise ValueError('Linux Bond name should start with bond')
            slaves = data.get('slaves') or []
            if isinstance(slaves, str):
                slaves = slaves.split()
            slaves = [str(x) for x in slaves if str(x)]
            if len(slaves) < 2:
                raise ValueError('Select at least two physical interfaces for a bond')
            if any(x not in physical_interfaces() for x in slaves):
                raise ValueError('Bond slaves must be physical interfaces')
            mode = str(data.get('bond_mode') or 'active-backup')
            cmd += ['--slaves', ' '.join(slaves), '--bond_mode', mode]
            if mode == 'active-backup' and str(data.get('bond_primary') or '').strip():
                cmd += ['--bond-primary', str(data['bond_primary']).strip()]
            if mode in ('802.3ad', 'balance-xor'):
                cmd += ['--bond_xmit_hash_policy', str(data.get('bond_xmit_hash_policy') or 'layer2+3')]
        elif typ == 'vlan':
            raw = str(data.get('vlan_raw_device') or '').strip()
            tag = int(data.get('vlan_id') or 0)
            if not raw or not (1 <= tag <= 4094):
                raise ValueError('VLAN raw device and VLAN ID 1-4094 are required')
            cmd += ['--vlan-raw-device', raw, '--vlan-id', str(tag)]
        run(cmd)
        _set_dynamic_methods(iface, str(data.get('ipv4_mode')), str(data.get('ipv6_mode')))

    return _stage_mutation(mutate, f'{iface} created in Proxmox')


def update_interface(iface, data):
    old = current_iface(iface)
    typ = old.get('type')
    if typ == 'eth':
        raise ValueError('Physical interfaces use the attach/detach workflow')
    if typ not in ('bridge', 'bond', 'vlan'):
        raise ValueError(f'Editing interface type {typ} is not supported yet')

    def mutate():
        delete_props = ['cidr', 'gateway', 'cidr6', 'gateway6', 'address', 'netmask', 'address6', 'netmask6']
        if typ == 'bridge':
            delete_props += ['bridge_ports', 'bridge_vlan_aware']
        if typ == 'bond':
            delete_props += ['slaves', 'bond-primary', 'bond_xmit_hash_policy']
        if typ == 'vlan':
            delete_props += ['vlan-id', 'vlan-raw-device']
        cmd = ['pvesh', 'set', f'/nodes/{node_name()}/network/{iface}', '--type', typ]
        cmd += _delete_props_args(delete_props)
        cmd += _address_args(data)
        if str(data.get('comments') or '').strip():
            cmd += ['--comments', str(data['comments']).strip()]
        if typ == 'bridge':
            port = str(data.get('bridge_port') or '').strip()
            if port and port.lower() != 'none':
                cmd += ['--bridge_ports', port]
            if data.get('vlan_aware'):
                cmd += ['--bridge_vlan_aware', '1']
        elif typ == 'bond':
            slaves = data.get('slaves') or []
            if isinstance(slaves, str):
                slaves = slaves.split()
            if len(slaves) < 2:
                raise ValueError('Select at least two physical interfaces for a bond')
            cmd += ['--slaves', ' '.join(slaves), '--bond_mode', str(data.get('bond_mode') or old.get('bond_mode') or 'active-backup')]
            if str(data.get('bond_primary') or '').strip():
                cmd += ['--bond-primary', str(data['bond_primary']).strip()]
            if str(data.get('bond_xmit_hash_policy') or '').strip():
                cmd += ['--bond_xmit_hash_policy', str(data['bond_xmit_hash_policy']).strip()]
        elif typ == 'vlan':
            raw = str(data.get('vlan_raw_device') or old.get('vlan-raw-device') or '').strip()
            tag = int(data.get('vlan_id') or old.get('vlan-id') or 0)
            cmd += ['--vlan-raw-device', raw, '--vlan-id', str(tag)]
        run(cmd)
        _set_dynamic_methods(iface, str(data.get('ipv4_mode')), str(data.get('ipv6_mode')))

    return _stage_mutation(mutate, f'{iface} updated in Proxmox')


def delete_iface(iface):
    rows = {x.get('iface'): x for x in api_interfaces()}
    old = rows.get(iface) or current_iface(iface)
    if old.get('type') == 'eth' or old.get('is_physical'):
        raise ValueError('Physical interfaces cannot be deleted')

    # If it is already absent from staged config, deletion is already pending.
    if old.get('pending_action') == 'delete':
        return {'ok': True, 'message': f'{iface} deletion is already pending in Proxmox', 'pending': pending_network_status(), 'requires_apply': True}

    def mutate():
        run(['pvesh', 'delete', f'/nodes/{node_name()}/network/{iface}'])
        _stage_ipv6_client_mode(iface, 'disabled')

    return _stage_mutation(mutate, f'{iface} deletion staged in Proxmox')


def set_interface_link_state(iface, state):
    state = str(state or '').strip().lower()
    if state not in ('up', 'down'):
        raise ValueError('State must be up or down')
    row = next((x for x in api_interfaces() if x.get('iface') == iface), None)
    if not row:
        raise ValueError('Interface not found')
    if row.get('is_physical') or row.get('type') == 'eth':
        raise ValueError('Up/Down is only available for virtual interfaces')
    if row.get('type') not in ('bridge', 'bond', 'vlan'):
        raise ValueError('Up/Down is supported for Linux Bridge, Linux Bond and Linux VLAN')
    if not Path(f'/sys/class/net/{iface}').exists():
        raise ValueError(f'{iface} is not currently present in the Linux runtime')
    run(['ip', 'link', 'set', 'dev', iface, state])
    time.sleep(0.15)
    return {
        'ok': True,
        'iface': iface,
        'state': carrier_state(iface),
        'message': f'{iface} set {state.upper()} (runtime only)',
    }

def _l3_profile(item):
    iface = str(item.get('iface') or '')
    mode6 = _effective_ipv6_mode(iface, item)
    method6 = 'auto' if mode6 == 'slaac' else 'dhcp' if mode6 == 'dhcpv6' else (item.get('method6') or 'manual')
    return {
        'method': item.get('method') or 'manual',
        'cidr': _configured_cidr(item, 4),
        'gateway': item.get('gateway'),
        'method6': method6,
        'cidr6': _configured_cidr(item, 6),
        'gateway6': item.get('gateway6'),
    }


def _set_l3_via_api(iface, typ, profile, extra_args=None):
    delete_props = ['cidr', 'gateway', 'cidr6', 'gateway6', 'address', 'netmask', 'address6', 'netmask6']
    cmd = ['pvesh', 'set', f'/nodes/{node_name()}/network/{iface}', '--type', typ] + _delete_props_args(delete_props)
    if profile.get('method') == 'static' and profile.get('cidr'):
        cmd += ['--cidr', profile['cidr']]
        if profile.get('gateway'):
            cmd += ['--gateway', str(profile['gateway'])]
    if profile.get('method6') == 'static' and profile.get('cidr6'):
        cmd += _static_ipv6_api_args(profile['cidr6'])
        if profile.get('gateway6'):
            cmd += ['--gateway6', str(profile['gateway6'])]
    if extra_args:
        cmd += extra_args
    run(cmd)
    _set_dynamic_methods(iface, profile.get('method'), profile.get('method6'))


def attach_physical(data):
    phy = str(data.get('physical') or '').strip()
    bridge = str(data.get('bridge') or '').strip()
    create_bridge_name = str(data.get('new_bridge') or '').strip()
    transfer = bool(data.get('transfer_settings', True))
    if phy not in physical_interfaces():
        raise ValueError('Physical interface not found')
    src = current_iface(phy)
    if src.get('parent_bridge'):
        raise ValueError('Physical interface is already attached to a bridge')
    rows = api_interfaces()
    membership = _bridge_membership(rows)
    if phy in membership:
        raise ValueError(f'{phy} is already attached to {membership[phy]}')
    target_name = create_bridge_name or bridge
    if not valid_iface(target_name) or not target_name.startswith('vmbr'):
        raise ValueError('Select an existing vmbr or provide a new vmbr name')
    profile = _l3_profile(src)

    def mutate():
        if create_bridge_name:
            run(['pvesh', 'create', f'/nodes/{node_name()}/network', '--type', 'bridge', '--iface', target_name,
                 '--autostart', '1', '--bridge_ports', phy])
            target = {'type': 'bridge'}
        else:
            target = {'type': 'bridge'}
            if target.get('type') != 'bridge':
                raise ValueError('Target must be a Linux Bridge')
            ports = [p for p in str(target.get('bridge_ports') or '').split() if p]
            if phy not in ports:
                ports.append(phy)
            run(['pvesh', 'set', f'/nodes/{node_name()}/network/{target_name}', '--type', 'bridge', '--bridge_ports', ' '.join(ports)])
        if transfer:
            # Source becomes L2-only; target receives the exact L3 mode, including DHCP.
            _set_l3_via_api(phy, 'eth', {'method': 'manual', 'method6': 'manual'})
            final_ports = phy if create_bridge_name else ' '.join(ports)
            _set_l3_via_api(target_name, 'bridge', profile, ['--bridge_ports', final_ports])

    result = _stage_mutation(mutate, f'{phy} attachment to {target_name} staged in Proxmox')
    result['bridge'] = target_name
    result['transferred'] = transfer
    return result


def detach_physical(data):
    phy = str(data.get('physical') or '').strip()
    transfer = bool(data.get('transfer_settings', True))
    if phy not in physical_interfaces():
        raise ValueError('Physical interface not found')
    rows = api_interfaces()
    membership = _bridge_membership(rows)
    bridge = membership.get(phy)
    if not bridge:
        raise ValueError('Physical interface is not attached to a Linux Bridge')
    br = current_iface(bridge)
    profile = _l3_profile(br)

    def mutate():
        ports = [p for p in str(br.get('bridge_ports') or '').split() if p and p != phy]
        cmd = ['pvesh', 'set', f'/nodes/{node_name()}/network/{bridge}', '--type', 'bridge', '--delete', 'bridge_ports']
        if ports:
            cmd += ['--bridge_ports', ' '.join(ports)]
        run(cmd)
        if transfer:
            _set_l3_via_api(bridge, 'bridge', {'method': 'manual', 'method6': 'manual'}, (['--bridge_ports', ' '.join(ports)] if ports else None))
            _set_l3_via_api(phy, 'eth', profile)

    result = _stage_mutation(mutate, f'{phy} detachment from {bridge} staged in Proxmox')
    result['bridge'] = bridge
    result['transferred'] = transfer
    return result


# ---------------- Authentication ----------------
def _pam_library():
    path = ctypes.util.find_library('pam') or 'libpam.so.0'
    lib = ctypes.CDLL(path)
    lib.pam_start.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.POINTER(PamConv), ctypes.POINTER(ctypes.c_void_p)]
    lib.pam_start.restype = ctypes.c_int
    lib.pam_authenticate.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.pam_authenticate.restype = ctypes.c_int
    lib.pam_acct_mgmt.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.pam_acct_mgmt.restype = ctypes.c_int
    lib.pam_end.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.pam_end.restype = ctypes.c_int
    return lib


PAM = _pam_library()
LIBC = ctypes.CDLL(ctypes.util.find_library('c') or 'libc.so.6')
LIBC.calloc.argtypes = [ctypes.c_size_t, ctypes.c_size_t]
LIBC.calloc.restype = ctypes.c_void_p
LIBC.strdup.argtypes = [ctypes.c_char_p]
LIBC.strdup.restype = ctypes.c_void_p


def pam_authenticate(username, password):
    if not username or not password or '\x00' in username or '\x00' in password:
        return False
    user_b = username.encode('utf-8')
    pass_b = password.encode('utf-8')

    @CONV_FUNC
    def conversation(num_msg, msg, resp, appdata_ptr):
        if num_msg <= 0:
            return 19
        mem = LIBC.calloc(num_msg, ctypes.sizeof(PamResponse))
        if not mem:
            return 5
        replies = ctypes.cast(mem, ctypes.POINTER(PamResponse))
        for i in range(num_msg):
            style = msg[i].contents.msg_style
            if style == PAM_PROMPT_ECHO_OFF:
                replies[i].resp = ctypes.cast(LIBC.strdup(pass_b), ctypes.c_char_p)
            elif style == PAM_PROMPT_ECHO_ON:
                replies[i].resp = ctypes.cast(LIBC.strdup(user_b), ctypes.c_char_p)
            elif style in (PAM_ERROR_MSG, PAM_TEXT_INFO):
                replies[i].resp = None
            else:
                return 19
            replies[i].resp_retcode = 0
        resp[0] = ctypes.cast(mem, ctypes.POINTER(PamResponse))
        return PAM_SUCCESS

    conv = PamConv(conversation, None)
    pamh = ctypes.c_void_p()
    result = PAM.pam_start(b'prm', user_b, ctypes.byref(conv), ctypes.byref(pamh))
    try:
        if result != PAM_SUCCESS:
            return False
        result = PAM.pam_authenticate(pamh, 0)
        if result != PAM_SUCCESS:
            return False
        result = PAM.pam_acct_mgmt(pamh, 0)
        return result == PAM_SUCCESS
    finally:
        if pamh:
            PAM.pam_end(pamh, result)


def user_groups(username):
    try:
        p = pwd.getpwnam(username)
    except KeyError:
        return set()
    groups = {grp.getgrgid(p.pw_gid).gr_name}
    for g in grp.getgrall():
        if username in g.gr_mem:
            groups.add(g.gr_name)
    return groups


def user_is_authorized(username, cfg):
    allowed = cfg.get('allowed_groups') or []
    return True if not allowed else bool(user_groups(username).intersection(set(allowed)))


def new_session(username, cfg):
    token = secrets.token_urlsafe(32)
    hours = max(1, min(168, int(cfg.get('session_hours', 8))))
    expiry = time.time() + hours * 3600
    with SESSIONS_LOCK:
        SESSIONS[token] = {'username': username, 'expires': expiry}
    return token, expiry


def session_from_cookie(header):
    if not header:
        return None
    c = cookies.SimpleCookie()
    try:
        c.load(header)
    except cookies.CookieError:
        return None
    morsel = c.get('prm_session')
    if not morsel:
        return None
    token = morsel.value
    with SESSIONS_LOCK:
        session = SESSIONS.get(token)
        if not session:
            return None
        if session['expires'] <= time.time():
            SESSIONS.pop(token, None)
            return None
        return token, session


def destroy_session(token):
    if token:
        with SESSIONS_LOCK:
            SESSIONS.pop(token, None)


class Handler(SimpleHTTPRequestHandler):
    def _session(self):
        return session_from_cookie(self.headers.get('Cookie', ''))

    def _require_auth(self):
        session = self._session()
        if session:
            return session[1]
        self._json(401, {'error': 'authentication required'})
        return None

    def _json(self, status, obj, extra_headers=None):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Length', str(len(b)))
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(b)

    def _body(self):
        n = int(self.headers.get('Content-Length', '0') or 0)
        if n > 131072:
            raise ValueError('Request body too large')
        return json.loads(self.rfile.read(n) or b'{}')

    def do_GET(self):
        p = urlparse(self.path).path
        try:
            if p == '/api/health':
                self._json(200, {'ok': True, 'name': 'VE Router Manager', 'version': VERSION, 'node': node_name()})
                return
            if p == '/api/me':
                session = self._session()
                if not session:
                    self._json(401, {'error': 'authentication required'})
                    return
                self._json(200, {'username': session[1]['username'], 'auth': 'linux-pam'})
                return
            if p.startswith('/api/'):
                auth = self._require_auth()
                if not auth:
                    return
                endpoints = {
                    '/api/dashboard': dashboard_data, '/api/dashboard/live': dashboard_live_data, '/api/interfaces': api_interfaces,
                    '/api/networks': network_rows, '/api/dhcp': dhcp_status, '/api/routes': route_rows,
                    '/api/nat': nat_status, '/api/firewall': firewall_status, '/api/wireguard': wireguard_status,
                    '/api/wireguard/live': wireguard_live_status,
                    '/api/ipv6': ipv6_status, '/api/system': system_status, '/api/network/pending': pending_network_status,
                }
                if p == '/api/status':
                    self._json(200, {'name': 'VE Router Manager', 'version': VERSION, 'node': node_name(), 'username': auth['username'], 'auth': 'Linux PAM'})
                    return
                if p.startswith('/api/interfaces/'):
                    iface = unquote(p.rsplit('/', 1)[-1])
                    found = next((x for x in api_interfaces() if x.get('iface') == iface), None)
                    self._json(200, found if found is not None else current_iface(iface))
                    return
                m = re.fullmatch(r'/api/wireguard/peers/([^/]+)/config', p)
                if m:
                    self._json(200, wireguard_client_config(unquote(m.group(1))))
                    return
                if p in endpoints:
                    self._json(200, endpoints[p]())
                    return
                self._json(404, {'error': 'not found'})
                return
            self.path = '/index.html' if p == '/' else p
            return super().do_GET()
        except ValueError as e:
            self._json(400, {'error': str(e)})
        except Exception as e:
            self._json(500, {'error': str(e)})

    def do_POST(self):
        p = urlparse(self.path).path
        _invalidate_fast_caches()
        try:
            if p == '/api/login':
                body = self._body()
                username = str(body.get('username', '')).strip()
                password = str(body.get('password', ''))
                cfg = load_config()
                if not pam_authenticate(username, password):
                    time.sleep(0.35)
                    self._json(401, {'error': 'Invalid Linux username or password'})
                    return
                if not user_is_authorized(username, cfg):
                    self._json(403, {'error': 'Linux account is authenticated but is not authorized to administer PRM'})
                    return
                token, _ = new_session(username, cfg)
                self._json(200, {'ok': True, 'username': username, 'auth': 'linux-pam'}, {'Set-Cookie': f'prm_session={token}; Path=/; HttpOnly; Secure; SameSite=Strict'})
                return
            if not self._require_auth():
                return
            if p == '/api/logout':
                session = self._session()
                if session:
                    destroy_session(session[0])
                self._json(200, {'ok': True}, {'Set-Cookie': 'prm_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0'})
            elif p == '/api/interfaces':
                self._json(200, create_interface(self._body()))
            elif p == '/api/routes':
                self._json(200, create_route(self._body()))
            elif p == '/api/dhcp/reservations':
                self._json(200, create_dhcp_reservation(self._body()))
            elif p == '/api/dhcp':
                self._json(200, create_dhcp(self._body()))
            elif p == '/api/nat':
                self._json(200, create_nat(self._body()))
            elif p == '/api/firewall':
                self._json(200, create_firewall_rule(self._body()))
            elif p == '/api/wireguard/interfaces':
                self._json(200, create_wireguard_interface(self._body()))
            elif p == '/api/wireguard/peers':
                self._json(200, create_wireguard_peer(self._body()))
            elif re.fullmatch(r'/api/wireguard/interfaces/[^/]+/state', p):
                iface = unquote(p.split('/')[-2])
                body = self._body()
                self._json(200, set_wireguard_interface_state(iface, body.get('state')))
            elif p == '/api/firewall/options':
                body = self._body()
                self._json(200, set_firewall_enabled(body.get('scope'), bool(body.get('enabled', True))))
            elif p == '/api/firewall/policies':
                self._json(200, set_firewall_policies(self._body()))
            elif p == '/api/nat/forwarding':
                body = self._body()
                self._json(200, set_forwarding(int(body.get('family') or 4), bool(body.get('enabled', True))))
            elif p == '/api/ipv6/forwarding':
                body = self._body()
                self._json(200, set_ipv6_forwarding(bool(body.get('enabled', True))))
            elif p == '/api/interfaces/physical/attach':
                self._json(200, attach_physical(self._body()))
            elif p == '/api/interfaces/physical/detach':
                self._json(200, detach_physical(self._body()))
            elif re.fullmatch(r'/api/interfaces/[^/]+/state', p):
                iface = unquote(p.split('/')[-2])
                body = self._body()
                self._json(200, set_interface_link_state(iface, body.get('state')))
            elif p == '/api/network/apply-pending':
                self._json(200, apply_existing_pending())
            elif p == '/api/network/discard-pending':
                self._json(200, discard_existing_pending())
            elif p == '/api/network/apply':
                self._json(200, apply_network())
            elif p == '/api/network/confirm':
                self._json(200, confirm_network(str(self._body().get('transaction') or '')))
            elif p == '/api/network/revert':
                self._json(200, revert_network(str(self._body().get('transaction') or '')))
            else:
                self._json(404, {'error': 'not found'})
        except ValueError as e:
            self._json(400, {'error': str(e)})
        except Exception as e:
            self._json(500, {'error': str(e)})

    def do_PUT(self):
        if not self._require_auth():
            return
        p = urlparse(self.path).path
        _invalidate_fast_caches()
        try:
            if p.startswith('/api/interfaces/'):
                iface = unquote(p.rsplit('/', 1)[-1])
                self._json(200, update_interface(iface, self._body()))
            elif p.startswith('/api/routes/'):
                route_id = unquote(p.rsplit('/', 1)[-1])
                self._json(200, update_route(route_id, self._body()))
            elif p.startswith('/api/dhcp/'):
                iface = unquote(p.rsplit('/', 1)[-1])
                self._json(200, update_dhcp(iface, self._body()))
            elif p.startswith('/api/nat/'):
                rule_id = unquote(p.rsplit('/', 1)[-1])
                self._json(200, update_nat(rule_id, self._body()))
            elif p.startswith('/api/wireguard/interfaces/'):
                iface = unquote(p.rsplit('/', 1)[-1])
                self._json(200, update_wireguard_interface(iface, self._body()))
            elif p.startswith('/api/wireguard/peers/'):
                peer_id = unquote(p.rsplit('/', 1)[-1])
                self._json(200, update_wireguard_peer(peer_id, self._body()))
            elif p.startswith('/api/firewall/'):
                rule_id = unquote(p.rsplit('/', 1)[-1])
                self._json(200, update_firewall_rule(rule_id, self._body()))
            else:
                self._json(404, {'error': 'not found'})
        except ValueError as e:
            self._json(400, {'error': str(e)})
        except Exception as e:
            self._json(500, {'error': str(e)})

    def do_DELETE(self):
        if not self._require_auth():
            return
        p = urlparse(self.path).path
        _invalidate_fast_caches()
        try:
            if p.startswith('/api/interfaces/'):
                self._json(200, delete_iface(unquote(p.rsplit('/', 1)[-1])))
            elif p.startswith('/api/routes/'):
                self._json(200, delete_route(unquote(p.rsplit('/', 1)[-1])))
            elif p.startswith('/api/dhcp/reservations/'):
                self._json(200, delete_dhcp_reservation(unquote(p.rsplit('/', 1)[-1])))
            elif p.startswith('/api/dhcp/'):
                self._json(200, delete_dhcp(unquote(p.rsplit('/', 1)[-1])))
            elif p.startswith('/api/nat/'):
                self._json(200, delete_nat(unquote(p.rsplit('/', 1)[-1])))
            elif p.startswith('/api/wireguard/interfaces/'):
                self._json(200, delete_wireguard_interface(unquote(p.rsplit('/', 1)[-1])))
            elif p.startswith('/api/wireguard/peers/'):
                self._json(200, delete_wireguard_peer(unquote(p.rsplit('/', 1)[-1])))
            elif p.startswith('/api/firewall/'):
                self._json(200, delete_firewall_rule(unquote(p.rsplit('/', 1)[-1])))
            else:
                self._json(404, {'error': 'not found'})
        except ValueError as e:
            self._json(400, {'error': str(e)})
        except Exception as e:
            self._json(500, {'error': str(e)})

    def translate_path(self, path):
        rel = urlparse(path).path.lstrip('/') or 'index.html'
        return str(WEB / rel)

    def end_headers(self):
        path = urlparse(self.path).path
        if not path.startswith('/api/'):
            if path.endswith(('.css', '.js', '.svg', '.png', '.ico')):
                self.send_header('Cache-Control', 'public, max-age=86400')
            else:
                self.send_header('Cache-Control', 'no-cache')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        super().end_headers()

    def log_message(self, fmt, *args):
        print('%s - %s' % (self.address_string(), fmt % args), flush=True)


def main():
    STATE.mkdir(parents=True, exist_ok=True)
    ROLLBACK_DIR.mkdir(parents=True, exist_ok=True)
    DHCP_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(DHCP_DIR, 0o700)
    except Exception:
        pass
    cfg = load_config()
    os.chdir(WEB)
    httpd = ThreadingHTTPServer((cfg['listen'], int(cfg['port'])), Handler)
    if cfg.get('tls', True):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain('/etc/prm/prm.crt', '/etc/prm/prm.key')
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
    print(f'PRM {VERSION} listening on {cfg["listen"]}:{cfg["port"]} node={node_name()} auth=linux-pam', flush=True)
    httpd.serve_forever()


if __name__ == '__main__':
    if '--sync-dhcp' in sys.argv:
        raise SystemExit(sync_dhcp_runtime())
    if '--sync-wireguard-firewall' in sys.argv:
        sync_wireguard_firewall_rules()
        raise SystemExit(0)
    if '--sync-ipv6-icmp-firewall' in sys.argv:
        sync_ipv6_icmp_firewall_rule()
        raise SystemExit(0)
    if '--sync-nat-helper' in sys.argv:
        # Repair only the Proxmox fwbr conntrack-zone helper. Do not rewrite
        # nft NAT tables here: this is a one-time boot/start verification and
        # preserves NAT counters/conntrack.
        _sync_nat_conntrack_zone(_nat_cfg())
        raise SystemExit(0)
    if '--restore-nat' in sys.argv:
        raise SystemExit(restore_nat_on_boot())
    if '--sync-nat' in sys.argv:
        raise SystemExit(sync_nat_rules())
    if '--wireguard-hook' in sys.argv:
        try:
            i = sys.argv.index('--wireguard-hook')
            action = sys.argv[i + 1]
            iface = sys.argv[i + 2]
        except Exception:
            raise SystemExit(0)
        raise SystemExit(wireguard_hook(action, iface))
    main()
